-- MariaDB dump 10.17  Distrib 10.5.2-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: sarbon_new
-- ------------------------------------------------------
-- Server version	10.5.2-MariaDB-1:10.5.2+maria~bionic

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `academic_degree`
--

DROP TABLE IF EXISTS `academic_degree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `academic_degree` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_degree`
--

LOCK TABLES `academic_degree` WRITE;
/*!40000 ALTER TABLE `academic_degree` DISABLE KEYS */;
/*!40000 ALTER TABLE `academic_degree` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `action_log`
--

DROP TABLE IF EXISTS `action_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` int(11) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `method` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `result` longtext DEFAULT NULL,
  `errors` text DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  `post_data` longtext DEFAULT NULL,
  `get_data` text DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `browser` text DEFAULT NULL,
  `ip_address` varchar(33) DEFAULT NULL,
  `host` text DEFAULT NULL,
  `ip_address_data` text DEFAULT NULL,
  `log_date` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action_log`
--

LOCK TABLES `action_log` WRITE;
/*!40000 ALTER TABLE `action_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `action_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `type` tinyint(1) DEFAULT 0,
  `postcode` varchar(150) DEFAULT NULL,
  `lat` varchar(100) DEFAULT NULL,
  `long` varchar(100) DEFAULT NULL,
  `sort` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `created_on` timestamp NULL DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_on` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx-area-region_id` (`region_id`) USING BTREE,
  CONSTRAINT `fk-area-region_id` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=784 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (1,'Mo\'ynoq tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(2,'Kegeyli tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(3,'Ellikqala tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(4,'Chimboy tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(5,'Beruniy tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(6,'Amudaryo tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(7,'Nukus tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(8,'Qonliko\'l tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(9,'Qorauzaq tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(10,'Qung\'irot tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(11,'Shumanay tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(12,'Taxtako\'pir tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(13,'To\'rtko\'l tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(14,'Xo\'jayli tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(15,'Bo\'zatov tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(16,'Andijon tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(17,'Asaka tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(18,'Baliqchi tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(19,'Bo\'z tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(20,'Buloqboshi tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(21,'Izboskan tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(22,'Jalolquduq tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(23,'Marhamat tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(24,'Oltinko\'l tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(25,'Paxtaobod tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(26,'Qo\'rg\'ontepa tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(27,'Shahrixon tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(28,'Ulug\'nor tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(29,'Xo\'jaobod tumani',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(30,'Xonobod shahri',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(31,'Andijon shahri',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(32,'Chortoq tumani',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(33,'Chust tumani',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(34,'Kosonsoy tumani',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(35,'Mingbuloq tumani',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(36,'Namangan tumani',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(37,'Norin tumani',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(38,'Pop tumani',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(39,'To\'raqo\'rg\'on tumani',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(40,'Uchqo\'rg\'on tumani',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(41,'Uychi tumani',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(42,'Yangiqo\'rg\'on tumani',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(43,'Namangan shahri',3,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(44,'Beshariq tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(45,'Bog\'dod tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(46,'Buvayda tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(47,'Dang\'ara tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(48,'Farg\'ona tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(49,'Furqat tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(50,'Farg\'ona shahri',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(51,'Oltiariq tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(52,'Qo\'shtepa tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(53,'O\'zbekiston tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(54,'Quva tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(55,'Rishton tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(56,'So\'x tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(57,'Toshloq tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(58,'Uchko\'prik tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(59,'Yozyovon tumani',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(60,'Marg\'ilon shahri',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(61,'Quvasov shahri',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(62,'Qo\'qon shahri',4,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(64,'Buxoro tumani',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(65,'G\'ijduvon tumani',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(66,'Jondor tumani',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(67,'Kogon tumani',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(68,'Olot tumani',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(69,'Peshko\' tumani',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(70,'Qorako\'l tumani',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(71,'Qorovulbozor tumani',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(72,'Romitan tumani',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(73,'Shofirkon tumani',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(74,'Vobkent tumani',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(75,'Buxoro shahar',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(76,'Bog\'ot tumani',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(77,'Gurlan tumani',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(78,'Tuproqqal`a tumani',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(79,'Qo\'shko\'pir tumani',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(80,'Shovot tumani',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(81,'Urganch tumani',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(82,'Xazorasp tumani',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(83,'Xiva tumani',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(84,'Xonqa tumani',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(85,'Yangiariq tumani',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(86,'Yangibozor tumani',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(87,'Urgench shahar',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(88,'Angor tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(89,'Bandixon tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(90,'Boysun tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(91,'Denov tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(92,'Jarqo\'rg\'on tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(93,'Muzrobot tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(94,'Oltinsoy tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(95,'Qiziriq tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(96,'Qumqo\'rg\'on tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(97,'Sariosiyo tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(98,'Sherobod tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(99,'Sho\'rchi tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(100,'Termiz tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(101,'Uzun tumani',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(102,'Chiroqchi tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(103,'Dehqonobod tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(104,'G\'uzor tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(105,'Kasbi tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(106,'Kitob tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(107,'Koson tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(108,'Mirishkor tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(109,'Mubarak tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(110,'Nishon tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(111,'Qamashi tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(112,'Qarshi tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(113,'Shahrisabz tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(114,'Yakkabog\' tumani',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(115,'Qarshi shahri',8,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(116,'Arnasoy tumani',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(117,'Baxmal tumani',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(118,'Do\'stlik tumani',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(119,'Forish tumani',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(120,'G\'allaorol tumani',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(121,'Sharof Rashidov',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(122,'Mirzacho\'l tumani',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(123,'Paxtakor tumani',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(124,'Yangiobod tumani',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(125,'Zafarobod tumani',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(126,'Zarbdor tumani',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(127,'Zomin tumani',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(128,'Jizzax shahri',9,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(129,'Karmana tumani',10,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(130,'Konimex tumani',10,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(131,'Navbahor tumani',10,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(132,'Nurota tumani',10,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(133,'Qiziltepa tumani',10,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(134,'Tomdi tumani',10,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(135,'Uchquduq tumani',10,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(136,'Xatirchi tumani',10,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(137,'Navoiy shahri',10,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(138,'Zarafshon shaxar',10,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(139,'Bulung\'ur tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(140,'Ishtixon tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(141,'Jomboy tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(142,'Kattaqo\'rg\'on tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(143,'Narpay tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(144,'Nurobod tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(145,'Oqdaryo tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(146,'Pastdarg\'om tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(147,'Paxtachi tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(148,'Poyariq tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(149,'Qo\'shrabot tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(150,'Samarqand tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(151,'Toyloq tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(152,'Urgut tumani',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(153,'Samarqand shahar',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(154,'Boyovut tumani',12,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(155,'Guliston tumani',12,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(156,'Mirzaobod tumani',12,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(157,'Oqoltin tumani',12,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(158,'Sardoba tumani',12,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(159,'Sayxunobod tumani',12,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(160,'Sirdaryo tumani',12,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(161,'Xovos tumani',12,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(162,'Guliston shahri',12,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(163,'Yangiyer shahri',12,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(164,'Bekobod tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(165,'Bo\'ka tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(166,'Bo\'stonliq tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(167,'Chinoz tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(168,'Ohangaron tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(169,'Oqqo\'rg\'on tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(170,'Parkent tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(171,'Piskent tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(172,'Qibray tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(173,'Quyi chirchiq tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(174,'Yangiyo\'l tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(175,'Yuqori chirchiq tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(176,'Zangiota tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(177,'Angren shahri',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(178,'Chirchiq shahri',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(179,'Olmaliq shahri',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(181,'Toshkent tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(182,'O\'rtachirchiq tumani',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(183,'Bekobod shahri',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(184,'Bektemir tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(185,'Bektemir tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(186,'Chilonzor tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(187,'Mirobod tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(188,'Mirzo Ulug\'bek tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(189,'Olmazor tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(190,'Shayxontohur tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(191,'Sirg\'ali tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(192,'Uchtepa tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(193,'Yakkasaroy tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(194,'Yunusobod tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(196,'Nukus shahri',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(197,'Taxiatosh tumani',1,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(198,'Asaka shahri',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(199,'Qorasuv shahri',2,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(200,'Kogon shahri',5,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(201,'Xiva shahri',6,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(202,'Termiz shahri',7,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(203,'Kattaqo\'rg\'on shahri',11,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(204,'Shirin tumani',12,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(778,'Yangiyo\'l shahar',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(779,'Ohangaron shahar',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(780,'Nurafshon shahri',13,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(781,'Yangihayot tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(782,'Yashnabod tumani',14,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0),(783,'Boshqa',15,0,NULL,NULL,NULL,0,0,NULL,0,NULL,0);
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) NOT NULL,
  `user_id` varchar(64) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `idx-auth_assignment-user_id` (`user_id`),
  CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_assignment`
--

LOCK TABLES `auth_assignment` WRITE;
/*!40000 ALTER TABLE `auth_assignment` DISABLE KEYS */;
INSERT INTO `auth_assignment` VALUES ('admin','1',1734413788),('admin','2',1734413788),('admin','3',1734413788),('admin','4',1734413788),('edu_admin','5',1734436012);
/*!40000 ALTER TABLE `auth_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_child`
--

DROP TABLE IF EXISTS `auth_child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_child` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` varchar(255) NOT NULL,
  `child` varchar(255) NOT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_child`
--

LOCK TABLES `auth_child` WRITE;
/*!40000 ALTER TABLE `auth_child` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_item` (
  `name` varchar(64) NOT NULL,
  `type` smallint(6) NOT NULL,
  `description` text DEFAULT NULL,
  `rule_name` varchar(64) DEFAULT NULL,
  `data` blob DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_item`
--

LOCK TABLES `auth_item` WRITE;
/*!40000 ALTER TABLE `auth_item` DISABLE KEYS */;
INSERT INTO `auth_item` VALUES ('academic-degree_create',2,'Academic degree|create',NULL,NULL,1734430603,1734430603),('academic-degree_delete',2,'Academic degree|delete',NULL,NULL,1734430603,1734430603),('academic-degree_index',2,'Academic degree|index',NULL,NULL,1734430603,1734430603),('academic-degree_update',2,'Academic degree|update',NULL,NULL,1734430603,1734430603),('academic-degree_view',2,'Academic degree|view',NULL,NULL,1734430603,1734430603),('access-control_create-permission',2,'Access control|create permission',NULL,NULL,1734430603,1734430603),('access-control_create-role',2,'Access control|create role',NULL,NULL,1734430603,1734430603),('access-control_delete-role',2,'Access control|delete role',NULL,NULL,1734430603,1734430603),('access-control_permissions',2,'Access control|permissions',NULL,NULL,1734430603,1734430603),('access-control_role-permissions',2,'Access control|role permissions',NULL,NULL,1734430603,1734430603),('access-control_roles',2,'Access control|roles',NULL,NULL,1734430603,1734430603),('access-control_update-role',2,'Access control|update role',NULL,NULL,1734430603,1734430603),('action-log_index',2,'Action log|index',NULL,NULL,1734430603,1734430603),('action-log_view',2,'Action log|view',NULL,NULL,1734430603,1734430603),('admin',1,'Administrator',NULL,NULL,1734413788,1734413788),('area_create',2,'Area|create',NULL,NULL,1734430603,1734430603),('area_delete',2,'Area|delete',NULL,NULL,1734430603,1734430603),('area_index',2,'Area|index',NULL,NULL,1734430603,1734430603),('area_update',2,'Area|update',NULL,NULL,1734430603,1734430603),('area_view',2,'Area|view',NULL,NULL,1734430603,1734430603),('attend-reason_cancellation',2,'Attend reason|cancellation',NULL,NULL,1734430603,1734430603),('attend-reason_confirm',2,'Attend reason|confirm',NULL,NULL,1734430603,1734430603),('attend-reason_create',2,'Attend reason|create',NULL,NULL,1734430603,1734430603),('attend-reason_delete',2,'Attend reason|delete',NULL,NULL,1734430603,1734430603),('attend-reason_index',2,'Attend reason|index',NULL,NULL,1734430603,1734430603),('attend-reason_update',2,'Attend reason|update',NULL,NULL,1734430603,1734430603),('attend-reason_view',2,'Attend reason|view',NULL,NULL,1734430603,1734430603),('attend_create',2,'Attend|create',NULL,NULL,1734430603,1734430603),('attend_delete',2,'Attend|delete',NULL,NULL,1734430603,1734430603),('attend_index',2,'Attend|index',NULL,NULL,1734430603,1734430603),('attend_update',2,'Attend|update',NULL,NULL,1734430603,1734430603),('attend_view',2,'Attend|view',NULL,NULL,1734430603,1734430603),('building_create',2,'Building|create',NULL,NULL,1734430603,1734430603),('building_delete',2,'Building|delete',NULL,NULL,1734430603,1734430603),('building_index',2,'Building|index',NULL,NULL,1734430603,1734430603),('building_update',2,'Building|update',NULL,NULL,1734430603,1734430603),('building_view',2,'Building|view',NULL,NULL,1734430603,1734430603),('category-of-cohabitant_create',2,'Category of cohabitant|create',NULL,NULL,1734430603,1734430603),('category-of-cohabitant_delete',2,'Category of cohabitant|delete',NULL,NULL,1734430603,1734430603),('category-of-cohabitant_index',2,'Category of cohabitant|index',NULL,NULL,1734430603,1734430603),('category-of-cohabitant_update',2,'Category of cohabitant|update',NULL,NULL,1734430603,1734430603),('category-of-cohabitant_view',2,'Category of cohabitant|view',NULL,NULL,1734430603,1734430603),('citizenship_create',2,'Citizenship|create',NULL,NULL,1734430603,1734430603),('citizenship_delete',2,'Citizenship|delete',NULL,NULL,1734430603,1734430603),('citizenship_index',2,'Citizenship|index',NULL,NULL,1734430603,1734430603),('citizenship_update',2,'Citizenship|update',NULL,NULL,1734430603,1734430603),('citizenship_view',2,'Citizenship|view',NULL,NULL,1734430603,1734430603),('commands-type_create',2,'Commands type|create',NULL,NULL,1734430603,1734430603),('commands-type_delete',2,'Commands type|delete',NULL,NULL,1734430603,1734430603),('commands-type_index',2,'Commands type|index',NULL,NULL,1734430603,1734430603),('commands-type_update',2,'Commands type|update',NULL,NULL,1734430603,1734430603),('commands-type_view',2,'Commands type|view',NULL,NULL,1734430603,1734430603),('commands_create',2,'Commands|create',NULL,NULL,1734430603,1734430603),('commands_delete',2,'Commands|delete',NULL,NULL,1734430603,1734430603),('commands_index',2,'Commands|index',NULL,NULL,1734430603,1734430603),('commands_update',2,'Commands|update',NULL,NULL,1734430603,1734430603),('commands_view',2,'Commands|view',NULL,NULL,1734430603,1734430603),('country_index',2,'Country|index',NULL,NULL,1734430603,1734430603),('country_view',2,'Country|view',NULL,NULL,1734430603,1734430603),('course_create',2,'Course|create',NULL,NULL,1734430603,1734430603),('course_delete',2,'Course|delete',NULL,NULL,1734430603,1734430603),('course_index',2,'Course|index',NULL,NULL,1734430603,1734430603),('course_update',2,'Course|update',NULL,NULL,1734430603,1734430603),('course_view',2,'Course|view',NULL,NULL,1734430603,1734430603),('dean',1,'Dean of the faculty',NULL,NULL,1734413788,1734413788),('dean_deputy',1,'dean_deputy',NULL,NULL,1734430608,1734430608),('degree-info_create',2,'Degree info|create',NULL,NULL,1734430603,1734430603),('degree-info_delete',2,'Degree info|delete',NULL,NULL,1734430603,1734430603),('degree-info_index',2,'Degree info|index',NULL,NULL,1734430603,1734430603),('degree-info_update',2,'Degree info|update',NULL,NULL,1734430603,1734430603),('degree-info_view',2,'Degree info|view',NULL,NULL,1734430603,1734430603),('degree_create',2,'Degree|create',NULL,NULL,1734430603,1734430603),('degree_delete',2,'Degree|delete',NULL,NULL,1734430603,1734430603),('degree_index',2,'Degree|index',NULL,NULL,1734430603,1734430603),('degree_update',2,'Degree|update',NULL,NULL,1734430603,1734430603),('degree_view',2,'Degree|view',NULL,NULL,1734430603,1734430603),('department_create',2,'Department|create',NULL,NULL,1734430604,1734430604),('department_delete',2,'Department|delete',NULL,NULL,1734430604,1734430604),('department_index',2,'Department|index',NULL,NULL,1734430603,1734430603),('department_types',2,'Department|types',NULL,NULL,1734430603,1734430603),('department_update',2,'Department|update',NULL,NULL,1734430604,1734430604),('department_user-access',2,'Department|user access',NULL,NULL,1734430603,1734430603),('department_view',2,'Department|view',NULL,NULL,1734430604,1734430604),('dep_lead',1,'dep_lead',NULL,NULL,1734430608,1734430608),('diploma-type_create',2,'Diploma type|create',NULL,NULL,1734430604,1734430604),('diploma-type_delete',2,'Diploma type|delete',NULL,NULL,1734430604,1734430604),('diploma-type_index',2,'Diploma type|index',NULL,NULL,1734430604,1734430604),('diploma-type_update',2,'Diploma type|update',NULL,NULL,1734430604,1734430604),('diploma-type_view',2,'Diploma type|view',NULL,NULL,1734430604,1734430604),('direction_create',2,'Direction|create',NULL,NULL,1734430604,1734430604),('direction_delete',2,'Direction|delete',NULL,NULL,1734430604,1734430604),('direction_index',2,'Direction|index',NULL,NULL,1734430604,1734430604),('direction_update',2,'Direction|update',NULL,NULL,1734430604,1734430604),('direction_view',2,'Direction|view',NULL,NULL,1734430604,1734430604),('document-decree_command-type',2,'Document decree|command type',NULL,NULL,1734430604,1734430604),('document-decree_confirm',2,'Document decree|confirm',NULL,NULL,1734430604,1734430604),('document-decree_create',2,'Document decree|create',NULL,NULL,1734430604,1734430604),('document-decree_delete',2,'Document decree|delete',NULL,NULL,1734430604,1734430604),('document-decree_hr-update',2,'Document decree|hr update',NULL,NULL,1734430604,1734430604),('document-decree_index',2,'Document decree|index',NULL,NULL,1734430604,1734430604),('document-decree_sign',2,'Document decree|sign',NULL,NULL,1734430604,1734430604),('document-decree_signature-update',2,'Document decree|signature update',NULL,NULL,1734430604,1734430604),('document-decree_update',2,'Document decree|update',NULL,NULL,1734430604,1734430604),('document-decree_view',2,'Document decree|view',NULL,NULL,1734430604,1734430604),('document-execution_create',2,'Document execution|create',NULL,NULL,1734430604,1734430604),('document-execution_delete',2,'Document execution|delete',NULL,NULL,1734430604,1734430604),('document-execution_index',2,'Document execution|index',NULL,NULL,1734430604,1734430604),('document-execution_update',2,'Document execution|update',NULL,NULL,1734430604,1734430604),('document-execution_view',2,'Document execution|view',NULL,NULL,1734430604,1734430604),('document-notification_command-type',2,'Document notification|command type',NULL,NULL,1734430604,1734430604),('document-notification_confirm',2,'Document notification|confirm',NULL,NULL,1734430604,1734430604),('document-notification_create',2,'Document notification|create',NULL,NULL,1734430604,1734430604),('document-notification_delete',2,'Document notification|delete',NULL,NULL,1734430604,1734430604),('document-notification_hr-update',2,'Document notification|hr update',NULL,NULL,1734430604,1734430604),('document-notification_index',2,'Document notification|index',NULL,NULL,1734430604,1734430604),('document-notification_sign',2,'Document notification|sign',NULL,NULL,1734430604,1734430604),('document-notification_signature-update',2,'Document notification|signature update',NULL,NULL,1734430604,1734430604),('document-notification_update',2,'Document notification|update',NULL,NULL,1734430604,1734430604),('document-notification_view',2,'Document notification|view',NULL,NULL,1734430604,1734430604),('document-type_create',2,'Document type|create',NULL,NULL,1734430604,1734430604),('document-type_delete',2,'Document type|delete',NULL,NULL,1734430604,1734430604),('document-type_index',2,'Document type|index',NULL,NULL,1734430604,1734430604),('document-type_update',2,'Document type|update',NULL,NULL,1734430604,1734430604),('document-type_view',2,'Document type|view',NULL,NULL,1734430604,1734430604),('document-weight_create',2,'Document weight|create',NULL,NULL,1734430604,1734430604),('document-weight_delete',2,'Document weight|delete',NULL,NULL,1734430604,1734430604),('document-weight_index',2,'Document weight|index',NULL,NULL,1734430604,1734430604),('document-weight_update',2,'Document weight|update',NULL,NULL,1734430604,1734430604),('document-weight_view',2,'Document weight|view',NULL,NULL,1734430604,1734430604),('document_create',2,'Document|create',NULL,NULL,1734430604,1734430604),('document_delete',2,'Document|delete',NULL,NULL,1734430604,1734430604),('document_delete-file',2,'Document|delete file',NULL,NULL,1734430604,1734430604),('document_index',2,'Document|index',NULL,NULL,1734430604,1734430604),('document_update',2,'Document|update',NULL,NULL,1734430604,1734430604),('document_view',2,'Document|view',NULL,NULL,1734430604,1734430604),('edu-form_create',2,'Edu form|create',NULL,NULL,1734430604,1734430604),('edu-form_delete',2,'Edu form|delete',NULL,NULL,1734430604,1734430604),('edu-form_index',2,'Edu form|index',NULL,NULL,1734430604,1734430604),('edu-form_update',2,'Edu form|update',NULL,NULL,1734430604,1734430604),('edu-form_view',2,'Edu form|view',NULL,NULL,1734430604,1734430604),('edu-plan_create',2,'Edu plan|create',NULL,NULL,1734430604,1734430604),('edu-plan_delete',2,'Edu plan|delete',NULL,NULL,1734430604,1734430604),('edu-plan_index',2,'Edu plan|index',NULL,NULL,1734430604,1734430604),('edu-plan_update',2,'Edu plan|update',NULL,NULL,1734430604,1734430604),('edu-plan_view',2,'Edu plan|view',NULL,NULL,1734430604,1734430604),('edu-semestr-subject-category-time_index',2,'Edu semestr subject category time|index',NULL,NULL,1734430604,1734430604),('edu-semestr-subject_create',2,'Edu semestr subject|create',NULL,NULL,1734430604,1734430604),('edu-semestr-subject_delete',2,'Edu semestr subject|delete',NULL,NULL,1734430604,1734430604),('edu-semestr-subject_index',2,'Edu semestr subject|index',NULL,NULL,1734430604,1734430604),('edu-semestr-subject_update',2,'Edu semestr subject|update',NULL,NULL,1734430604,1734430604),('edu-semestr-subject_view',2,'Edu semestr subject|view',NULL,NULL,1734430604,1734430604),('edu-semestr_create',2,'Edu semestr|create',NULL,NULL,1734430604,1734430604),('edu-semestr_delete',2,'Edu semestr|delete',NULL,NULL,1734430604,1734430604),('edu-semestr_index',2,'Edu semestr|index',NULL,NULL,1734430604,1734430604),('edu-semestr_student-subject-merge',2,'Edu semestr|student subject merge',NULL,NULL,1734430604,1734430604),('edu-semestr_update',2,'Edu semestr|update',NULL,NULL,1734430604,1734430604),('edu-semestr_view',2,'Edu semestr|view',NULL,NULL,1734430604,1734430604),('edu-type_create',2,'Edu type|create',NULL,NULL,1734430604,1734430604),('edu-type_delete',2,'Edu type|delete',NULL,NULL,1734430604,1734430604),('edu-type_index',2,'Edu type|index',NULL,NULL,1734430604,1734430604),('edu-type_update',2,'Edu type|update',NULL,NULL,1734430604,1734430604),('edu-type_view',2,'Edu type|view',NULL,NULL,1734430604,1734430604),('edu-year_create',2,'Edu year|create',NULL,NULL,1734430604,1734430604),('edu-year_delete',2,'Edu year|delete',NULL,NULL,1734430604,1734430604),('edu-year_index',2,'Edu year|index',NULL,NULL,1734430604,1734430604),('edu-year_update',2,'Edu year|update',NULL,NULL,1734430604,1734430604),('edu-year_view',2,'Edu year|view',NULL,NULL,1734430604,1734430604),('edu_admin',1,'edu_admin',NULL,NULL,1734413788,1734413788),('edu_moderator',1,'edu_moderator',NULL,NULL,1734430608,1734430608),('exam-control-student_check',2,'Exam control student|check',NULL,NULL,1734430604,1734430604),('exam-control-student_create',2,'Exam control student|create',NULL,NULL,1734430604,1734430604),('exam-control-student_delete',2,'Exam control student|delete',NULL,NULL,1734430604,1734430604),('exam-control-student_finish',2,'Exam control student|finish',NULL,NULL,1734430604,1734430604),('exam-control-student_index',2,'Exam control student|index',NULL,NULL,1734430604,1734430604),('exam-control-student_rating',2,'Exam control student|rating',NULL,NULL,1734430604,1734430604),('exam-control-student_update',2,'Exam control student|update',NULL,NULL,1734430604,1734430604),('exam-control-student_view',2,'Exam control student|view',NULL,NULL,1734430604,1734430604),('exam-control_create',2,'Exam control|create',NULL,NULL,1734430604,1734430604),('exam-control_delete',2,'Exam control|delete',NULL,NULL,1734430604,1734430604),('exam-control_index',2,'Exam control|index',NULL,NULL,1734430604,1734430604),('exam-control_update',2,'Exam control|update',NULL,NULL,1734430604,1734430604),('exam-control_view',2,'Exam control|view',NULL,NULL,1734430604,1734430604),('exam-questions_create',2,'Exam questions|create',NULL,NULL,1734430604,1734430604),('exam-questions_delete',2,'Exam questions|delete',NULL,NULL,1734430604,1734430604),('exam-questions_index',2,'Exam questions|index',NULL,NULL,1734430604,1734430604),('exam-questions_is-confirm',2,'Exam questions|is confirm',NULL,NULL,1734430604,1734430604),('exam-questions_update',2,'Exam questions|update',NULL,NULL,1734430604,1734430604),('exam-questions_view',2,'Exam questions|view',NULL,NULL,1734430604,1734430604),('exam-student-question_delete',2,'Exam student question|delete',NULL,NULL,1734430605,1734430605),('exam-student-question_index',2,'Exam student question|index',NULL,NULL,1734430605,1734430605),('exam-student-question_update',2,'Exam student question|update',NULL,NULL,1734430605,1734430605),('exam-student-question_update-ball',2,'Exam student question|update ball',NULL,NULL,1734430605,1734430605),('exam-student-question_view',2,'Exam student question|view',NULL,NULL,1734430605,1734430605),('exam-student_create',2,'Exam student|create',NULL,NULL,1734430605,1734430605),('exam-student_delete',2,'Exam student|delete',NULL,NULL,1734430605,1734430605),('exam-student_finish',2,'Exam student|finish',NULL,NULL,1734430605,1734430605),('exam-student_index',2,'Exam student|index',NULL,NULL,1734430604,1734430604),('exam-student_rating',2,'Exam student|rating',NULL,NULL,1734430605,1734430605),('exam-student_update',2,'Exam student|update',NULL,NULL,1734430605,1734430605),('exam-student_view',2,'Exam student|view',NULL,NULL,1734430605,1734430605),('exam-test-option_create',2,'Exam test option|create',NULL,NULL,1734430605,1734430605),('exam-test-option_delete',2,'Exam test option|delete',NULL,NULL,1734430605,1734430605),('exam-test-option_index',2,'Exam test option|index',NULL,NULL,1734430605,1734430605),('exam-test-option_update',2,'Exam test option|update',NULL,NULL,1734430605,1734430605),('exam-test-option_view',2,'Exam test option|view',NULL,NULL,1734430605,1734430605),('exam-test-student-answer_delete',2,'Exam test student answer|delete',NULL,NULL,1734430605,1734430605),('exam-test-student-answer_designation',2,'Exam test student answer|designation',NULL,NULL,1734430605,1734430605),('exam-test-student-answer_index',2,'Exam test student answer|index',NULL,NULL,1734430605,1734430605),('exam-test-student-answer_view',2,'Exam test student answer|view',NULL,NULL,1734430605,1734430605),('exam-test_create',2,'Exam test|create',NULL,NULL,1734430605,1734430605),('exam-test_delete',2,'Exam test|delete',NULL,NULL,1734430605,1734430605),('exam-test_excel-import',2,'Exam test|excel import',NULL,NULL,1734430605,1734430605),('exam-test_index',2,'Exam test|index',NULL,NULL,1734430605,1734430605),('exam-test_is-check',2,'Exam test|is check',NULL,NULL,1734430605,1734430605),('exam-test_update',2,'Exam test|update',NULL,NULL,1734430605,1734430605),('exam-test_view',2,'Exam test|view',NULL,NULL,1734430605,1734430605),('exams-type_create',2,'Exams type|create',NULL,NULL,1734430605,1734430605),('exams-type_delete',2,'Exams type|delete',NULL,NULL,1734430605,1734430605),('exams-type_index',2,'Exams type|index',NULL,NULL,1734430605,1734430605),('exams-type_update',2,'Exams type|update',NULL,NULL,1734430605,1734430605),('exams-type_view',2,'Exams type|view',NULL,NULL,1734430605,1734430605),('exam_allotment',2,'Exam|allotment',NULL,NULL,1734430604,1734430604),('exam_create',2,'Exam|create',NULL,NULL,1734430604,1734430604),('exam_delete',2,'Exam|delete',NULL,NULL,1734430604,1734430604),('exam_exam-check',2,'Exam|exam check',NULL,NULL,1734430604,1734430604),('exam_exam-finish',2,'Exam|exam finish',NULL,NULL,1734430604,1734430604),('exam_exam-notify',2,'Exam|exam notify',NULL,NULL,1734430604,1734430604),('exam_exam-teacher-attach',2,'Exam|exam teacher attach',NULL,NULL,1734430604,1734430604),('exam_index',2,'Exam|index',NULL,NULL,1734430604,1734430604),('exam_update',2,'Exam|update',NULL,NULL,1734430604,1734430604),('exam_view',2,'Exam|view',NULL,NULL,1734430604,1734430604),('excel_ik-excel',2,'Excel|ik excel',NULL,NULL,1734430605,1734430605),('faculty_create',2,'Faculty|create',NULL,NULL,1734430605,1734430605),('faculty_delete',2,'Faculty|delete',NULL,NULL,1734430605,1734430605),('faculty_index',2,'Faculty|index',NULL,NULL,1734430605,1734430605),('faculty_update',2,'Faculty|update',NULL,NULL,1734430605,1734430605),('faculty_user-access',2,'Faculty|user access',NULL,NULL,1734430605,1734430605),('faculty_view',2,'Faculty|view',NULL,NULL,1734430605,1734430605),('final-exam-test-start_add-ball',2,'Final exam test start|add ball',NULL,NULL,1734430605,1734430605),('final-exam-test-start_finish',2,'Final exam test start|finish',NULL,NULL,1734430605,1734430605),('final-exam-test-start_get',2,'Final exam test start|get',NULL,NULL,1734430605,1734430605),('final-exam-test-start_student-update',2,'Final exam test start|student update',NULL,NULL,1734430605,1734430605),('final-exam-test-start_time',2,'Final exam test start|time',NULL,NULL,1734430605,1734430605),('final-exam-test-start_update',2,'Final exam test start|update',NULL,NULL,1734430605,1734430605),('final-exam-test-start_view',2,'Final exam test start|view',NULL,NULL,1734430605,1734430605),('final-exam-test_add',2,'Final exam test|add',NULL,NULL,1734430605,1734430605),('final-exam-test_index',2,'Final exam test|index',NULL,NULL,1734430605,1734430605),('final-exam-test_update',2,'Final exam test|update',NULL,NULL,1734430605,1734430605),('final-exam_all-confirm',2,'Final exam|all confirm',NULL,NULL,1734430605,1734430605),('final-exam_confirm',2,'Final exam|confirm',NULL,NULL,1734430605,1734430605),('final-exam_confirm-dean',2,'Final exam|confirm dean',NULL,NULL,1734430605,1734430605),('final-exam_confirm-mudir',2,'Final exam|confirm mudir',NULL,NULL,1734430605,1734430605),('final-exam_confirm-two',2,'Final exam|confirm two',NULL,NULL,1734430605,1734430605),('final-exam_create',2,'Final exam|create',NULL,NULL,1734430605,1734430605),('final-exam_delete',2,'Final exam|delete',NULL,NULL,1734430605,1734430605),('final-exam_edu-type-update',2,'Final exam|edu type update',NULL,NULL,1734430605,1734430605),('final-exam_in-charge',2,'Final exam|in charge',NULL,NULL,1734430605,1734430605),('final-exam_index',2,'Final exam|index',NULL,NULL,1734430605,1734430605),('final-exam_last-confirm',2,'Final exam|last confirm',NULL,NULL,1734430605,1734430605),('final-exam_update',2,'Final exam|update',NULL,NULL,1734430605,1734430605),('final-exam_view',2,'Final exam|view',NULL,NULL,1734430605,1734430605),('get-info_academik-reference',2,'Get info|academik reference',NULL,NULL,1734430605,1734430605),('group_create',2,'Group|create',NULL,NULL,1734430605,1734430605),('group_delete',2,'Group|delete',NULL,NULL,1734430605,1734430605),('group_group',2,'Group|group',NULL,NULL,1734430605,1734430605),('group_index',2,'Group|index',NULL,NULL,1734430605,1734430605),('group_update',2,'Group|update',NULL,NULL,1734430605,1734430605),('group_view',2,'Group|view',NULL,NULL,1734430605,1734430605),('hr',1,'hr',NULL,NULL,1734413788,1734413788),('ik-student-bot_bot',2,'Ik student bot|bot',NULL,NULL,1734430605,1734430605),('important-level_create',2,'Important level|create',NULL,NULL,1734430605,1734430605),('important-level_delete',2,'Important level|delete',NULL,NULL,1734430605,1734430605),('important-level_index',2,'Important level|index',NULL,NULL,1734430605,1734430605),('important-level_update',2,'Important level|update',NULL,NULL,1734430605,1734430605),('important-level_view',2,'Important level|view',NULL,NULL,1734430605,1734430605),('kafedra_create',2,'Kafedra|create',NULL,NULL,1734430605,1734430605),('kafedra_delete',2,'Kafedra|delete',NULL,NULL,1734430605,1734430605),('kafedra_index',2,'Kafedra|index',NULL,NULL,1734430605,1734430605),('kafedra_update',2,'Kafedra|update',NULL,NULL,1734430605,1734430605),('kafedra_user-access',2,'Kafedra|user access',NULL,NULL,1734430605,1734430605),('kafedra_view',2,'Kafedra|view',NULL,NULL,1734430605,1734430605),('languages_create',2,'Languages|create',NULL,NULL,1734430605,1734430605),('languages_delete',2,'Languages|delete',NULL,NULL,1734430605,1734430605),('languages_index',2,'Languages|index',NULL,NULL,1734430605,1734430605),('languages_update',2,'Languages|update',NULL,NULL,1734430605,1734430605),('languages_view',2,'Languages|view',NULL,NULL,1734430605,1734430605),('lang_create',2,'Lang|create',NULL,NULL,1734430605,1734430605),('lang_delete',2,'Lang|delete',NULL,NULL,1734430605,1734430605),('lang_index',2,'Lang|index',NULL,NULL,1734430605,1734430605),('lang_update',2,'Lang|update',NULL,NULL,1734430605,1734430605),('lang_view',2,'Lang|view',NULL,NULL,1734430605,1734430605),('letter-forward-item_create',2,'Letter forward item|create',NULL,NULL,1734430605,1734430605),('letter-forward-item_delete',2,'Letter forward item|delete',NULL,NULL,1734430605,1734430605),('letter-forward-item_index',2,'Letter forward item|index',NULL,NULL,1734430605,1734430605),('letter-forward-item_update',2,'Letter forward item|update',NULL,NULL,1734430605,1734430605),('letter-forward-item_view',2,'Letter forward item|view',NULL,NULL,1734430605,1734430605),('letter-forward_create',2,'Letter forward|create',NULL,NULL,1734430605,1734430605),('letter-forward_delete',2,'Letter forward|delete',NULL,NULL,1734430605,1734430605),('letter-forward_index',2,'Letter forward|index',NULL,NULL,1734430605,1734430605),('letter-forward_update',2,'Letter forward|update',NULL,NULL,1734430605,1734430605),('letter-forward_view',2,'Letter forward|view',NULL,NULL,1734430605,1734430605),('letter-outgoing_create',2,'Letter outgoing|create',NULL,NULL,1734430606,1734430606),('letter-outgoing_delete',2,'Letter outgoing|delete',NULL,NULL,1734430606,1734430606),('letter-outgoing_index',2,'Letter outgoing|index',NULL,NULL,1734430606,1734430606),('letter-outgoing_is-ok',2,'Letter outgoing|is ok',NULL,NULL,1734430606,1734430606),('letter-outgoing_update',2,'Letter outgoing|update',NULL,NULL,1734430606,1734430606),('letter-outgoing_view',2,'Letter outgoing|view',NULL,NULL,1734430606,1734430606),('letter-reply_create',2,'Letter reply|create',NULL,NULL,1734430606,1734430606),('letter-reply_delete',2,'Letter reply|delete',NULL,NULL,1734430606,1734430606),('letter-reply_index',2,'Letter reply|index',NULL,NULL,1734430606,1734430606),('letter-reply_is-ok',2,'Letter reply|is ok',NULL,NULL,1734430606,1734430606),('letter-reply_update',2,'Letter reply|update',NULL,NULL,1734430606,1734430606),('letter-reply_view',2,'Letter reply|view',NULL,NULL,1734430606,1734430606),('letter_create',2,'Letter|create',NULL,NULL,1734430605,1734430605),('letter_delete',2,'Letter|delete',NULL,NULL,1734430605,1734430605),('letter_delete-file',2,'Letter|delete file',NULL,NULL,1734430605,1734430605),('letter_index',2,'Letter|index',NULL,NULL,1734430605,1734430605),('letter_is-ok',2,'Letter|is ok',NULL,NULL,1734430605,1734430605),('letter_update',2,'Letter|update',NULL,NULL,1734430605,1734430605),('letter_view',2,'Letter|view',NULL,NULL,1734430605,1734430605),('mudir',1,'mudir',NULL,NULL,1734430608,1734430608),('nationality_create',2,'Nationality|create',NULL,NULL,1734430606,1734430606),('nationality_delete',2,'Nationality|delete',NULL,NULL,1734430606,1734430606),('nationality_index',2,'Nationality|index',NULL,NULL,1734430606,1734430606),('nationality_update',2,'Nationality|update',NULL,NULL,1734430606,1734430606),('nationality_view',2,'Nationality|view',NULL,NULL,1734430606,1734430606),('open-info_student-call-sheet',2,'Open info|student call sheet',NULL,NULL,1734430606,1734430606),('option_create',2,'Option|create',NULL,NULL,1734430606,1734430606),('option_delete',2,'Option|delete',NULL,NULL,1734430606,1734430606),('option_index',2,'Option|index',NULL,NULL,1734430606,1734430606),('option_update',2,'Option|update',NULL,NULL,1734430606,1734430606),('option_view',2,'Option|view',NULL,NULL,1734430606,1734430606),('para_create',2,'Para|create',NULL,NULL,1734430606,1734430606),('para_delete',2,'Para|delete',NULL,NULL,1734430606,1734430606),('para_index',2,'Para|index',NULL,NULL,1734430606,1734430606),('para_update',2,'Para|update',NULL,NULL,1734430606,1734430606),('para_view',2,'Para|view',NULL,NULL,1734430606,1734430606),('partiya_create',2,'Partiya|create',NULL,NULL,1734430606,1734430606),('partiya_delete',2,'Partiya|delete',NULL,NULL,1734430606,1734430606),('partiya_index',2,'Partiya|index',NULL,NULL,1734430606,1734430606),('partiya_update',2,'Partiya|update',NULL,NULL,1734430606,1734430606),('partiya_view',2,'Partiya|view',NULL,NULL,1734430606,1734430606),('password_index',2,'Password|index',NULL,NULL,1734430606,1734430606),('password_update',2,'Password|update',NULL,NULL,1734430606,1734430606),('password_view',2,'Password|view',NULL,NULL,1734430606,1734430606),('prorector',1,'prorector',NULL,NULL,1734430608,1734430608),('rector',1,'Rector',NULL,NULL,1734413788,1734413788),('region_create',2,'Region|create',NULL,NULL,1734430606,1734430606),('region_delete',2,'Region|delete',NULL,NULL,1734430606,1734430606),('region_index',2,'Region|index',NULL,NULL,1734430606,1734430606),('region_update',2,'Region|update',NULL,NULL,1734430606,1734430606),('region_view',2,'Region|view',NULL,NULL,1734430606,1734430606),('residence-status_create',2,'Residence status|create',NULL,NULL,1734430606,1734430606),('residence-status_delete',2,'Residence status|delete',NULL,NULL,1734430606,1734430606),('residence-status_index',2,'Residence status|index',NULL,NULL,1734430606,1734430606),('residence-status_update',2,'Residence status|update',NULL,NULL,1734430606,1734430606),('residence-status_view',2,'Residence status|view',NULL,NULL,1734430606,1734430606),('room-ip_create',2,'Room ip|create',NULL,NULL,1734430606,1734430606),('room-ip_delete',2,'Room ip|delete',NULL,NULL,1734430606,1734430606),('room-ip_excel-import',2,'Room ip|excel import',NULL,NULL,1734430606,1734430606),('room-ip_index',2,'Room ip|index',NULL,NULL,1734430606,1734430606),('room-ip_update',2,'Room ip|update',NULL,NULL,1734430606,1734430606),('room-ip_view',2,'Room ip|view',NULL,NULL,1734430606,1734430606),('room-type_create',2,'Room type|create',NULL,NULL,1734430606,1734430606),('room-type_delete',2,'Room type|delete',NULL,NULL,1734430606,1734430606),('room-type_index',2,'Room type|index',NULL,NULL,1734430606,1734430606),('room-type_update',2,'Room type|update',NULL,NULL,1734430606,1734430606),('room-type_view',2,'Room type|view',NULL,NULL,1734430606,1734430606),('room_create',2,'Room|create',NULL,NULL,1734430606,1734430606),('room_delete',2,'Room|delete',NULL,NULL,1734430606,1734430606),('room_free',2,'Room|free',NULL,NULL,1734430606,1734430606),('room_free-exam',2,'Room|free exam',NULL,NULL,1734430606,1734430606),('room_index',2,'Room|index',NULL,NULL,1734430606,1734430606),('room_update',2,'Room|update',NULL,NULL,1734430606,1734430606),('room_view',2,'Room|view',NULL,NULL,1734430606,1734430606),('semestr_create',2,'Semestr|create',NULL,NULL,1734430606,1734430606),('semestr_delete',2,'Semestr|delete',NULL,NULL,1734430606,1734430606),('semestr_index',2,'Semestr|index',NULL,NULL,1734430606,1734430606),('semestr_update',2,'Semestr|update',NULL,NULL,1734430606,1734430606),('semestr_view',2,'Semestr|view',NULL,NULL,1734430606,1734430606),('social-category_create',2,'Social category|create',NULL,NULL,1734430606,1734430606),('social-category_delete',2,'Social category|delete',NULL,NULL,1734430606,1734430606),('social-category_index',2,'Social category|index',NULL,NULL,1734430606,1734430606),('social-category_update',2,'Social category|update',NULL,NULL,1734430606,1734430606),('social-category_view',2,'Social category|view',NULL,NULL,1734430606,1734430606),('statistic_checking',2,'Statistic|checking',NULL,NULL,1734430606,1734430606),('statistic_checking-chala',2,'Statistic|checking chala',NULL,NULL,1734430606,1734430606),('statistic_edu-plan',2,'Statistic|edu plan',NULL,NULL,1734430606,1734430606),('statistic_empolyee',2,'Statistic|empolyee',NULL,NULL,1734430606,1734430606),('statistic_exam-checking',2,'Statistic|exam checking',NULL,NULL,1734430606,1734430606),('statistic_faculty-statistic',2,'Statistic|faculty statistic',NULL,NULL,1734430606,1734430606),('statistic_home-page',2,'Statistic|home page',NULL,NULL,1734430606,1734430606),('statistic_kafedra',2,'Statistic|kafedra',NULL,NULL,1734430606,1734430606),('statistic_kpi-content-store',2,'Statistic|kpi content store',NULL,NULL,1734430606,1734430606),('statistic_kpi-survey-store',2,'Statistic|kpi survey store',NULL,NULL,1734430606,1734430606),('statistic_kpi-survey-store00',2,'Statistic|kpi survey store00',NULL,NULL,1734430606,1734430606),('statistic_statistic',2,'Statistic|statistic',NULL,NULL,1734430606,1734430606),('statistic_student-count-by-faculty',2,'Statistic|student count by faculty',NULL,NULL,1734430606,1734430606),('statistic_students',2,'Statistic|students',NULL,NULL,1734430606,1734430606),('student',1,'Student',NULL,NULL,1734413788,1734413788),('student-attend_by-date',2,'Student attend|by date',NULL,NULL,1734430606,1734430606),('student-attend_create',2,'Student attend|create',NULL,NULL,1734430606,1734430606),('student-attend_delete',2,'Student attend|delete',NULL,NULL,1734430606,1734430606),('student-attend_index',2,'Student attend|index',NULL,NULL,1734430606,1734430606),('student-attend_update',2,'Student attend|update',NULL,NULL,1734430606,1734430606),('student-attend_view',2,'Student attend|view',NULL,NULL,1734430606,1734430606),('student-category_create',2,'Student category|create',NULL,NULL,1734430606,1734430606),('student-category_delete',2,'Student category|delete',NULL,NULL,1734430606,1734430606),('student-category_index',2,'Student category|index',NULL,NULL,1734430606,1734430606),('student-category_update',2,'Student category|update',NULL,NULL,1734430606,1734430606),('student-category_view',2,'Student category|view',NULL,NULL,1734430606,1734430606),('student-group_create',2,'Student group|create',NULL,NULL,1734430607,1734430607),('student-group_delete',2,'Student group|delete',NULL,NULL,1734430607,1734430607),('student-group_index',2,'Student group|index',NULL,NULL,1734430606,1734430606),('student-group_update',2,'Student group|update',NULL,NULL,1734430607,1734430607),('student-mark_create',2,'Student mark|create',NULL,NULL,1734430607,1734430607),('student-mark_delete',2,'Student mark|delete',NULL,NULL,1734430607,1734430607),('student-mark_exam',2,'Student mark|exam',NULL,NULL,1734430607,1734430607),('student-mark_final-exam',2,'Student mark|final exam',NULL,NULL,1734430607,1734430607),('student-mark_get',2,'Student mark|get',NULL,NULL,1734430607,1734430607),('student-mark_index',2,'Student mark|index',NULL,NULL,1734430607,1734430607),('student-mark_student-mark-update',2,'Student mark|student mark update',NULL,NULL,1734430607,1734430607),('student-mark_view',2,'Student mark|view',NULL,NULL,1734430607,1734430607),('student-semestr-subject_index',2,'Student semestr subject|index',NULL,NULL,1734430607,1734430607),('student-topic-permission_create',2,'Student topic permission|create',NULL,NULL,1734430607,1734430607),('student-topic-permission_delete',2,'Student topic permission|delete',NULL,NULL,1734430607,1734430607),('student-topic-permission_index',2,'Student topic permission|index',NULL,NULL,1734430607,1734430607),('student-topic-permission_permission',2,'Student topic permission|permission',NULL,NULL,1734430607,1734430607),('student-topic-permission_update',2,'Student topic permission|update',NULL,NULL,1734430607,1734430607),('student-topic-permission_view',2,'Student topic permission|view',NULL,NULL,1734430607,1734430607),('student-vedomst_delete',2,'Student vedomst|delete',NULL,NULL,1734430607,1734430607),('student-vedomst_index',2,'Student vedomst|index',NULL,NULL,1734430607,1734430607),('student-vedomst_update',2,'Student vedomst|update',NULL,NULL,1734430607,1734430607),('student_by-pinfl',2,'Student|by pinfl',NULL,NULL,1734430606,1734430606),('student_create',2,'Student|create',NULL,NULL,1734430606,1734430606),('student_delete',2,'Student|delete',NULL,NULL,1734430606,1734430606),('student_export',2,'Student|export',NULL,NULL,1734430606,1734430606),('student_get',2,'Student|get',NULL,NULL,1734430606,1734430606),('student_import',2,'Student|import',NULL,NULL,1734430606,1734430606),('student_index',2,'Student|index',NULL,NULL,1734430606,1734430606),('student_me',2,'Student|me',NULL,NULL,1734430606,1734430606),('student_missed-hours',2,'Student|missed hours',NULL,NULL,1734430606,1734430606),('student_read',2,'Student|read',NULL,NULL,1734430606,1734430606),('student_statistic-attend',2,'Student|statistic attend',NULL,NULL,1734430606,1734430606),('student_student11',2,'Student|student11',NULL,NULL,1734430606,1734430606),('student_tutor',2,'Student|tutor',NULL,NULL,1734430606,1734430606),('student_type',2,'Student|type',NULL,NULL,1734430606,1734430606),('student_update',2,'Student|update',NULL,NULL,1734430606,1734430606),('student_view',2,'Student|view',NULL,NULL,1734430606,1734430606),('subject-category_create',2,'Subject category|create',NULL,NULL,1734430607,1734430607),('subject-category_delete',2,'Subject category|delete',NULL,NULL,1734430607,1734430607),('subject-category_index',2,'Subject category|index',NULL,NULL,1734430607,1734430607),('subject-category_update',2,'Subject category|update',NULL,NULL,1734430607,1734430607),('subject-category_view',2,'Subject category|view',NULL,NULL,1734430607,1734430607),('subject-content_create',2,'Subject content|create',NULL,NULL,1734430607,1734430607),('subject-content_delete',2,'Subject content|delete',NULL,NULL,1734430607,1734430607),('subject-content_index',2,'Subject content|index',NULL,NULL,1734430607,1734430607),('subject-content_order',2,'Subject content|order',NULL,NULL,1734430607,1734430607),('subject-content_trash',2,'Subject content|trash',NULL,NULL,1734430607,1734430607),('subject-content_trash-delete',2,'Subject content|trash delete',NULL,NULL,1734430607,1734430607),('subject-content_types',2,'Subject content|types',NULL,NULL,1734430607,1734430607),('subject-content_update',2,'Subject content|update',NULL,NULL,1734430607,1734430607),('subject-content_view',2,'Subject content|view',NULL,NULL,1734430607,1734430607),('subject-semestr_create',2,'Subject semestr|create',NULL,NULL,1734430607,1734430607),('subject-semestr_delete',2,'Subject semestr|delete',NULL,NULL,1734430607,1734430607),('subject-semestr_index',2,'Subject semestr|index',NULL,NULL,1734430607,1734430607),('subject-semestr_update',2,'Subject semestr|update',NULL,NULL,1734430607,1734430607),('subject-semestr_view',2,'Subject semestr|view',NULL,NULL,1734430607,1734430607),('subject-topic-test_answer',2,'Subject topic test|answer',NULL,NULL,1734430607,1734430607),('subject-topic-test_finish',2,'Subject topic test|finish',NULL,NULL,1734430607,1734430607),('subject-topic-test_index',2,'Subject topic test|index',NULL,NULL,1734430607,1734430607),('subject-topic-test_topic-test',2,'Subject topic test|topic test',NULL,NULL,1734430607,1734430607),('subject-topic_create',2,'Subject topic|create',NULL,NULL,1734430607,1734430607),('subject-topic_delete',2,'Subject topic|delete',NULL,NULL,1734430607,1734430607),('subject-topic_export',2,'Subject topic|export',NULL,NULL,1734430607,1734430607),('subject-topic_index',2,'Subject topic|index',NULL,NULL,1734430607,1734430607),('subject-topic_order',2,'Subject topic|order',NULL,NULL,1734430607,1734430607),('subject-topic_update',2,'Subject topic|update',NULL,NULL,1734430607,1734430607),('subject-topic_view',2,'Subject topic|view',NULL,NULL,1734430607,1734430607),('subject-type_create',2,'Subject type|create',NULL,NULL,1734430607,1734430607),('subject-type_delete',2,'Subject type|delete',NULL,NULL,1734430607,1734430607),('subject-type_index',2,'Subject type|index',NULL,NULL,1734430607,1734430607),('subject-type_update',2,'Subject type|update',NULL,NULL,1734430607,1734430607),('subject-type_view',2,'Subject type|view',NULL,NULL,1734430607,1734430607),('subject_create',2,'Subject|create',NULL,NULL,1734430607,1734430607),('subject_delete',2,'Subject|delete',NULL,NULL,1734430607,1734430607),('subject_index',2,'Subject|index',NULL,NULL,1734430607,1734430607),('subject_update',2,'Subject|update',NULL,NULL,1734430607,1734430607),('subject_view',2,'Subject|view',NULL,NULL,1734430607,1734430607),('teacher',1,'teacher',NULL,NULL,1734413788,1734413788),('teacher-access_content',2,'Teacher access|content',NULL,NULL,1734430607,1734430607),('teacher-access_create',2,'Teacher access|create',NULL,NULL,1734430607,1734430607),('teacher-access_delete',2,'Teacher access|delete',NULL,NULL,1734430607,1734430607),('teacher-access_free',2,'Teacher access|free',NULL,NULL,1734430607,1734430607),('teacher-access_free-exam',2,'Teacher access|free exam',NULL,NULL,1734430607,1734430607),('teacher-access_get',2,'Teacher access|get',NULL,NULL,1734430607,1734430607),('teacher-access_index',2,'Teacher access|index',NULL,NULL,1734430607,1734430607),('teacher-access_update',2,'Teacher access|update',NULL,NULL,1734430607,1734430607),('teacher-access_view',2,'Teacher access|view',NULL,NULL,1734430607,1734430607),('test_all-delete',2,'Test|all delete',NULL,NULL,1734430607,1734430607),('test_create',2,'Test|create',NULL,NULL,1734430607,1734430607),('test_delete',2,'Test|delete',NULL,NULL,1734430607,1734430607),('test_excel-import',2,'Test|excel import',NULL,NULL,1734430607,1734430607),('test_index',2,'Test|index',NULL,NULL,1734430607,1734430607),('test_is-check',2,'Test|is check',NULL,NULL,1734430607,1734430607),('test_update',2,'Test|update',NULL,NULL,1734430607,1734430607),('test_view',2,'Test|view',NULL,NULL,1734430607,1734430607),('time-table1_create',2,'Time table1|create',NULL,NULL,1734430607,1734430607),('time-table1_create-add-group',2,'Time table1|create add group',NULL,NULL,1734430607,1734430607),('time-table1_delete',2,'Time table1|delete',NULL,NULL,1734430607,1734430607),('time-table1_index',2,'Time table1|index',NULL,NULL,1734430607,1734430607),('time-table1_parent-null',2,'Time table1|parent null',NULL,NULL,1734430607,1734430607),('time-table1_update',2,'Time table1|update',NULL,NULL,1734430607,1734430607),('time-table1_view',2,'Time table1|view',NULL,NULL,1734430607,1734430607),('time-table1_viewww',2,'Time table1|viewww',NULL,NULL,1734430607,1734430607),('timetable-attend_attend-student',2,'Timetable attend|attend student',NULL,NULL,1734430607,1734430607),('timetable-attend_create',2,'Timetable attend|create',NULL,NULL,1734430607,1734430607),('timetable-attend_get',2,'Timetable attend|get',NULL,NULL,1734430607,1734430607),('timetable-attend_index',2,'Timetable attend|index',NULL,NULL,1734430607,1734430607),('timetable-attend_student-reason',2,'Timetable attend|student reason',NULL,NULL,1734430607,1734430607),('timetable-attend_update',2,'Timetable attend|update',NULL,NULL,1734430607,1734430607),('timetable-date_attend',2,'Timetable date|attend',NULL,NULL,1734430608,1734430608),('timetable-date_create',2,'Timetable date|create',NULL,NULL,1734430608,1734430608),('timetable-date_delete',2,'Timetable date|delete',NULL,NULL,1734430608,1734430608),('timetable-date_filter',2,'Timetable date|filter',NULL,NULL,1734430608,1734430608),('timetable-date_get',2,'Timetable date|get',NULL,NULL,1734430608,1734430608),('timetable-date_get-date',2,'Timetable date|get date',NULL,NULL,1734430608,1734430608),('timetable-date_index',2,'Timetable date|index',NULL,NULL,1734430608,1734430608),('timetable-date_teacher',2,'Timetable date|teacher',NULL,NULL,1734430608,1734430608),('timetable-reason_create',2,'Timetable reason|create',NULL,NULL,1734430608,1734430608),('timetable-reason_delete',2,'Timetable reason|delete',NULL,NULL,1734430608,1734430608),('timetable-reason_index',2,'Timetable reason|index',NULL,NULL,1734430608,1734430608),('timetable-reason_update',2,'Timetable reason|update',NULL,NULL,1734430608,1734430608),('timetable_add-day',2,'Timetable|add day',NULL,NULL,1734430607,1734430607),('timetable_add-group',2,'Timetable|add group',NULL,NULL,1734430607,1734430607),('timetable_attend',2,'Timetable|attend',NULL,NULL,1734430608,1734430608),('timetable_create',2,'Timetable|create',NULL,NULL,1734430607,1734430607),('timetable_delete',2,'Timetable|delete',NULL,NULL,1734430607,1734430607),('timetable_delete-one',2,'Timetable|delete one',NULL,NULL,1734430607,1734430607),('timetable_edu-plan',2,'Timetable|edu plan',NULL,NULL,1734430607,1734430607),('timetable_edu-semestr',2,'Timetable|edu semestr',NULL,NULL,1734430608,1734430608),('timetable_index',2,'Timetable|index',NULL,NULL,1734430607,1734430607),('timetable_student-type',2,'Timetable|student type',NULL,NULL,1734430608,1734430608),('timetable_teacher-topic',2,'Timetable|teacher topic',NULL,NULL,1734430608,1734430608),('timetable_update',2,'Timetable|update',NULL,NULL,1734430607,1734430607),('timetable_user',2,'Timetable|user',NULL,NULL,1734430607,1734430607),('timetable_view',2,'Timetable|view',NULL,NULL,1734430607,1734430607),('tutor',1,'tutor',NULL,NULL,1734430608,1734430608),('user-access-type_create',2,'User access type|create',NULL,NULL,1734430608,1734430608),('user-access-type_delete',2,'User access type|delete',NULL,NULL,1734430608,1734430608),('user-access-type_index',2,'User access type|index',NULL,NULL,1734430608,1734430608),('user-access-type_update',2,'User access type|update',NULL,NULL,1734430608,1734430608),('user-access-type_view',2,'User access type|view',NULL,NULL,1734430608,1734430608),('user-access_create',2,'User access|create',NULL,NULL,1734430608,1734430608),('user-access_delete',2,'User access|delete',NULL,NULL,1734430608,1734430608),('user-access_index',2,'User access|index',NULL,NULL,1734430608,1734430608),('user-access_view',2,'User access|view',NULL,NULL,1734430608,1734430608),('user_all-file-removes',2,'User|all file removes',NULL,NULL,1734430608,1734430608),('user_create',2,'User|create',NULL,NULL,1734430608,1734430608),('user_delete',2,'User|delete',NULL,NULL,1734430608,1734430608),('user_get',2,'User|get',NULL,NULL,1734430608,1734430608),('user_index',2,'User|index',NULL,NULL,1734430608,1734430608),('user_login-history',2,'User|login history',NULL,NULL,1734430608,1734430608),('user_logout',2,'User|logout',NULL,NULL,1734430608,1734430608),('user_me',2,'User|me',NULL,NULL,1734430608,1734430608),('user_self',2,'User|self',NULL,NULL,1734430608,1734430608),('user_selfget',2,'User|selfget',NULL,NULL,1734430608,1734430608),('user_status-list',2,'User|status list',NULL,NULL,1734430608,1734430608),('user_update',2,'User|update',NULL,NULL,1734430608,1734430608),('user_view',2,'User|view',NULL,NULL,1734430608,1734430608),('week_create',2,'Week|create',NULL,NULL,1734430608,1734430608),('week_delete',2,'Week|delete',NULL,NULL,1734430608,1734430608),('week_index',2,'Week|index',NULL,NULL,1734430608,1734430608),('week_update',2,'Week|update',NULL,NULL,1734430608,1734430608),('week_view',2,'Week|view',NULL,NULL,1734430608,1734430608),('work-load_create',2,'Work load|create',NULL,NULL,1734430608,1734430608),('work-load_delete',2,'Work load|delete',NULL,NULL,1734430608,1734430608),('work-load_index',2,'Work load|index',NULL,NULL,1734430608,1734430608),('work-load_update',2,'Work load|update',NULL,NULL,1734430608,1734430608),('work-load_view',2,'Work load|view',NULL,NULL,1734430608,1734430608),('work-rate_create',2,'Work rate|create',NULL,NULL,1734430608,1734430608),('work-rate_delete',2,'Work rate|delete',NULL,NULL,1734430608,1734430608),('work-rate_index',2,'Work rate|index',NULL,NULL,1734430608,1734430608),('work-rate_update',2,'Work rate|update',NULL,NULL,1734430608,1734430608),('work-rate_view',2,'Work rate|view',NULL,NULL,1734430608,1734430608);
/*!40000 ALTER TABLE `auth_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_item_child`
--

LOCK TABLES `auth_item_child` WRITE;
/*!40000 ALTER TABLE `auth_item_child` DISABLE KEYS */;
INSERT INTO `auth_item_child` VALUES ('admin','academic-degree_create'),('admin','academic-degree_delete'),('admin','academic-degree_index'),('admin','academic-degree_update'),('admin','academic-degree_view'),('admin','access-control_create-permission'),('admin','access-control_create-role'),('admin','access-control_delete-role'),('admin','access-control_permissions'),('admin','access-control_role-permissions'),('admin','access-control_roles'),('admin','access-control_update-role'),('admin','action-log_index'),('admin','action-log_view'),('admin','area_create'),('admin','area_delete'),('admin','area_index'),('admin','area_update'),('admin','area_view'),('admin','attend-reason_cancellation'),('admin','attend-reason_confirm'),('admin','attend-reason_create'),('admin','attend-reason_delete'),('admin','attend-reason_index'),('admin','attend-reason_update'),('admin','attend-reason_view'),('admin','attend_create'),('admin','attend_delete'),('admin','attend_index'),('admin','attend_update'),('admin','attend_view'),('admin','building_create'),('admin','building_delete'),('admin','building_index'),('admin','building_update'),('admin','building_view'),('admin','category-of-cohabitant_create'),('admin','category-of-cohabitant_delete'),('admin','category-of-cohabitant_index'),('admin','category-of-cohabitant_update'),('admin','category-of-cohabitant_view'),('admin','citizenship_create'),('admin','citizenship_delete'),('admin','citizenship_index'),('admin','citizenship_update'),('admin','citizenship_view'),('admin','commands-type_create'),('admin','commands-type_delete'),('admin','commands-type_index'),('admin','commands-type_update'),('admin','commands-type_view'),('admin','commands_create'),('admin','commands_delete'),('admin','commands_index'),('admin','commands_update'),('admin','commands_view'),('admin','country_index'),('admin','country_view'),('admin','course_create'),('admin','course_delete'),('admin','course_index'),('admin','course_update'),('admin','course_view'),('admin','degree-info_create'),('admin','degree-info_delete'),('admin','degree-info_index'),('admin','degree-info_update'),('admin','degree-info_view'),('admin','degree_create'),('admin','degree_delete'),('admin','degree_index'),('admin','degree_update'),('admin','degree_view'),('admin','department_create'),('admin','department_delete'),('admin','department_index'),('admin','department_types'),('admin','department_update'),('admin','department_user-access'),('admin','department_view'),('admin','diploma-type_create'),('admin','diploma-type_delete'),('admin','diploma-type_index'),('admin','diploma-type_update'),('admin','diploma-type_view'),('admin','direction_create'),('admin','direction_delete'),('admin','direction_index'),('admin','direction_update'),('admin','direction_view'),('admin','document-decree_command-type'),('admin','document-decree_confirm'),('admin','document-decree_create'),('admin','document-decree_delete'),('admin','document-decree_hr-update'),('admin','document-decree_index'),('admin','document-decree_sign'),('admin','document-decree_signature-update'),('admin','document-decree_update'),('admin','document-decree_view'),('admin','document-execution_create'),('admin','document-execution_delete'),('admin','document-execution_index'),('admin','document-execution_update'),('admin','document-execution_view'),('admin','document-notification_command-type'),('admin','document-notification_confirm'),('admin','document-notification_create'),('admin','document-notification_delete'),('admin','document-notification_hr-update'),('admin','document-notification_index'),('admin','document-notification_sign'),('admin','document-notification_signature-update'),('admin','document-notification_update'),('admin','document-notification_view'),('admin','document-type_create'),('admin','document-type_delete'),('admin','document-type_index'),('admin','document-type_update'),('admin','document-type_view'),('admin','document-weight_create'),('admin','document-weight_delete'),('admin','document-weight_index'),('admin','document-weight_update'),('admin','document-weight_view'),('admin','document_create'),('admin','document_delete'),('admin','document_delete-file'),('admin','document_index'),('admin','document_update'),('admin','document_view'),('admin','edu-form_create'),('admin','edu-form_delete'),('admin','edu-form_index'),('admin','edu-form_update'),('admin','edu-form_view'),('admin','edu-plan_create'),('admin','edu-plan_delete'),('admin','edu-plan_index'),('admin','edu-plan_update'),('admin','edu-plan_view'),('admin','edu-semestr-subject-category-time_index'),('admin','edu-semestr-subject_create'),('admin','edu-semestr-subject_delete'),('admin','edu-semestr-subject_index'),('admin','edu-semestr-subject_update'),('admin','edu-semestr-subject_view'),('admin','edu-semestr_create'),('admin','edu-semestr_delete'),('admin','edu-semestr_index'),('admin','edu-semestr_student-subject-merge'),('admin','edu-semestr_update'),('admin','edu-semestr_view'),('admin','edu-type_create'),('admin','edu-type_delete'),('admin','edu-type_index'),('admin','edu-type_update'),('admin','edu-type_view'),('admin','edu-year_create'),('admin','edu-year_delete'),('admin','edu-year_index'),('admin','edu-year_update'),('admin','edu-year_view'),('admin','exam-control-student_check'),('admin','exam-control-student_create'),('admin','exam-control-student_delete'),('admin','exam-control-student_finish'),('admin','exam-control-student_index'),('admin','exam-control-student_rating'),('admin','exam-control-student_update'),('admin','exam-control-student_view'),('admin','exam-control_create'),('admin','exam-control_delete'),('admin','exam-control_index'),('admin','exam-control_update'),('admin','exam-control_view'),('admin','exam-questions_create'),('admin','exam-questions_delete'),('admin','exam-questions_index'),('admin','exam-questions_is-confirm'),('admin','exam-questions_update'),('admin','exam-questions_view'),('admin','exam-student-question_delete'),('admin','exam-student-question_index'),('admin','exam-student-question_update'),('admin','exam-student-question_update-ball'),('admin','exam-student-question_view'),('admin','exam-student_create'),('admin','exam-student_delete'),('admin','exam-student_finish'),('admin','exam-student_index'),('admin','exam-student_rating'),('admin','exam-student_update'),('admin','exam-student_view'),('admin','exam-test-option_create'),('admin','exam-test-option_delete'),('admin','exam-test-option_index'),('admin','exam-test-option_update'),('admin','exam-test-option_view'),('admin','exam-test-student-answer_delete'),('admin','exam-test-student-answer_designation'),('admin','exam-test-student-answer_index'),('admin','exam-test-student-answer_view'),('admin','exam-test_create'),('admin','exam-test_delete'),('admin','exam-test_excel-import'),('admin','exam-test_index'),('admin','exam-test_is-check'),('admin','exam-test_update'),('admin','exam-test_view'),('admin','exams-type_create'),('admin','exams-type_delete'),('admin','exams-type_index'),('admin','exams-type_update'),('admin','exams-type_view'),('admin','exam_allotment'),('admin','exam_create'),('admin','exam_delete'),('admin','exam_exam-check'),('admin','exam_exam-finish'),('admin','exam_exam-notify'),('admin','exam_exam-teacher-attach'),('admin','exam_index'),('admin','exam_update'),('admin','exam_view'),('admin','excel_ik-excel'),('admin','faculty_create'),('admin','faculty_delete'),('admin','faculty_index'),('admin','faculty_update'),('admin','faculty_user-access'),('admin','faculty_view'),('admin','final-exam-test-start_add-ball'),('admin','final-exam-test-start_finish'),('admin','final-exam-test-start_get'),('admin','final-exam-test-start_student-update'),('admin','final-exam-test-start_time'),('admin','final-exam-test-start_update'),('admin','final-exam-test-start_view'),('admin','final-exam-test_add'),('admin','final-exam-test_index'),('admin','final-exam-test_update'),('admin','final-exam_all-confirm'),('admin','final-exam_confirm'),('admin','final-exam_confirm-dean'),('admin','final-exam_confirm-mudir'),('admin','final-exam_confirm-two'),('admin','final-exam_create'),('admin','final-exam_delete'),('admin','final-exam_edu-type-update'),('admin','final-exam_in-charge'),('admin','final-exam_index'),('admin','final-exam_last-confirm'),('admin','final-exam_update'),('admin','final-exam_view'),('admin','get-info_academik-reference'),('admin','group_create'),('admin','group_delete'),('admin','group_group'),('admin','group_index'),('admin','group_update'),('admin','group_view'),('admin','ik-student-bot_bot'),('admin','important-level_create'),('admin','important-level_delete'),('admin','important-level_index'),('admin','important-level_update'),('admin','important-level_view'),('admin','kafedra_create'),('admin','kafedra_delete'),('admin','kafedra_index'),('admin','kafedra_update'),('admin','kafedra_user-access'),('admin','kafedra_view'),('admin','languages_create'),('admin','languages_delete'),('admin','languages_index'),('admin','languages_update'),('admin','languages_view'),('admin','lang_create'),('admin','lang_delete'),('admin','lang_index'),('admin','lang_update'),('admin','lang_view'),('admin','letter-forward-item_create'),('admin','letter-forward-item_delete'),('admin','letter-forward-item_index'),('admin','letter-forward-item_update'),('admin','letter-forward-item_view'),('admin','letter-forward_create'),('admin','letter-forward_delete'),('admin','letter-forward_index'),('admin','letter-forward_update'),('admin','letter-forward_view'),('admin','letter-outgoing_create'),('admin','letter-outgoing_delete'),('admin','letter-outgoing_index'),('admin','letter-outgoing_is-ok'),('admin','letter-outgoing_update'),('admin','letter-outgoing_view'),('admin','letter-reply_create'),('admin','letter-reply_delete'),('admin','letter-reply_index'),('admin','letter-reply_is-ok'),('admin','letter-reply_update'),('admin','letter-reply_view'),('admin','letter_create'),('admin','letter_delete'),('admin','letter_delete-file'),('admin','letter_index'),('admin','letter_is-ok'),('admin','letter_update'),('admin','letter_view'),('admin','nationality_create'),('admin','nationality_delete'),('admin','nationality_index'),('admin','nationality_update'),('admin','nationality_view'),('admin','open-info_student-call-sheet'),('admin','option_create'),('admin','option_delete'),('admin','option_index'),('admin','option_update'),('admin','option_view'),('admin','para_create'),('admin','para_delete'),('admin','para_index'),('admin','para_update'),('admin','para_view'),('admin','partiya_create'),('admin','partiya_delete'),('admin','partiya_index'),('admin','partiya_update'),('admin','partiya_view'),('admin','password_index'),('admin','password_update'),('admin','password_view'),('admin','region_create'),('admin','region_delete'),('admin','region_index'),('admin','region_update'),('admin','region_view'),('admin','residence-status_create'),('admin','residence-status_delete'),('admin','residence-status_index'),('admin','residence-status_update'),('admin','residence-status_view'),('admin','room-ip_create'),('admin','room-ip_delete'),('admin','room-ip_excel-import'),('admin','room-ip_index'),('admin','room-ip_update'),('admin','room-ip_view'),('admin','room-type_create'),('admin','room-type_delete'),('admin','room-type_index'),('admin','room-type_update'),('admin','room-type_view'),('admin','room_create'),('admin','room_delete'),('admin','room_free'),('admin','room_free-exam'),('admin','room_index'),('admin','room_update'),('admin','room_view'),('admin','semestr_create'),('admin','semestr_delete'),('admin','semestr_index'),('admin','semestr_update'),('admin','semestr_view'),('admin','social-category_create'),('admin','social-category_delete'),('admin','social-category_index'),('admin','social-category_update'),('admin','social-category_view'),('admin','statistic_checking'),('admin','statistic_checking-chala'),('admin','statistic_edu-plan'),('admin','statistic_empolyee'),('admin','statistic_exam-checking'),('admin','statistic_faculty-statistic'),('admin','statistic_home-page'),('admin','statistic_kafedra'),('admin','statistic_kpi-content-store'),('admin','statistic_kpi-survey-store'),('admin','statistic_kpi-survey-store00'),('admin','statistic_statistic'),('admin','statistic_student-count-by-faculty'),('admin','statistic_students'),('admin','student-attend_by-date'),('admin','student-attend_create'),('admin','student-attend_delete'),('admin','student-attend_index'),('admin','student-attend_update'),('admin','student-attend_view'),('admin','student-category_create'),('admin','student-category_delete'),('admin','student-category_index'),('admin','student-category_update'),('admin','student-category_view'),('admin','student-group_create'),('admin','student-group_delete'),('admin','student-group_index'),('admin','student-group_update'),('admin','student-mark_create'),('admin','student-mark_delete'),('admin','student-mark_exam'),('admin','student-mark_final-exam'),('admin','student-mark_get'),('admin','student-mark_index'),('admin','student-mark_student-mark-update'),('admin','student-mark_view'),('admin','student-semestr-subject_index'),('admin','student-topic-permission_create'),('admin','student-topic-permission_delete'),('admin','student-topic-permission_index'),('admin','student-topic-permission_permission'),('admin','student-topic-permission_update'),('admin','student-topic-permission_view'),('admin','student-vedomst_delete'),('admin','student-vedomst_index'),('admin','student-vedomst_update'),('admin','student_by-pinfl'),('admin','student_create'),('admin','student_delete'),('admin','student_export'),('admin','student_get'),('admin','student_import'),('admin','student_index'),('admin','student_me'),('admin','student_missed-hours'),('admin','student_read'),('admin','student_statistic-attend'),('admin','student_student11'),('admin','student_tutor'),('admin','student_type'),('admin','student_update'),('admin','student_view'),('admin','subject-category_create'),('admin','subject-category_delete'),('admin','subject-category_index'),('admin','subject-category_update'),('admin','subject-category_view'),('admin','subject-content_create'),('admin','subject-content_delete'),('admin','subject-content_index'),('admin','subject-content_order'),('admin','subject-content_trash'),('admin','subject-content_trash-delete'),('admin','subject-content_types'),('admin','subject-content_update'),('admin','subject-content_view'),('admin','subject-semestr_create'),('admin','subject-semestr_delete'),('admin','subject-semestr_index'),('admin','subject-semestr_update'),('admin','subject-semestr_view'),('admin','subject-topic-test_answer'),('admin','subject-topic-test_finish'),('admin','subject-topic-test_index'),('admin','subject-topic-test_topic-test'),('admin','subject-topic_create'),('admin','subject-topic_delete'),('admin','subject-topic_export'),('admin','subject-topic_index'),('admin','subject-topic_order'),('admin','subject-topic_update'),('admin','subject-topic_view'),('admin','subject-type_create'),('admin','subject-type_delete'),('admin','subject-type_index'),('admin','subject-type_update'),('admin','subject-type_view'),('admin','subject_create'),('admin','subject_delete'),('admin','subject_index'),('admin','subject_update'),('admin','subject_view'),('admin','teacher-access_content'),('admin','teacher-access_create'),('admin','teacher-access_delete'),('admin','teacher-access_free'),('admin','teacher-access_free-exam'),('admin','teacher-access_get'),('admin','teacher-access_index'),('admin','teacher-access_update'),('admin','teacher-access_view'),('admin','test_all-delete'),('admin','test_create'),('admin','test_delete'),('admin','test_excel-import'),('admin','test_index'),('admin','test_is-check'),('admin','test_update'),('admin','test_view'),('admin','time-table1_create'),('admin','time-table1_create-add-group'),('admin','time-table1_delete'),('admin','time-table1_index'),('admin','time-table1_parent-null'),('admin','time-table1_update'),('admin','time-table1_view'),('admin','time-table1_viewww'),('admin','timetable-attend_attend-student'),('admin','timetable-attend_create'),('admin','timetable-attend_get'),('admin','timetable-attend_index'),('admin','timetable-attend_student-reason'),('admin','timetable-attend_update'),('admin','timetable-date_attend'),('admin','timetable-date_create'),('admin','timetable-date_delete'),('admin','timetable-date_filter'),('admin','timetable-date_get'),('admin','timetable-date_get-date'),('admin','timetable-date_index'),('admin','timetable-date_teacher'),('admin','timetable-reason_create'),('admin','timetable-reason_delete'),('admin','timetable-reason_index'),('admin','timetable-reason_update'),('admin','timetable_add-day'),('admin','timetable_add-group'),('admin','timetable_attend'),('admin','timetable_create'),('admin','timetable_delete'),('admin','timetable_delete-one'),('admin','timetable_edu-plan'),('admin','timetable_edu-semestr'),('admin','timetable_index'),('admin','timetable_student-type'),('admin','timetable_teacher-topic'),('admin','timetable_update'),('admin','timetable_user'),('admin','timetable_view'),('admin','user-access-type_create'),('admin','user-access-type_delete'),('admin','user-access-type_index'),('admin','user-access-type_update'),('admin','user-access-type_view'),('admin','user-access_create'),('admin','user-access_delete'),('admin','user-access_index'),('admin','user-access_view'),('admin','user_all-file-removes'),('admin','user_create'),('admin','user_delete'),('admin','user_get'),('admin','user_index'),('admin','user_login-history'),('admin','user_logout'),('admin','user_me'),('admin','user_self'),('admin','user_selfget'),('admin','user_status-list'),('admin','user_update'),('admin','user_view'),('admin','week_create'),('admin','week_delete'),('admin','week_index'),('admin','week_update'),('admin','week_view'),('admin','work-load_create'),('admin','work-load_delete'),('admin','work-load_index'),('admin','work-load_update'),('admin','work-load_view'),('admin','work-rate_create'),('admin','work-rate_delete'),('admin','work-rate_index'),('admin','work-rate_update'),('admin','work-rate_view'),('edu_admin','academic-degree_create'),('edu_admin','academic-degree_delete'),('edu_admin','academic-degree_index'),('edu_admin','academic-degree_update'),('edu_admin','academic-degree_view'),('edu_admin','access-control_create-permission'),('edu_admin','access-control_create-role'),('edu_admin','access-control_delete-role'),('edu_admin','access-control_permissions'),('edu_admin','access-control_role-permissions'),('edu_admin','access-control_roles'),('edu_admin','access-control_update-role'),('edu_admin','action-log_index'),('edu_admin','action-log_view'),('edu_admin','area_create'),('edu_admin','area_delete'),('edu_admin','area_index'),('edu_admin','area_update'),('edu_admin','area_view'),('edu_admin','attend-reason_cancellation'),('edu_admin','attend-reason_confirm'),('edu_admin','attend-reason_create'),('edu_admin','attend-reason_delete'),('edu_admin','attend-reason_index'),('edu_admin','attend-reason_update'),('edu_admin','attend-reason_view'),('edu_admin','attend_create'),('edu_admin','attend_delete'),('edu_admin','attend_index'),('edu_admin','attend_update'),('edu_admin','attend_view'),('edu_admin','building_create'),('edu_admin','building_delete'),('edu_admin','building_index'),('edu_admin','building_update'),('edu_admin','building_view'),('edu_admin','category-of-cohabitant_create'),('edu_admin','category-of-cohabitant_delete'),('edu_admin','category-of-cohabitant_index'),('edu_admin','category-of-cohabitant_update'),('edu_admin','category-of-cohabitant_view'),('edu_admin','citizenship_create'),('edu_admin','citizenship_delete'),('edu_admin','citizenship_index'),('edu_admin','citizenship_update'),('edu_admin','citizenship_view'),('edu_admin','commands-type_create'),('edu_admin','commands-type_delete'),('edu_admin','commands-type_index'),('edu_admin','commands-type_update'),('edu_admin','commands-type_view'),('edu_admin','commands_create'),('edu_admin','commands_delete'),('edu_admin','commands_index'),('edu_admin','commands_update'),('edu_admin','commands_view'),('edu_admin','country_index'),('edu_admin','country_view'),('edu_admin','course_create'),('edu_admin','course_delete'),('edu_admin','course_index'),('edu_admin','course_update'),('edu_admin','course_view'),('edu_admin','degree-info_create'),('edu_admin','degree-info_delete'),('edu_admin','degree-info_index'),('edu_admin','degree-info_update'),('edu_admin','degree-info_view'),('edu_admin','degree_create'),('edu_admin','degree_delete'),('edu_admin','degree_index'),('edu_admin','degree_update'),('edu_admin','degree_view'),('edu_admin','department_create'),('edu_admin','department_delete'),('edu_admin','department_index'),('edu_admin','department_types'),('edu_admin','department_update'),('edu_admin','department_user-access'),('edu_admin','department_view'),('edu_admin','diploma-type_create'),('edu_admin','diploma-type_delete'),('edu_admin','diploma-type_index'),('edu_admin','diploma-type_update'),('edu_admin','diploma-type_view'),('edu_admin','direction_create'),('edu_admin','direction_delete'),('edu_admin','direction_index'),('edu_admin','direction_update'),('edu_admin','direction_view'),('edu_admin','document-decree_command-type'),('edu_admin','document-decree_confirm'),('edu_admin','document-decree_create'),('edu_admin','document-decree_delete'),('edu_admin','document-decree_hr-update'),('edu_admin','document-decree_index'),('edu_admin','document-decree_sign'),('edu_admin','document-decree_signature-update'),('edu_admin','document-decree_update'),('edu_admin','document-decree_view'),('edu_admin','document-execution_create'),('edu_admin','document-execution_delete'),('edu_admin','document-execution_index'),('edu_admin','document-execution_update'),('edu_admin','document-execution_view'),('edu_admin','document-notification_command-type'),('edu_admin','document-notification_confirm'),('edu_admin','document-notification_create'),('edu_admin','document-notification_delete'),('edu_admin','document-notification_hr-update'),('edu_admin','document-notification_index'),('edu_admin','document-notification_sign'),('edu_admin','document-notification_signature-update'),('edu_admin','document-notification_update'),('edu_admin','document-notification_view'),('edu_admin','document-type_create'),('edu_admin','document-type_delete'),('edu_admin','document-type_index'),('edu_admin','document-type_update'),('edu_admin','document-type_view'),('edu_admin','document-weight_create'),('edu_admin','document-weight_delete'),('edu_admin','document-weight_index'),('edu_admin','document-weight_update'),('edu_admin','document-weight_view'),('edu_admin','document_create'),('edu_admin','document_delete'),('edu_admin','document_delete-file'),('edu_admin','document_index'),('edu_admin','document_update'),('edu_admin','document_view'),('edu_admin','edu-form_create'),('edu_admin','edu-form_delete'),('edu_admin','edu-form_index'),('edu_admin','edu-form_update'),('edu_admin','edu-form_view'),('edu_admin','edu-plan_create'),('edu_admin','edu-plan_delete'),('edu_admin','edu-plan_index'),('edu_admin','edu-plan_update'),('edu_admin','edu-plan_view'),('edu_admin','edu-semestr-subject-category-time_index'),('edu_admin','edu-semestr-subject_create'),('edu_admin','edu-semestr-subject_delete'),('edu_admin','edu-semestr-subject_index'),('edu_admin','edu-semestr-subject_update'),('edu_admin','edu-semestr-subject_view'),('edu_admin','edu-semestr_create'),('edu_admin','edu-semestr_delete'),('edu_admin','edu-semestr_index'),('edu_admin','edu-semestr_student-subject-merge'),('edu_admin','edu-semestr_update'),('edu_admin','edu-semestr_view'),('edu_admin','edu-type_create'),('edu_admin','edu-type_delete'),('edu_admin','edu-type_index'),('edu_admin','edu-type_update'),('edu_admin','edu-type_view'),('edu_admin','edu-year_create'),('edu_admin','edu-year_delete'),('edu_admin','edu-year_index'),('edu_admin','edu-year_update'),('edu_admin','edu-year_view'),('edu_admin','exam-control-student_check'),('edu_admin','exam-control-student_create'),('edu_admin','exam-control-student_delete'),('edu_admin','exam-control-student_finish'),('edu_admin','exam-control-student_index'),('edu_admin','exam-control-student_rating'),('edu_admin','exam-control-student_update'),('edu_admin','exam-control-student_view'),('edu_admin','exam-control_create'),('edu_admin','exam-control_delete'),('edu_admin','exam-control_index'),('edu_admin','exam-control_update'),('edu_admin','exam-control_view'),('edu_admin','exam-questions_create'),('edu_admin','exam-questions_delete'),('edu_admin','exam-questions_index'),('edu_admin','exam-questions_is-confirm'),('edu_admin','exam-questions_update'),('edu_admin','exam-questions_view'),('edu_admin','exam-student-question_delete'),('edu_admin','exam-student-question_index'),('edu_admin','exam-student-question_update'),('edu_admin','exam-student-question_update-ball'),('edu_admin','exam-student-question_view'),('edu_admin','exam-student_create'),('edu_admin','exam-student_delete'),('edu_admin','exam-student_finish'),('edu_admin','exam-student_index'),('edu_admin','exam-student_rating'),('edu_admin','exam-student_update'),('edu_admin','exam-student_view'),('edu_admin','exam-test-option_create'),('edu_admin','exam-test-option_delete'),('edu_admin','exam-test-option_index'),('edu_admin','exam-test-option_update'),('edu_admin','exam-test-option_view'),('edu_admin','exam-test-student-answer_delete'),('edu_admin','exam-test-student-answer_designation'),('edu_admin','exam-test-student-answer_index'),('edu_admin','exam-test-student-answer_view'),('edu_admin','exam-test_create'),('edu_admin','exam-test_delete'),('edu_admin','exam-test_excel-import'),('edu_admin','exam-test_index'),('edu_admin','exam-test_is-check'),('edu_admin','exam-test_update'),('edu_admin','exam-test_view'),('edu_admin','exams-type_create'),('edu_admin','exams-type_delete'),('edu_admin','exams-type_index'),('edu_admin','exams-type_update'),('edu_admin','exams-type_view'),('edu_admin','exam_allotment'),('edu_admin','exam_create'),('edu_admin','exam_delete'),('edu_admin','exam_exam-check'),('edu_admin','exam_exam-finish'),('edu_admin','exam_exam-notify'),('edu_admin','exam_exam-teacher-attach'),('edu_admin','exam_index'),('edu_admin','exam_update'),('edu_admin','exam_view'),('edu_admin','excel_ik-excel'),('edu_admin','faculty_create'),('edu_admin','faculty_delete'),('edu_admin','faculty_index'),('edu_admin','faculty_update'),('edu_admin','faculty_user-access'),('edu_admin','faculty_view'),('edu_admin','final-exam-test-start_add-ball'),('edu_admin','final-exam-test-start_finish'),('edu_admin','final-exam-test-start_get'),('edu_admin','final-exam-test-start_student-update'),('edu_admin','final-exam-test-start_time'),('edu_admin','final-exam-test-start_update'),('edu_admin','final-exam-test-start_view'),('edu_admin','final-exam-test_add'),('edu_admin','final-exam-test_index'),('edu_admin','final-exam-test_update'),('edu_admin','final-exam_all-confirm'),('edu_admin','final-exam_confirm'),('edu_admin','final-exam_confirm-dean'),('edu_admin','final-exam_confirm-mudir'),('edu_admin','final-exam_confirm-two'),('edu_admin','final-exam_create'),('edu_admin','final-exam_delete'),('edu_admin','final-exam_edu-type-update'),('edu_admin','final-exam_in-charge'),('edu_admin','final-exam_index'),('edu_admin','final-exam_last-confirm'),('edu_admin','final-exam_update'),('edu_admin','final-exam_view'),('edu_admin','get-info_academik-reference'),('edu_admin','group_create'),('edu_admin','group_delete'),('edu_admin','group_group'),('edu_admin','group_index'),('edu_admin','group_update'),('edu_admin','group_view'),('edu_admin','ik-student-bot_bot'),('edu_admin','important-level_create'),('edu_admin','important-level_delete'),('edu_admin','important-level_index'),('edu_admin','important-level_update'),('edu_admin','important-level_view'),('edu_admin','kafedra_create'),('edu_admin','kafedra_delete'),('edu_admin','kafedra_index'),('edu_admin','kafedra_update'),('edu_admin','kafedra_user-access'),('edu_admin','kafedra_view'),('edu_admin','languages_create'),('edu_admin','languages_delete'),('edu_admin','languages_index'),('edu_admin','languages_update'),('edu_admin','languages_view'),('edu_admin','lang_create'),('edu_admin','lang_delete'),('edu_admin','lang_index'),('edu_admin','lang_update'),('edu_admin','lang_view'),('edu_admin','letter-forward-item_create'),('edu_admin','letter-forward-item_delete'),('edu_admin','letter-forward-item_index'),('edu_admin','letter-forward-item_update'),('edu_admin','letter-forward-item_view'),('edu_admin','letter-forward_create'),('edu_admin','letter-forward_delete'),('edu_admin','letter-forward_index'),('edu_admin','letter-forward_update'),('edu_admin','letter-forward_view'),('edu_admin','letter-outgoing_create'),('edu_admin','letter-outgoing_delete'),('edu_admin','letter-outgoing_index'),('edu_admin','letter-outgoing_is-ok'),('edu_admin','letter-outgoing_update'),('edu_admin','letter-outgoing_view'),('edu_admin','letter-reply_create'),('edu_admin','letter-reply_delete'),('edu_admin','letter-reply_index'),('edu_admin','letter-reply_is-ok'),('edu_admin','letter-reply_update'),('edu_admin','letter-reply_view'),('edu_admin','letter_create'),('edu_admin','letter_delete'),('edu_admin','letter_delete-file'),('edu_admin','letter_index'),('edu_admin','letter_is-ok'),('edu_admin','letter_update'),('edu_admin','letter_view'),('edu_admin','nationality_create'),('edu_admin','nationality_delete'),('edu_admin','nationality_index'),('edu_admin','nationality_update'),('edu_admin','nationality_view'),('edu_admin','open-info_student-call-sheet'),('edu_admin','option_create'),('edu_admin','option_delete'),('edu_admin','option_index'),('edu_admin','option_update'),('edu_admin','option_view'),('edu_admin','para_create'),('edu_admin','para_delete'),('edu_admin','para_index'),('edu_admin','para_update'),('edu_admin','para_view'),('edu_admin','partiya_create'),('edu_admin','partiya_delete'),('edu_admin','partiya_index'),('edu_admin','partiya_update'),('edu_admin','partiya_view'),('edu_admin','password_index'),('edu_admin','password_update'),('edu_admin','password_view'),('edu_admin','region_create'),('edu_admin','region_delete'),('edu_admin','region_index'),('edu_admin','region_update'),('edu_admin','region_view'),('edu_admin','residence-status_create'),('edu_admin','residence-status_delete'),('edu_admin','residence-status_index'),('edu_admin','residence-status_update'),('edu_admin','residence-status_view'),('edu_admin','room-ip_create'),('edu_admin','room-ip_delete'),('edu_admin','room-ip_excel-import'),('edu_admin','room-ip_index'),('edu_admin','room-ip_update'),('edu_admin','room-ip_view'),('edu_admin','room-type_create'),('edu_admin','room-type_delete'),('edu_admin','room-type_index'),('edu_admin','room-type_update'),('edu_admin','room-type_view'),('edu_admin','room_create'),('edu_admin','room_delete'),('edu_admin','room_free'),('edu_admin','room_free-exam'),('edu_admin','room_index'),('edu_admin','room_update'),('edu_admin','room_view'),('edu_admin','semestr_create'),('edu_admin','semestr_delete'),('edu_admin','semestr_index'),('edu_admin','semestr_update'),('edu_admin','semestr_view'),('edu_admin','social-category_create'),('edu_admin','social-category_delete'),('edu_admin','social-category_index'),('edu_admin','social-category_update'),('edu_admin','social-category_view'),('edu_admin','statistic_checking'),('edu_admin','statistic_checking-chala'),('edu_admin','statistic_edu-plan'),('edu_admin','statistic_empolyee'),('edu_admin','statistic_exam-checking'),('edu_admin','statistic_faculty-statistic'),('edu_admin','statistic_home-page'),('edu_admin','statistic_kafedra'),('edu_admin','statistic_kpi-content-store'),('edu_admin','statistic_kpi-survey-store'),('edu_admin','statistic_kpi-survey-store00'),('edu_admin','statistic_statistic'),('edu_admin','statistic_student-count-by-faculty'),('edu_admin','statistic_students'),('edu_admin','student-attend_by-date'),('edu_admin','student-attend_create'),('edu_admin','student-attend_delete'),('edu_admin','student-attend_index'),('edu_admin','student-attend_update'),('edu_admin','student-attend_view'),('edu_admin','student-category_create'),('edu_admin','student-category_delete'),('edu_admin','student-category_index'),('edu_admin','student-category_update'),('edu_admin','student-category_view'),('edu_admin','student-group_create'),('edu_admin','student-group_delete'),('edu_admin','student-group_index'),('edu_admin','student-group_update'),('edu_admin','student-mark_create'),('edu_admin','student-mark_delete'),('edu_admin','student-mark_exam'),('edu_admin','student-mark_final-exam'),('edu_admin','student-mark_get'),('edu_admin','student-mark_index'),('edu_admin','student-mark_student-mark-update'),('edu_admin','student-mark_view'),('edu_admin','student-semestr-subject_index'),('edu_admin','student-topic-permission_create'),('edu_admin','student-topic-permission_delete'),('edu_admin','student-topic-permission_index'),('edu_admin','student-topic-permission_permission'),('edu_admin','student-topic-permission_update'),('edu_admin','student-topic-permission_view'),('edu_admin','student-vedomst_delete'),('edu_admin','student-vedomst_index'),('edu_admin','student-vedomst_update'),('edu_admin','student_by-pinfl'),('edu_admin','student_create'),('edu_admin','student_delete'),('edu_admin','student_export'),('edu_admin','student_get'),('edu_admin','student_import'),('edu_admin','student_index'),('edu_admin','student_me'),('edu_admin','student_missed-hours'),('edu_admin','student_read'),('edu_admin','student_statistic-attend'),('edu_admin','student_student11'),('edu_admin','student_tutor'),('edu_admin','student_type'),('edu_admin','student_update'),('edu_admin','student_view'),('edu_admin','subject-category_create'),('edu_admin','subject-category_delete'),('edu_admin','subject-category_index'),('edu_admin','subject-category_update'),('edu_admin','subject-category_view'),('edu_admin','subject-content_create'),('edu_admin','subject-content_delete'),('edu_admin','subject-content_index'),('edu_admin','subject-content_order'),('edu_admin','subject-content_trash'),('edu_admin','subject-content_trash-delete'),('edu_admin','subject-content_types'),('edu_admin','subject-content_update'),('edu_admin','subject-content_view'),('edu_admin','subject-semestr_create'),('edu_admin','subject-semestr_delete'),('edu_admin','subject-semestr_index'),('edu_admin','subject-semestr_update'),('edu_admin','subject-semestr_view'),('edu_admin','subject-topic-test_answer'),('edu_admin','subject-topic-test_finish'),('edu_admin','subject-topic-test_index'),('edu_admin','subject-topic-test_topic-test'),('edu_admin','subject-topic_create'),('edu_admin','subject-topic_delete'),('edu_admin','subject-topic_export'),('edu_admin','subject-topic_index'),('edu_admin','subject-topic_order'),('edu_admin','subject-topic_update'),('edu_admin','subject-topic_view'),('edu_admin','subject-type_create'),('edu_admin','subject-type_delete'),('edu_admin','subject-type_index'),('edu_admin','subject-type_update'),('edu_admin','subject-type_view'),('edu_admin','subject_create'),('edu_admin','subject_delete'),('edu_admin','subject_index'),('edu_admin','subject_update'),('edu_admin','subject_view'),('edu_admin','teacher-access_content'),('edu_admin','teacher-access_create'),('edu_admin','teacher-access_delete'),('edu_admin','teacher-access_free'),('edu_admin','teacher-access_free-exam'),('edu_admin','teacher-access_get'),('edu_admin','teacher-access_index'),('edu_admin','teacher-access_update'),('edu_admin','teacher-access_view'),('edu_admin','test_all-delete'),('edu_admin','test_create'),('edu_admin','test_delete'),('edu_admin','test_excel-import'),('edu_admin','test_index'),('edu_admin','test_is-check'),('edu_admin','test_update'),('edu_admin','test_view'),('edu_admin','time-table1_create'),('edu_admin','time-table1_create-add-group'),('edu_admin','time-table1_delete'),('edu_admin','time-table1_index'),('edu_admin','time-table1_parent-null'),('edu_admin','time-table1_update'),('edu_admin','time-table1_view'),('edu_admin','time-table1_viewww'),('edu_admin','timetable-attend_attend-student'),('edu_admin','timetable-attend_create'),('edu_admin','timetable-attend_get'),('edu_admin','timetable-attend_index'),('edu_admin','timetable-attend_student-reason'),('edu_admin','timetable-attend_update'),('edu_admin','timetable-date_attend'),('edu_admin','timetable-date_create'),('edu_admin','timetable-date_delete'),('edu_admin','timetable-date_filter'),('edu_admin','timetable-date_get'),('edu_admin','timetable-date_get-date'),('edu_admin','timetable-date_index'),('edu_admin','timetable-date_teacher'),('edu_admin','timetable-reason_create'),('edu_admin','timetable-reason_delete'),('edu_admin','timetable-reason_index'),('edu_admin','timetable-reason_update'),('edu_admin','timetable_add-day'),('edu_admin','timetable_add-group'),('edu_admin','timetable_attend'),('edu_admin','timetable_create'),('edu_admin','timetable_delete'),('edu_admin','timetable_delete-one'),('edu_admin','timetable_edu-plan'),('edu_admin','timetable_edu-semestr'),('edu_admin','timetable_index'),('edu_admin','timetable_student-type'),('edu_admin','timetable_teacher-topic'),('edu_admin','timetable_update'),('edu_admin','timetable_user'),('edu_admin','timetable_view'),('edu_admin','user-access-type_create'),('edu_admin','user-access-type_delete'),('edu_admin','user-access-type_index'),('edu_admin','user-access-type_update'),('edu_admin','user-access-type_view'),('edu_admin','user-access_create'),('edu_admin','user-access_delete'),('edu_admin','user-access_index'),('edu_admin','user-access_view'),('edu_admin','user_all-file-removes'),('edu_admin','user_create'),('edu_admin','user_delete'),('edu_admin','user_get'),('edu_admin','user_index'),('edu_admin','user_login-history'),('edu_admin','user_logout'),('edu_admin','user_me'),('edu_admin','user_self'),('edu_admin','user_selfget'),('edu_admin','user_status-list'),('edu_admin','user_update'),('edu_admin','user_view'),('edu_admin','week_create'),('edu_admin','week_delete'),('edu_admin','week_index'),('edu_admin','week_update'),('edu_admin','week_view'),('edu_admin','work-load_create'),('edu_admin','work-load_delete'),('edu_admin','work-load_index'),('edu_admin','work-load_update'),('edu_admin','work-load_view'),('edu_admin','work-rate_create'),('edu_admin','work-rate_delete'),('edu_admin','work-rate_index'),('edu_admin','work-rate_update'),('edu_admin','work-rate_view');
/*!40000 ALTER TABLE `auth_item_child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_rule` (
  `name` varchar(64) NOT NULL,
  `data` blob DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_rule`
--

LOCK TABLES `auth_rule` WRITE;
/*!40000 ALTER TABLE `auth_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `building`
--

DROP TABLE IF EXISTS `building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `building` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `building`
--

LOCK TABLES `building` WRITE;
/*!40000 ALTER TABLE `building` DISABLE KEYS */;
INSERT INTO `building` VALUES (1,1,1,1734438261,1734438261,5,0,0);
/*!40000 ALTER TABLE `building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_of_cohabitant`
--

DROP TABLE IF EXISTS `category_of_cohabitant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_of_cohabitant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_of_cohabitant`
--

LOCK TABLES `category_of_cohabitant` WRITE;
/*!40000 ALTER TABLE `category_of_cohabitant` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_of_cohabitant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citizenship`
--

DROP TABLE IF EXISTS `citizenship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `citizenship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citizenship`
--

LOCK TABLES `citizenship` WRITE;
/*!40000 ALTER TABLE `citizenship` DISABLE KEYS */;
/*!40000 ALTER TABLE `citizenship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `ISO` varchar(2) NOT NULL,
  `ISO3` varchar(3) DEFAULT NULL,
  `num_code` int(11) DEFAULT NULL,
  `phone_code` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=240 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'Afghanistan','AF','AFG',4,93),(2,'Albania','AL','ALB',8,355),(3,'Algeria','DZ','DZA',12,213),(4,'American Samoa','AS','ASM',16,1684),(5,'Andorra','AD','AND',20,376),(6,'Angola','AO','AGO',24,244),(7,'Anguilla','AI','AIA',660,1264),(8,'Antarctica','AQ',NULL,NULL,0),(9,'Antigua and Barbuda','AG','ATG',28,1268),(10,'Argentina','AR','ARG',32,54),(11,'Armenia','AM','ARM',51,374),(12,'Aruba','AW','ABW',533,297),(13,'Australia','AU','AUS',36,61),(14,'Austria','AT','AUT',40,43),(15,'Azerbaijan','AZ','AZE',31,994),(16,'Bahamas','BS','BHS',44,1242),(17,'Bahrain','BH','BHR',48,973),(18,'Bangladesh','BD','BGD',50,880),(19,'Barbados','BB','BRB',52,1246),(20,'Belarus','BY','BLR',112,375),(21,'Belgium','BE','BEL',56,32),(22,'Belize','BZ','BLZ',84,501),(23,'Benin','BJ','BEN',204,229),(24,'Bermuda','BM','BMU',60,1441),(25,'Bhutan','BT','BTN',64,975),(26,'Bolivia','BO','BOL',68,591),(27,'Bosnia and Herzegovina','BA','BIH',70,387),(28,'Botswana','BW','BWA',72,267),(29,'Bouvet Island','BV',NULL,NULL,0),(30,'Brazil','BR','BRA',76,55),(31,'British Indian Ocean Territory','IO',NULL,NULL,246),(32,'Brunei Darussalam','BN','BRN',96,673),(33,'Bulgaria','BG','BGR',100,359),(34,'Burkina Faso','BF','BFA',854,226),(35,'Burundi','BI','BDI',108,257),(36,'Cambodia','KH','KHM',116,855),(37,'Cameroon','CM','CMR',120,237),(38,'Canada','CA','CAN',124,1),(39,'Cape Verde','CV','CPV',132,238),(40,'Cayman Islands','KY','CYM',136,1345),(41,'Central African Republic','CF','CAF',140,236),(42,'Chad','TD','TCD',148,235),(43,'Chile','CL','CHL',152,56),(44,'China','CN','CHN',156,86),(45,'Christmas Island','CX',NULL,NULL,61),(46,'Cocos (Keeling) Islands','CC',NULL,NULL,672),(47,'Colombia','CO','COL',170,57),(48,'Comoros','KM','COM',174,269),(49,'Congo','CG','COG',178,242),(50,'Congo, the Democratic Republic of the','CD','COD',180,242),(51,'Cook Islands','CK','COK',184,682),(52,'Costa Rica','CR','CRI',188,506),(53,'Cote D\'Ivoire','CI','CIV',384,225),(54,'Croatia','HR','HRV',191,385),(55,'Cuba','CU','CUB',192,53),(56,'Cyprus','CY','CYP',196,357),(57,'Czech Republic','CZ','CZE',203,420),(58,'Denmark','DK','DNK',208,45),(59,'Djibouti','DJ','DJI',262,253),(60,'Dominica','DM','DMA',212,1767),(61,'Dominican Republic','DO','DOM',214,1809),(62,'Ecuador','EC','ECU',218,593),(63,'Egypt','EG','EGY',818,20),(64,'El Salvador','SV','SLV',222,503),(65,'Equatorial Guinea','GQ','GNQ',226,240),(66,'Eritrea','ER','ERI',232,291),(67,'Estonia','EE','EST',233,372),(68,'Ethiopia','ET','ETH',231,251),(69,'Falkland Islands (Malvinas)','FK','FLK',238,500),(70,'Faroe Islands','FO','FRO',234,298),(71,'Fiji','FJ','FJI',242,679),(72,'Finland','FI','FIN',246,358),(73,'France','FR','FRA',250,33),(74,'French Guiana','GF','GUF',254,594),(75,'French Polynesia','PF','PYF',258,689),(76,'French Southern Territories','TF',NULL,NULL,0),(77,'Gabon','GA','GAB',266,241),(78,'Gambia','GM','GMB',270,220),(79,'Georgia','GE','GEO',268,995),(80,'Germany','DE','DEU',276,49),(81,'Ghana','GH','GHA',288,233),(82,'Gibraltar','GI','GIB',292,350),(83,'Greece','GR','GRC',300,30),(84,'Greenland','GL','GRL',304,299),(85,'Grenada','GD','GRD',308,1473),(86,'Guadeloupe','GP','GLP',312,590),(87,'Guam','GU','GUM',316,1671),(88,'Guatemala','GT','GTM',320,502),(89,'Guinea','GN','GIN',324,224),(90,'Guinea-Bissau','GW','GNB',624,245),(91,'Guyana','GY','GUY',328,592),(92,'Haiti','HT','HTI',332,509),(93,'Heard Island and Mcdonald Islands','HM',NULL,NULL,0),(94,'Holy See (Vatican City State)','VA','VAT',336,39),(95,'Honduras','HN','HND',340,504),(96,'Hong Kong','HK','HKG',344,852),(97,'Hungary','HU','HUN',348,36),(98,'Iceland','IS','ISL',352,354),(99,'India','IN','IND',356,91),(100,'Indonesia','ID','IDN',360,62),(101,'Iran, Islamic Republic of','IR','IRN',364,98),(102,'Iraq','IQ','IRQ',368,964),(103,'Ireland','IE','IRL',372,353),(104,'Israel','IL','ISR',376,972),(105,'Italy','IT','ITA',380,39),(106,'Jamaica','JM','JAM',388,1876),(107,'Japan','JP','JPN',392,81),(108,'Jordan','JO','JOR',400,962),(109,'Kazakhstan','KZ','KAZ',398,7),(110,'Kenya','KE','KEN',404,254),(111,'Kiribati','KI','KIR',296,686),(112,'Korea, Democratic People\'s Republic of','KP','PRK',408,850),(113,'Korea, Republic of','KR','KOR',410,82),(114,'Kuwait','KW','KWT',414,965),(115,'Kyrgyzstan','KG','KGZ',417,996),(116,'Lao People\'s Democratic Republic','LA','LAO',418,856),(117,'Latvia','LV','LVA',428,371),(118,'Lebanon','LB','LBN',422,961),(119,'Lesotho','LS','LSO',426,266),(120,'Liberia','LR','LBR',430,231),(121,'Libyan Arab Jamahiriya','LY','LBY',434,218),(122,'Liechtenstein','LI','LIE',438,423),(123,'Lithuania','LT','LTU',440,370),(124,'Luxembourg','LU','LUX',442,352),(125,'Macao','MO','MAC',446,853),(126,'Macedonia, the Former Yugoslav Republic of','MK','MKD',807,389),(127,'Madagascar','MG','MDG',450,261),(128,'Malawi','MW','MWI',454,265),(129,'Malaysia','MY','MYS',458,60),(130,'Maldives','MV','MDV',462,960),(131,'Mali','ML','MLI',466,223),(132,'Malta','MT','MLT',470,356),(133,'Marshall Islands','MH','MHL',584,692),(134,'Martinique','MQ','MTQ',474,596),(135,'Mauritania','MR','MRT',478,222),(136,'Mauritius','MU','MUS',480,230),(137,'Mayotte','YT',NULL,NULL,269),(138,'Mexico','MX','MEX',484,52),(139,'Micronesia, Federated States of','FM','FSM',583,691),(140,'Moldova, Republic of','MD','MDA',498,373),(141,'Monaco','MC','MCO',492,377),(142,'Mongolia','MN','MNG',496,976),(143,'Montserrat','MS','MSR',500,1664),(144,'Morocco','MA','MAR',504,212),(145,'Mozambique','MZ','MOZ',508,258),(146,'Myanmar','MM','MMR',104,95),(147,'Namibia','NA','NAM',516,264),(148,'Nauru','NR','NRU',520,674),(149,'Nepal','NP','NPL',524,977),(150,'Netherlands','NL','NLD',528,31),(151,'Netherlands Antilles','AN','ANT',530,599),(152,'New Caledonia','NC','NCL',540,687),(153,'New Zealand','NZ','NZL',554,64),(154,'Nicaragua','NI','NIC',558,505),(155,'Niger','NE','NER',562,227),(156,'Nigeria','NG','NGA',566,234),(157,'Niue','NU','NIU',570,683),(158,'Norfolk Island','NF','NFK',574,672),(159,'Northern Mariana Islands','MP','MNP',580,1670),(160,'Norway','NO','NOR',578,47),(161,'Oman','OM','OMN',512,968),(162,'Pakistan','PK','PAK',586,92),(163,'Palau','PW','PLW',585,680),(164,'Palestinian Territory, Occupied','PS',NULL,NULL,970),(165,'Panama','PA','PAN',591,507),(166,'Papua New Guinea','PG','PNG',598,675),(167,'Paraguay','PY','PRY',600,595),(168,'Peru','PE','PER',604,51),(169,'Philippines','PH','PHL',608,63),(170,'Pitcairn','PN','PCN',612,0),(171,'Poland','PL','POL',616,48),(172,'Portugal','PT','PRT',620,351),(173,'Puerto Rico','PR','PRI',630,1787),(174,'Qatar','QA','QAT',634,974),(175,'Reunion','RE','REU',638,262),(176,'Romania','RO','ROM',642,40),(177,'Russian Federation','RU','RUS',643,70),(178,'Rwanda','RW','RWA',646,250),(179,'Saint Helena','SH','SHN',654,290),(180,'Saint Kitts and Nevis','KN','KNA',659,1869),(181,'Saint Lucia','LC','LCA',662,1758),(182,'Saint Pierre and Miquelon','PM','SPM',666,508),(183,'Saint Vincent and the Grenadines','VC','VCT',670,1784),(184,'Samoa','WS','WSM',882,684),(185,'San Marino','SM','SMR',674,378),(186,'Sao Tome and Principe','ST','STP',678,239),(187,'Saudi Arabia','SA','SAU',682,966),(188,'Senegal','SN','SEN',686,221),(189,'Serbia and Montenegro','CS',NULL,NULL,381),(190,'Seychelles','SC','SYC',690,248),(191,'Sierra Leone','SL','SLE',694,232),(192,'Singapore','SG','SGP',702,65),(193,'Slovakia','SK','SVK',703,421),(194,'Slovenia','SI','SVN',705,386),(195,'Solomon Islands','SB','SLB',90,677),(196,'Somalia','SO','SOM',706,252),(197,'South Africa','ZA','ZAF',710,27),(198,'South Georgia and the South Sandwich Islands','GS',NULL,NULL,0),(199,'Spain','ES','ESP',724,34),(200,'Sri Lanka','LK','LKA',144,94),(201,'Sudan','SD','SDN',736,249),(202,'Suriname','SR','SUR',740,597),(203,'Svalbard and Jan Mayen','SJ','SJM',744,47),(204,'Swaziland','SZ','SWZ',748,268),(205,'Sweden','SE','SWE',752,46),(206,'Switzerland','CH','CHE',756,41),(207,'Syrian Arab Republic','SY','SYR',760,963),(208,'Taiwan, Province of China','TW','TWN',158,886),(209,'Tajikistan','TJ','TJK',762,992),(210,'Tanzania, United Republic of','TZ','TZA',834,255),(211,'Thailand','TH','THA',764,66),(212,'Timor-Leste','TL',NULL,NULL,670),(213,'Togo','TG','TGO',768,228),(214,'Tokelau','TK','TKL',772,690),(215,'Tonga','TO','TON',776,676),(216,'Trinidad and Tobago','TT','TTO',780,1868),(217,'Tunisia','TN','TUN',788,216),(218,'Turkey','TR','TUR',792,90),(219,'Turkmenistan','TM','TKM',795,7370),(220,'Turks and Caicos Islands','TC','TCA',796,1649),(221,'Tuvalu','TV','TUV',798,688),(222,'Uganda','UG','UGA',800,256),(223,'Ukraine','UA','UKR',804,380),(224,'United Arab Emirates','AE','ARE',784,971),(225,'United Kingdom','GB','GBR',826,44),(226,'United States','US','USA',840,1),(227,'United States Minor Outlying Islands','UM',NULL,NULL,1),(228,'Uruguay','UY','URY',858,598),(229,'Uzbekistan','UZ','UZB',860,998),(230,'Vanuatu','VU','VUT',548,678),(231,'Venezuela','VE','VEN',862,58),(232,'Viet Nam','VN','VNM',704,84),(233,'Virgin Islands, British','VG','VGB',92,1284),(234,'Virgin Islands, U.s.','VI','VIR',850,1340),(235,'Wallis and Futuna','WF','WLF',876,681),(236,'Western Sahara','EH','ESH',732,212),(237,'Yemen','YE','YEM',887,967),(238,'Zambia','ZM','ZMB',894,260),(239,'Zimbabwe','ZW','ZWE',716,263);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,1,1,1734432461,1734432461,2,0,0),(2,1,1,1734432468,1734432468,2,0,0),(3,1,1,1734432474,1734432474,2,0,0),(4,1,1,1734432478,1734432478,2,0,0),(5,1,1,1734432484,1734432484,2,0,0);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `degree`
--

DROP TABLE IF EXISTS `degree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `degree` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `degree`
--

LOCK TABLES `degree` WRITE;
/*!40000 ALTER TABLE `degree` DISABLE KEYS */;
/*!40000 ALTER TABLE `degree` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `degree_info`
--

DROP TABLE IF EXISTS `degree_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `degree_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `degree_info`
--

LOCK TABLES `degree_info` WRITE;
/*!40000 ALTER TABLE `degree_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `degree_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `type` tinyint(3) DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `user_id` int(11) DEFAULT NULL COMMENT 'Lead of department',
  PRIMARY KEY (`id`),
  KEY `mk_department_table_users_table` (`user_id`),
  CONSTRAINT `mk_department_table_users_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diploma_type`
--

DROP TABLE IF EXISTS `diploma_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diploma_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diploma_type`
--

LOCK TABLES `diploma_type` WRITE;
/*!40000 ALTER TABLE `diploma_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `diploma_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `direction`
--

DROP TABLE IF EXISTS `direction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `direction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `faculty_id` int(11) NOT NULL,
  `code` varchar(255) NOT NULL COMMENT 'yonalish kodi',
  `status` tinyint(1) DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_direction_table_faculty_table` (`faculty_id`),
  CONSTRAINT `mk_direction_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `direction`
--

LOCK TABLES `direction` WRITE;
/*!40000 ALTER TABLE `direction` DISABLE KEYS */;
/*!40000 ALTER TABLE `direction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edu_form`
--

DROP TABLE IF EXISTS `edu_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_form`
--

LOCK TABLES `edu_form` WRITE;
/*!40000 ALTER TABLE `edu_form` DISABLE KEYS */;
INSERT INTO `edu_form` VALUES (1,1,1,1734431137,1734431137,2,0,0),(2,1,1,1734431148,1734431148,2,0,0),(3,0,1,1734431169,1734438511,2,5,0);
/*!40000 ALTER TABLE `edu_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edu_plan`
--

DROP TABLE IF EXISTS `edu_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL COMMENT 'type qoshiladi kuzgi qabul(1)  qishgi qabul (2)',
  `edu_year_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `direction_id` int(11) NOT NULL,
  `edu_type_id` int(11) NOT NULL,
  `edu_form_id` int(11) NOT NULL COMMENT 'ta-lim shakli',
  `course` int(11) NOT NULL COMMENT 'nech kurs o''qishi',
  `first_start` date NOT NULL,
  `first_end` date NOT NULL,
  `second_start` date NOT NULL,
  `second_end` date NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_edu_plan_table_edu_year_table` (`edu_year_id`),
  KEY `mk_edu_plan_table_faculty_table` (`faculty_id`),
  KEY `mk_edu_plan_table_direction_table` (`direction_id`),
  KEY `mk_edu_plan_table_edu_type_table` (`edu_type_id`),
  KEY `mk_edu_plan_table_edu_form_table` (`edu_form_id`),
  CONSTRAINT `mk_edu_plan_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_edu_plan_table_edu_form_table` FOREIGN KEY (`edu_form_id`) REFERENCES `edu_form` (`id`),
  CONSTRAINT `mk_edu_plan_table_edu_type_table` FOREIGN KEY (`edu_type_id`) REFERENCES `edu_type` (`id`),
  CONSTRAINT `mk_edu_plan_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_edu_plan_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_plan`
--

LOCK TABLES `edu_plan` WRITE;
/*!40000 ALTER TABLE `edu_plan` DISABLE KEYS */;
/*!40000 ALTER TABLE `edu_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edu_semestr`
--

DROP TABLE IF EXISTS `edu_semestr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_semestr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT 1 COMMENT 'type 1 - random teshiradi 2 - teacher o`zi tekshiradi id',
  `edu_type_id` int(11) NOT NULL,
  `edu_form_id` int(11) NOT NULL,
  `edu_year_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `direction_id` int(11) NOT NULL,
  `edu_plan_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `semestr_id` int(11) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `is_checked` int(11) NOT NULL,
  `credit` double DEFAULT 0,
  `optional_subject_count` int(11) DEFAULT 0 COMMENT 'tanlov fanlari soni edu_semestr_subject ga qarab turini sanash',
  `required_subject_count` int(11) DEFAULT 0 COMMENT 'majburiy fanlari soni edu_semestr subjectga qarab turini sanash',
  `status` tinyint(1) DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_edu_semestr_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_edu_semestr_table_faculty_table` (`faculty_id`),
  KEY `mk_edu_semestr_table_direction_table` (`direction_id`),
  KEY `mk_edu_semestr_table_course_table` (`course_id`),
  KEY `mk_edu_semestr_table_semestr_table` (`semestr_id`),
  KEY `mk_edu_semestr_table_edu_year_table` (`edu_year_id`),
  KEY `mk_edu_semestr_table_edu_type_table` (`edu_type_id`),
  KEY `mk_edu_semestr_table_edu_form_table` (`edu_form_id`),
  CONSTRAINT `mk_edu_semestr_table_course_table` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
  CONSTRAINT `mk_edu_semestr_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_edu_semestr_table_edu_form_table` FOREIGN KEY (`edu_form_id`) REFERENCES `edu_form` (`id`),
  CONSTRAINT `mk_edu_semestr_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_edu_semestr_table_edu_type_table` FOREIGN KEY (`edu_type_id`) REFERENCES `edu_type` (`id`),
  CONSTRAINT `mk_edu_semestr_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_edu_semestr_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_edu_semestr_table_semestr_table` FOREIGN KEY (`semestr_id`) REFERENCES `semestr` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_semestr`
--

LOCK TABLES `edu_semestr` WRITE;
/*!40000 ALTER TABLE `edu_semestr` DISABLE KEYS */;
/*!40000 ALTER TABLE `edu_semestr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edu_semestr_exams_type`
--

DROP TABLE IF EXISTS `edu_semestr_exams_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_semestr_exams_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `edu_semestr_subject_id` int(11) NOT NULL,
  `exams_type_id` int(11) NOT NULL,
  `max_ball` int(11) NOT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_edu_semestr_exams_type_table_edu_semestr_subject_table` (`edu_semestr_subject_id`),
  KEY `mk_edu_semestr_exams_type_table_exams_type_table` (`exams_type_id`),
  CONSTRAINT `mk_edu_semestr_exams_type_table_edu_semestr_subject_table` FOREIGN KEY (`edu_semestr_subject_id`) REFERENCES `edu_semestr_subject` (`id`),
  CONSTRAINT `mk_edu_semestr_exams_type_table_exams_type_table` FOREIGN KEY (`exams_type_id`) REFERENCES `exams_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_semestr_exams_type`
--

LOCK TABLES `edu_semestr_exams_type` WRITE;
/*!40000 ALTER TABLE `edu_semestr_exams_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `edu_semestr_exams_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edu_semestr_subject`
--

DROP TABLE IF EXISTS `edu_semestr_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_semestr_subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `edu_semestr_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `subject_semestr_id` int(11) DEFAULT NULL,
  `subject_type_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `direction_id` int(11) DEFAULT NULL,
  `credit` double DEFAULT 0,
  `auditory_time` double DEFAULT NULL,
  `all_ball_yuklama` int(11) DEFAULT 0,
  `is_checked` int(11) DEFAULT 0,
  `max_ball` int(11) DEFAULT 0,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `type` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_edu_semestr_subject_table_edu_semestr_table` (`edu_semestr_id`),
  KEY `mk_edu_semestr_subject_table_subject_table` (`subject_id`),
  KEY `mk_edu_semestr_subject_table_subject_type_table` (`subject_type_id`),
  KEY `mk_edu_semestr_subject_table_faculty_table` (`faculty_id`),
  KEY `mk_edu_semestr_subject_table_direction_table` (`direction_id`),
  CONSTRAINT `mk_edu_semestr_subject_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_edu_semestr_subject_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`),
  CONSTRAINT `mk_edu_semestr_subject_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_edu_semestr_subject_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `mk_edu_semestr_subject_table_subject_type_table` FOREIGN KEY (`subject_type_id`) REFERENCES `subject_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_semestr_subject`
--

LOCK TABLES `edu_semestr_subject` WRITE;
/*!40000 ALTER TABLE `edu_semestr_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `edu_semestr_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edu_semestr_subject_category_time`
--

DROP TABLE IF EXISTS `edu_semestr_subject_category_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_semestr_subject_category_time` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `edu_semestr_subject_id` int(11) NOT NULL,
  `subject_category_id` int(11) NOT NULL,
  `hours` int(11) NOT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `edu_semestr_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mk_e_s_subject_category_time_table_e_s_subject_table` (`edu_semestr_subject_id`),
  KEY `mk_e_s_subject_category_time_table_subject_category_table` (`subject_category_id`),
  KEY `mk_e_s_subject_category_time_table_edu_semestr_table` (`edu_semestr_id`),
  KEY `mk_e_s_subject_category_time_table_subject_table` (`subject_id`),
  CONSTRAINT `mk_e_s_subject_category_time_table_e_s_subject_table` FOREIGN KEY (`edu_semestr_subject_id`) REFERENCES `edu_semestr_subject` (`id`),
  CONSTRAINT `mk_e_s_subject_category_time_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`),
  CONSTRAINT `mk_e_s_subject_category_time_table_subject_category_table` FOREIGN KEY (`subject_category_id`) REFERENCES `subject_category` (`id`),
  CONSTRAINT `mk_e_s_subject_category_time_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_semestr_subject_category_time`
--

LOCK TABLES `edu_semestr_subject_category_time` WRITE;
/*!40000 ALTER TABLE `edu_semestr_subject_category_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `edu_semestr_subject_category_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edu_type`
--

DROP TABLE IF EXISTS `edu_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_type`
--

LOCK TABLES `edu_type` WRITE;
/*!40000 ALTER TABLE `edu_type` DISABLE KEYS */;
INSERT INTO `edu_type` VALUES (1,1,1,1734431183,1734431183,2,0,0),(2,0,1,1734431190,1734438519,2,5,0);
/*!40000 ALTER TABLE `edu_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edu_year`
--

DROP TABLE IF EXISTS `edu_year`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_year` int(11) NOT NULL,
  `end_year` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_year`
--

LOCK TABLES `edu_year` WRITE;
/*!40000 ALTER TABLE `edu_year` DISABLE KEYS */;
INSERT INTO `edu_year` VALUES (1,2023,2024,1,1,0,1734432236,1734432236,2,0,0),(2,2023,2024,2,1,0,1734432236,1734432236,2,0,0),(3,2024,2025,1,1,1,1734432236,1734432245,2,2,0),(4,2024,2025,2,1,0,1734432236,1734432236,2,0,0),(5,2025,2026,1,1,0,1734432236,1734432236,2,0,0),(6,2025,2026,2,1,0,1734432236,1734432236,2,0,0),(7,2026,2027,1,1,0,1734432236,1734432236,2,0,0),(8,2026,2027,2,1,0,1734432236,1734432236,2,0,0),(9,2027,2028,1,1,0,1734432236,1734432236,2,0,0),(10,2027,2028,2,1,0,1734432236,1734432236,2,0,0),(11,2028,2029,1,1,0,1734432236,1734432236,2,0,0),(12,2028,2029,2,1,0,1734432236,1734432236,2,0,0),(13,2029,2030,1,1,0,1734432236,1734432236,2,0,0),(14,2029,2030,2,1,0,1734432236,1734432236,2,0,0),(15,2030,2031,1,1,0,1734432236,1734432236,2,0,0),(16,2030,2031,2,1,0,1734432236,1734432236,2,0,0),(17,2031,2032,1,1,0,1734432236,1734432236,2,0,0),(18,2031,2032,2,1,0,1734432236,1734432236,2,0,0),(19,2032,2033,1,1,0,1734432236,1734432236,2,0,0),(20,2032,2033,2,1,0,1734432236,1734432236,2,0,0),(21,2033,2034,1,1,0,1734432236,1734432236,2,0,0),(22,2033,2034,2,1,0,1734432236,1734432236,2,0,0),(23,2034,2035,1,1,0,1734432236,1734432236,2,0,0),(24,2034,2035,2,1,0,1734432236,1734432236,2,0,0),(25,2035,2036,1,1,0,1734432236,1734432236,2,0,0),(26,2035,2036,2,1,0,1734432236,1734432236,2,0,0);
/*!40000 ALTER TABLE `edu_year` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exams_type`
--

DROP TABLE IF EXISTS `exams_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exams_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams_type`
--

LOCK TABLES `exams_type` WRITE;
/*!40000 ALTER TABLE `exams_type` DISABLE KEYS */;
INSERT INTO `exams_type` VALUES (1,1,1,1734432771,1734432771,2,0,0),(2,1,1,1734432780,1734432780,2,0,0),(3,1,1,1734432788,1734432788,2,0,0),(4,1,1,1734432801,1734432814,2,2,1),(5,1,1,1734432810,1734432810,2,0,0);
/*!40000 ALTER TABLE `exams_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_faculty_table_users_table` (`user_id`),
  CONSTRAINT `mk_faculty_table_users_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `final_exam`
--

DROP TABLE IF EXISTS `final_exam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `final_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vedomst` int(11) DEFAULT 1,
  `edu_semestr_subject_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `edu_semestr_exams_type_id` int(11) DEFAULT NULL,
  `exams_type_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `edu_plan_id` int(11) DEFAULT NULL,
  `edu_semestr_id` int(11) DEFAULT NULL,
  `edu_year_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `semestr_id` int(11) DEFAULT NULL,
  `edu_form_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `direction_id` int(11) DEFAULT NULL,
  `language_id` int(11) DEFAULT NULL,
  `exam_type` int(11) DEFAULT 0,
  `exam_form_type` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `building_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `para_id` int(11) DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `start_time` int(11) DEFAULT NULL,
  `finish_time` int(11) DEFAULT NULL,
  `lang_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mk_final_exam_table_edu_semestr_subject_table` (`edu_semestr_subject_id`),
  KEY `mk_final_exam_table_user_table` (`user_id`),
  KEY `mk_final_exam_table_edu_semestr_exams_type_table` (`edu_semestr_exams_type_id`),
  KEY `mk_final_exam_table_exams_type_table` (`exams_type_id`),
  KEY `mk_final_exam_table_subject_table` (`subject_id`),
  KEY `mk_final_exam_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_final_exam_table_edu_semestr_table` (`edu_semestr_id`),
  KEY `mk_final_exam_table_edu_year_table` (`edu_year_id`),
  KEY `mk_final_exam_table_course_table` (`course_id`),
  KEY `mk_final_exam_table_semestr_table` (`semestr_id`),
  KEY `mk_final_exam_table_faculty_table` (`faculty_id`),
  KEY `mk_final_exam_table_direction_table` (`direction_id`),
  KEY `mk_final_exam_table_language_table` (`language_id`),
  KEY `mk_final_exam_table_edu_form_table` (`edu_form_id`),
  KEY `mk_final_exam_table_para_table` (`para_id`),
  KEY `mk_final_exam_table_building_table` (`building_id`),
  KEY `mk_final_exam_table_room_table` (`room_id`),
  KEY `mk_final_exam_table_lang_table` (`lang_id`),
  CONSTRAINT `mk_final_exam_table_building_table` FOREIGN KEY (`building_id`) REFERENCES `building` (`id`),
  CONSTRAINT `mk_final_exam_table_course_table` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
  CONSTRAINT `mk_final_exam_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_final_exam_table_edu_form_table` FOREIGN KEY (`edu_form_id`) REFERENCES `edu_form` (`id`),
  CONSTRAINT `mk_final_exam_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_final_exam_table_edu_semestr_exams_type_table` FOREIGN KEY (`edu_semestr_exams_type_id`) REFERENCES `edu_semestr_exams_type` (`id`),
  CONSTRAINT `mk_final_exam_table_edu_semestr_subject_table` FOREIGN KEY (`edu_semestr_subject_id`) REFERENCES `edu_semestr_subject` (`id`),
  CONSTRAINT `mk_final_exam_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`),
  CONSTRAINT `mk_final_exam_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_final_exam_table_exams_type_table` FOREIGN KEY (`exams_type_id`) REFERENCES `exams_type` (`id`),
  CONSTRAINT `mk_final_exam_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_final_exam_table_lang_table` FOREIGN KEY (`lang_id`) REFERENCES `language` (`id`),
  CONSTRAINT `mk_final_exam_table_language_table` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`),
  CONSTRAINT `mk_final_exam_table_para_table` FOREIGN KEY (`para_id`) REFERENCES `para` (`id`),
  CONSTRAINT `mk_final_exam_table_room_table` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`),
  CONSTRAINT `mk_final_exam_table_semestr_table` FOREIGN KEY (`semestr_id`) REFERENCES `semestr` (`id`),
  CONSTRAINT `mk_final_exam_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `mk_final_exam_table_user_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `final_exam`
--

LOCK TABLES `final_exam` WRITE;
/*!40000 ALTER TABLE `final_exam` DISABLE KEYS */;
/*!40000 ALTER TABLE `final_exam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `final_exam_confirm`
--

DROP TABLE IF EXISTS `final_exam_confirm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `final_exam_confirm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `final_exam_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_name` varchar(255) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT 1,
  `qr_code` longtext DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_final_exam_confirm_table_final_exam_table` (`final_exam_id`),
  KEY `mk_final_exam_confirm_table_user_table` (`user_id`),
  CONSTRAINT `mk_final_exam_confirm_table_final_exam_table` FOREIGN KEY (`final_exam_id`) REFERENCES `final_exam` (`id`),
  CONSTRAINT `mk_final_exam_confirm_table_user_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `final_exam_confirm`
--

LOCK TABLES `final_exam_confirm` WRITE;
/*!40000 ALTER TABLE `final_exam_confirm` DISABLE KEYS */;
/*!40000 ALTER TABLE `final_exam_confirm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `final_exam_group`
--

DROP TABLE IF EXISTS `final_exam_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `final_exam_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `final_exam_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `edu_semestr_subject_id` int(11) DEFAULT NULL,
  `edu_semestr_id` int(11) DEFAULT NULL,
  `edu_plan_id` int(11) DEFAULT NULL,
  `vedomst` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `para_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `subject_id` int(11) DEFAULT NULL,
  `start_time` int(11) DEFAULT NULL,
  `finish_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mk_final_exam_group_table_final_exam_table` (`final_exam_id`),
  KEY `mk_final_exam_group_table_group_table` (`group_id`),
  KEY `mk_final_exam_group_table_edu_semestr_subject_table` (`edu_semestr_subject_id`),
  KEY `mk_final_exam_group_table_edu_semestr_table` (`edu_semestr_id`),
  KEY `mk_final_exam_group_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_final_exam_group_table_para_table` (`para_id`),
  KEY `mk_final_exam_group_table_user_table` (`user_id`),
  KEY `mk_final_exam_group_table_subject_table` (`subject_id`),
  CONSTRAINT `mk_final_exam_group_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_final_exam_group_table_edu_semestr_subject_table` FOREIGN KEY (`edu_semestr_subject_id`) REFERENCES `edu_semestr_subject` (`id`),
  CONSTRAINT `mk_final_exam_group_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`),
  CONSTRAINT `mk_final_exam_group_table_final_exam_table` FOREIGN KEY (`final_exam_id`) REFERENCES `final_exam` (`id`),
  CONSTRAINT `mk_final_exam_group_table_group_table` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `mk_final_exam_group_table_para_table` FOREIGN KEY (`para_id`) REFERENCES `para` (`id`),
  CONSTRAINT `mk_final_exam_group_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `mk_final_exam_group_table_user_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `final_exam_group`
--

LOCK TABLES `final_exam_group` WRITE;
/*!40000 ALTER TABLE `final_exam_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `final_exam_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `final_exam_test`
--

DROP TABLE IF EXISTS `final_exam_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `final_exam_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `final_exam_id` int(11) NOT NULL,
  `student_mark_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `attends_count` int(11) DEFAULT 1,
  `correct` int(11) DEFAULT 0,
  `ball` float DEFAULT 0,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_final_exam_test_table_final_exam_table` (`final_exam_id`),
  KEY `mk_final_exam_test_table_student_mark_table` (`student_mark_id`),
  KEY `mk_final_exam_test_table_student_table` (`student_id`),
  KEY `mk_final_exam_test_table_users_table` (`user_id`),
  CONSTRAINT `mk_final_exam_test_table_final_exam_table` FOREIGN KEY (`final_exam_id`) REFERENCES `final_exam` (`id`),
  CONSTRAINT `mk_final_exam_test_table_student_mark_table` FOREIGN KEY (`student_mark_id`) REFERENCES `student_mark` (`id`),
  CONSTRAINT `mk_final_exam_test_table_student_table` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `mk_final_exam_test_table_users_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `final_exam_test`
--

LOCK TABLES `final_exam_test` WRITE;
/*!40000 ALTER TABLE `final_exam_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `final_exam_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `final_exam_test_question`
--

DROP TABLE IF EXISTS `final_exam_test_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `final_exam_test_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `final_exam_test_start_id` int(11) NOT NULL,
  `student_mark_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `test_id` int(11) NOT NULL,
  `option_id` int(11) DEFAULT NULL,
  `is_correct` int(11) DEFAULT 0,
  `option` varchar(255) DEFAULT '0',
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_final_exam_test_question_table_final_exam_test_start_table` (`final_exam_test_start_id`),
  KEY `mk_final_exam_test_question_table_student_mark_table` (`student_mark_id`),
  KEY `mk_final_exam_test_question_table_student_table` (`student_id`),
  KEY `mk_final_exam_test_question_table_users_table` (`user_id`),
  CONSTRAINT `mk_final_exam_test_question_table_final_exam_test_start_table` FOREIGN KEY (`final_exam_test_start_id`) REFERENCES `final_exam_test_start` (`id`),
  CONSTRAINT `mk_final_exam_test_question_table_student_mark_table` FOREIGN KEY (`student_mark_id`) REFERENCES `student_mark` (`id`),
  CONSTRAINT `mk_final_exam_test_question_table_student_table` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `mk_final_exam_test_question_table_users_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `final_exam_test_question`
--

LOCK TABLES `final_exam_test_question` WRITE;
/*!40000 ALTER TABLE `final_exam_test_question` DISABLE KEYS */;
/*!40000 ALTER TABLE `final_exam_test_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `final_exam_test_start`
--

DROP TABLE IF EXISTS `final_exam_test_start`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `final_exam_test_start` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `final_exam_test_id` int(11) NOT NULL,
  `student_mark_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `start_time` int(11) DEFAULT NULL,
  `finish_time` int(11) DEFAULT NULL,
  `exam_type` int(11) DEFAULT 0,
  `exam_form_type` int(11) DEFAULT NULL,
  `correct` int(11) DEFAULT 0,
  `attends_count` int(11) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `ball` float DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_final_exam_test_start_table_final_exam_test_table` (`final_exam_test_id`),
  KEY `mk_final_exam_test_start_table_student_mark_table` (`student_mark_id`),
  KEY `mk_final_exam_test_start_table_student_table` (`student_id`),
  KEY `mk_final_exam_test_start_table_users_table` (`user_id`),
  CONSTRAINT `mk_final_exam_test_start_table_final_exam_test_table` FOREIGN KEY (`final_exam_test_id`) REFERENCES `final_exam_test` (`id`),
  CONSTRAINT `mk_final_exam_test_start_table_student_mark_table` FOREIGN KEY (`student_mark_id`) REFERENCES `student_mark` (`id`),
  CONSTRAINT `mk_final_exam_test_start_table_student_table` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `mk_final_exam_test_start_table_users_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `final_exam_test_start`
--

LOCK TABLES `final_exam_test_start` WRITE;
/*!40000 ALTER TABLE `final_exam_test_start` DISABLE KEYS */;
/*!40000 ALTER TABLE `final_exam_test_start` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `faculty_id` int(11) NOT NULL,
  `direction_id` int(11) NOT NULL,
  `edu_plan_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `unical_name` varchar(255) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unical_name` (`unical_name`),
  KEY `mk_group_table_faculty_table` (`faculty_id`),
  KEY `mk_group_table_direction_table` (`direction_id`),
  KEY `mk_group_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_group_table_languages_table` (`language_id`),
  CONSTRAINT `mk_group_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_group_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_group_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_group_table_languages_table` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kafedra`
--

DROP TABLE IF EXISTS `kafedra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kafedra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `faculty_id` int(11) NOT NULL,
  `direction_id` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `user_id` int(11) DEFAULT NULL COMMENT 'Lead of kafedra or Mudir',
  PRIMARY KEY (`id`),
  KEY `mk_kafedra_table_faculty_table` (`faculty_id`),
  KEY `mk_kafedra_table_direction_table` (`direction_id`),
  KEY `mk_kafedra_table_users_table` (`user_id`),
  CONSTRAINT `mk_kafedra_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_kafedra_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_kafedra_table_users_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kafedra`
--

LOCK TABLES `kafedra` WRITE;
/*!40000 ALTER TABLE `kafedra` DISABLE KEYS */;
/*!40000 ALTER TABLE `kafedra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keys`
--

DROP TABLE IF EXISTS `keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT 0,
  `updated_by` int(11) DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keys`
--

LOCK TABLES `keys` WRITE;
/*!40000 ALTER TABLE `keys` DISABLE KEYS */;
INSERT INTO `keys` VALUES (1,'ShokirjonMK',1,1,NULL,NULL,0,0,0),(2,'University',1,1,NULL,NULL,0,0,0),(3,'NeverGiveUp',1,1,NULL,NULL,0,0,0),(4,'E-UNIVERSITY',1,1,NULL,NULL,0,0,0),(5,'ThisIsKey',1,1,NULL,NULL,0,0,0),(6,'ENGEENE',1,1,NULL,NULL,0,0,0),(7,'MasterKey',1,1,NULL,NULL,0,0,0),(8,'CompyuterVISION',1,1,NULL,NULL,0,0,0),(9,'Supervisor',1,1,NULL,NULL,0,0,0),(10,'Administrator-U',1,1,NULL,NULL,0,0,0),(11,'UserGuest',1,1,NULL,NULL,0,0,0),(12,'Solutions',1,1,NULL,NULL,0,0,0),(13,'Productor',1,1,NULL,NULL,0,0,0);
/*!40000 ALTER TABLE `keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `lang_code` varchar(10) DEFAULT NULL,
  `locale` varchar(50) DEFAULT NULL,
  `rtl` smallint(6) DEFAULT 0,
  `default` smallint(6) DEFAULT 0,
  `sort` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx-setting-lang_code` (`lang_code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'O\'zbekcha','uz','uz_UZ',0,0,0,1),(2,'English','en','en_GB',0,0,0,1),(3,'Русский','ru','ru_RU',0,0,0,1),(4,'Deutsch','de','de_DE',0,0,0,0),(5,'Español','es','es_ES',0,0,0,0),(6,'Français','fr','fr_FR',0,0,0,0),(7,'Italiano','it','it_IT',0,0,0,0),(8,'Türkçe','tr','tr_TR',0,0,0,0);
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `load_rate`
--

DROP TABLE IF EXISTS `load_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_access_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `work_load_id` int(11) DEFAULT NULL,
  `work_rate_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_load_rate_table_user_access_table` (`user_access_id`),
  KEY `mk_load_rate_table_user_table` (`user_id`),
  KEY `mk_load_rate_table_work_load_table` (`work_load_id`),
  KEY `mk_load_rate_table_work_rate_table` (`work_rate_id`),
  CONSTRAINT `mk_load_rate_table_user_access_table` FOREIGN KEY (`user_access_id`) REFERENCES `user_access` (`id`),
  CONSTRAINT `mk_load_rate_table_user_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `mk_load_rate_table_work_load_table` FOREIGN KEY (`work_load_id`) REFERENCES `work_load` (`id`),
  CONSTRAINT `mk_load_rate_table_work_rate_table` FOREIGN KEY (`work_rate_id`) REFERENCES `work_rate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `load_rate`
--

LOCK TABLES `load_rate` WRITE;
/*!40000 ALTER TABLE `load_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `load_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_history`
--

DROP TABLE IF EXISTS `login_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` datetime DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `log_in_out` tinyint(1) DEFAULT NULL,
  `ip_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ip_data`)),
  `device` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `model_device` varchar(255) DEFAULT NULL,
  `data` text DEFAULT NULL,
  `host` text DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_history`
--

LOCK TABLES `login_history` WRITE;
/*!40000 ALTER TABLE `login_history` DISABLE KEYS */;
INSERT INTO `login_history` VALUES (1,'2024-12-17 15:24:49','195.158.6.58',2,1,NULL,'Windows 10','desktop',NULL,NULL,'{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\",\"browser_name\":\"Google Chrome\",\"browser_version\":\"131.0.0.0\",\"platform\":\"Windows 10\",\"device\":\"desktop\",\"session\":\"Google Chrome 131.0.0.0 \\/ Windows 10\"}','api.sarbon.university',1,1,1734431089,1734431089,0,0,0),(2,'2024-12-17 17:04:00','188.113.230.54',5,1,NULL,'iPhone','mobile',NULL,NULL,'{\"user_agent\":\"Mozilla\\/5.0 (iPhone; CPU iPhone OS 18_2_0 like Mac OS X) AppleWebKit\\/605.1.15 (KHTML, like Gecko) CriOS\\/131.0.6778.103 Mobile\\/15E148 Safari\\/604.1\",\"browser_name\":\"Apple Safari\",\"browser_version\":\"604.1\",\"platform\":\"iPhone\",\"device\":\"mobile\",\"session\":\"Apple Safari 604.1 \\/ iPhone\"}','api.sarbon.university',1,1,1734437040,1734437040,0,0,0),(3,'2024-12-17 17:07:47','195.158.6.58',4,1,NULL,'Windows 10','desktop',NULL,NULL,'{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\",\"browser_name\":\"Google Chrome\",\"browser_version\":\"131.0.0.0\",\"platform\":\"Windows 10\",\"device\":\"desktop\",\"session\":\"Google Chrome 131.0.0.0 \\/ Windows 10\"}','api.sarbon.university',1,1,1734437267,1734437267,0,0,0),(4,'2024-12-17 17:21:57','86.62.0.158',5,1,NULL,'Windows 10','desktop',NULL,NULL,'{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\",\"browser_name\":\"Google Chrome\",\"browser_version\":\"131.0.0.0\",\"platform\":\"Windows 10\",\"device\":\"desktop\",\"session\":\"Google Chrome 131.0.0.0 \\/ Windows 10\"}','api.sarbon.university',1,1,1734438117,1734438117,0,0,0);
/*!40000 ALTER TABLE `login_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mark_history`
--

DROP TABLE IF EXISTS `mark_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mark_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_mark_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ball` varchar(255) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mark_history`
--

LOCK TABLES `mark_history` WRITE;
/*!40000 ALTER TABLE `mark_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `mark_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration`
--

LOCK TABLES `migration` WRITE;
/*!40000 ALTER TABLE `migration` DISABLE KEYS */;
INSERT INTO `migration` VALUES ('m000000_000000_base',1734413784),('m130524_201442_init',1734413788),('m180121_120402_create_rbac_tables',1734413788),('m200605_201020_init_rbac',1734413788),('m200608_124459_table_languages',1734413788),('m200721_043848_create_countries_table',1734413788),('m200721_093042_create_region_table',1734413788),('m200721_093043_create_area_table',1734413789),('m211023_091910_translate',1734413789),('m230506_084016_create_building_table',1734413789),('m230506_084200_create_room_table',1734413790),('m230506_084611_create_edu_form_table',1734413790),('m230506_084621_create_edu_type_table',1734413790),('m230506_084952_create_edu_year_table',1734413790),('m230506_085325_create_course_table',1734413790),('m230506_085616_create_semestr_table',1734413790),('m230506_095932_create_faculty_table',1734413790),('m230506_100604_create_direction_table',1734413790),('m230506_101331_create_kafedra_table',1734413791),('m230506_101820_create_department_table',1734413791),('m230506_102500_create_edu_plan_table',1734413792),('m230506_103141_create_group_table',1734413792),('m230506_103936_create_edu_semestr_table',1734413794),('m230506_104222_create_subject_type_table',1734413794),('m230506_104243_create_subject_table',1734413794),('m230506_104244_create_subject_semestr_table',1734413795),('m230506_105342_create_edu_semestr_subject_table',1734413796),('m230506_110337_create_citizenship_table',1734413796),('m230506_110339_create_nationality_table',1734413796),('m230506_110930_create_profile_table',1734413798),('m230507_122309_create_keys_table',1734413799),('m230507_122329_create_password_encrypts_table',1734413799),('m230508_061345_create_auth_child_table',1734413799),('m230509_073530_create_work_load_table',1734413799),('m230509_073613_create_work_rate_table',1734413799),('m230510_054105_create_user_access_type_table',1734413799),('m230510_054116_create_user_access_table',1734413800),('m230511_092639_create_category_of_cohabitant_table',1734413800),('m230511_092736_create_residence_status_table',1734413800),('m230511_092808_create_social_category_table',1734413800),('m230511_092837_create_student_category_table',1734413800),('m230511_093543_create_student_table',1734413803),('m230512_075839_create_language_table',1734413803),('m230513_074605_create_teacher_access_table',1734413803),('m230520_135625_create_action_log_table',1734413803),('m230521_070851_create_login_history_table',1734413803),('m230528_071637_create_subject_category_table',1734413803),('m230528_071650_create_exams_type_table',1734413803),('m230528_071705_create_edu_semestr_subject_category_time_table',1734413804),('m230528_071715_create_edu_semestr_exams_type_table',1734413804),('m230610_130519_create_academic_degree_table',1734413804),('m230610_130558_create_degree_table',1734413804),('m230610_130629_create_degree_info_table',1734413804),('m230610_130657_create_diploma_type_table',1734413805),('m230610_130732_create_partiya_table',1734413805),('m230618_071117_create_subject_topic_table',1734413805),('m230619_062901_create_student_group_table',1734413805),('m230620_055542_create_para_table',1734413806),('m230620_055545_create_week_table',1734413806),('m230621_115024_create_subject_content_table',1734413806),('m230720_122058_create_student_mark_table',1734413809),('m230804_071057_create_test_table',1734413810),('m230804_071108_create_option_table',1734413810),('m230805_112359_add_column_to_subject_topic_table',1734413810),('m230909_044144_add_column_to_user_role_table',1734413810),('m230927_044620_create_load_rate_table',1734413811),('m240112_093859_create_final_exam_table',1734413814),('m240117_093514_create_final_exam_group_table',1734413816),('m240118_072027_create_final_exam_confirm_table',1734413816),('m240125_103328_create_subject_vedomst_table',1734413816),('m240125_112314_create_student_semestr_subject_table',1734413818),('m240127_050304_add_plan_to_student_group_table',1734413820),('m240127_053108_add_faculty_to_student_group_table',1734413820),('m240127_072821_create_student_semestr_subject_vedomst_table',1734413821),('m240127_112349_add_vedomst_to_student_mark_table',1734413822),('m240129_055644_add_subject_id_column_to_final_exam_group',1734413822),('m240206_053655_create_timetable_table',1734413824),('m240206_060608_create_timetable_date_table',1734413830),('m240212_050915_add_hour_column_to_timetable_table',1734413830),('m240214_052548_add_two_group_column_to_timetable_date_table',1734413830),('m240214_073836_add_type_column_to_timetable_date_table',1734413830),('m240217_094357_create_timetable_student_table',1734413831),('m240217_145646_add_attend_status_column_to_timetable_date_table',1734413831),('m240217_152411_create_timetable_reason_table',1734413833),('m240217_153529_create_timetable_attend_table',1734413836),('m240312_091534_add_subject__id_column_to_timetable_attend_table',1734413837),('m240312_092021_add_subject_category_id_column_to_timetable_attend_table',1734413837),('m240402_060934_add_para_id_column_to_timetable_date_table',1734413837),('m240408_041216_add_semestr_key_column_to_student_group_table',1734413837),('m240430_044355_add_parents_columns_to_profile_table',1734413838),('m240501_114335_create_timetable_ids_table',1734413838),('m240529_072624_add_change_password_type_column_to_users_table',1734413838),('m240529_100932_create_mark_history_table',1734413838),('m240606_085218_add_type_column_to_edu_semestr_subject_table',1734413838),('m240910_053252_create_test_body_table',1734413838),('m240913_060612_add_time_column_to_final_exam_table',1734413838),('m240913_063633_add_time_column_to_final_exam_group_table',1734413838),('m240914_055233_create_final_exam_test_table',1734413839),('m240914_061803_create_final_exam_test_start_table',1734413839),('m240914_061818_create_final_exam_test_question_table',1734413840),('m240925_114436_add_ball_column_to_final_exam_test_start_table',1734413840),('m241004_055115_add_language_id_column_to_final_exam_group_table',1734413840),('m241029_091727_create_room_ip_table',1734413840),('m241030_061603_add_building_id_column_to_room_ip_table',1734413841),('m241109_091350_add_minutes_column_to_subject_table',1734413841),('m241126_063233_add_hour_column_to_topic_table',1734413841),('m241126_065206_add_name_column_to_subject_semestr_table',1734413841),('m241127_070543_add_edu_semestr_subject_column_to_subject_vedomst_table',1734413841),('m241129_054644_add_main_column_to_subject_content_table',1734413841);
/*!40000 ALTER TABLE `migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nationality`
--

DROP TABLE IF EXISTS `nationality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nationality` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nationality`
--

LOCK TABLES `nationality` WRITE;
/*!40000 ALTER TABLE `nationality` DISABLE KEYS */;
/*!40000 ALTER TABLE `nationality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `option`
--

DROP TABLE IF EXISTS `option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `text` longtext DEFAULT NULL,
  `file` varchar(100) DEFAULT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT 0,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_option_table_test_table` (`test_id`),
  CONSTRAINT `mk_option_table_test_table` FOREIGN KEY (`test_id`) REFERENCES `test` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `option`
--

LOCK TABLES `option` WRITE;
/*!40000 ALTER TABLE `option` DISABLE KEYS */;
/*!40000 ALTER TABLE `option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `para`
--

DROP TABLE IF EXISTS `para`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `para` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_time` varchar(10) DEFAULT NULL,
  `end_time` varchar(10) DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `para`
--

LOCK TABLES `para` WRITE;
/*!40000 ALTER TABLE `para` DISABLE KEYS */;
/*!40000 ALTER TABLE `para` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partiya`
--

DROP TABLE IF EXISTS `partiya`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partiya` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partiya`
--

LOCK TABLES `partiya` WRITE;
/*!40000 ALTER TABLE `partiya` DISABLE KEYS */;
/*!40000 ALTER TABLE `partiya` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_encrypts`
--

DROP TABLE IF EXISTS `password_encrypts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_encrypts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `key_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `up_password_encrypts_user_id` (`user_id`),
  KEY `up_password_encrypts_key_id` (`key_id`),
  CONSTRAINT `up_password_encrypts_key_id` FOREIGN KEY (`key_id`) REFERENCES `keys` (`id`),
  CONSTRAINT `up_password_encrypts_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_encrypts`
--

LOCK TABLES `password_encrypts` WRITE;
/*!40000 ALTER TABLE `password_encrypts` DISABLE KEYS */;
INSERT INTO `password_encrypts` VALUES (1,5,'8AVEIye9vss=',9,1734436012,1734436012);
/*!40000 ALTER TABLE `password_encrypts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `checked` tinyint(3) DEFAULT 0,
  `checked_full` tinyint(3) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `passport_serial` varchar(255) DEFAULT NULL,
  `passport_number` varchar(255) DEFAULT NULL,
  `passport_pin` varchar(15) DEFAULT NULL,
  `passport_issued_date` date DEFAULT NULL,
  `passport_given_date` date DEFAULT NULL,
  `passport_given_by` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` tinyint(1) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `phone_secondary` varchar(50) DEFAULT NULL,
  `passport_file` varchar(255) DEFAULT NULL,
  `all_file` varchar(255) DEFAULT NULL,
  `countries_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `permanent_countries_id` int(11) DEFAULT NULL,
  `permanent_region_id` int(11) DEFAULT NULL,
  `permanent_area_id` int(11) DEFAULT NULL,
  `permanent_address` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_foreign` tinyint(1) DEFAULT NULL,
  `citizenship_id` int(11) DEFAULT NULL COMMENT 'citizenship_id fuqarolik turi',
  `nationality_id` int(11) DEFAULT NULL COMMENT 'millati id',
  `telegram_chat_id` int(11) DEFAULT NULL,
  `diploma_type_id` int(11) DEFAULT NULL COMMENT 'diploma_type',
  `degree_id` int(11) DEFAULT NULL COMMENT 'darajasi id',
  `academic_degree_id` int(11) DEFAULT NULL COMMENT 'academic_degree id',
  `degree_info_id` int(11) DEFAULT NULL COMMENT 'degree_info id',
  `partiya_id` int(11) DEFAULT NULL COMMENT 'partiya id',
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `father_fio` varchar(255) DEFAULT NULL,
  `father_number` varchar(255) DEFAULT NULL,
  `father_info` text DEFAULT NULL,
  `mather_fio` varchar(255) DEFAULT NULL,
  `mather_number` varchar(255) DEFAULT NULL,
  `mather_info` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mk_profile_table_users_table` (`user_id`),
  KEY `mk_profile_table_countries_table` (`countries_id`),
  KEY `mk_profile_table_region_table` (`region_id`),
  KEY `mk_profile_table_area_table` (`area_id`),
  KEY `mk_profile_table_nationality_table` (`nationality_id`),
  KEY `ui_profile_table_citizenships_table` (`citizenship_id`),
  KEY `mk_profile_table_permanent_countries_table` (`permanent_countries_id`),
  KEY `mk_profile_table_permanent_region_table` (`permanent_region_id`),
  KEY `mk_profile_table_permanent_area_table` (`permanent_area_id`),
  CONSTRAINT `mk_profile_table_area_table` FOREIGN KEY (`area_id`) REFERENCES `area` (`id`),
  CONSTRAINT `mk_profile_table_countries_table` FOREIGN KEY (`countries_id`) REFERENCES `countries` (`id`),
  CONSTRAINT `mk_profile_table_nationality_table` FOREIGN KEY (`nationality_id`) REFERENCES `nationality` (`id`),
  CONSTRAINT `mk_profile_table_permanent_area_table` FOREIGN KEY (`permanent_area_id`) REFERENCES `area` (`id`),
  CONSTRAINT `mk_profile_table_permanent_countries_table` FOREIGN KEY (`permanent_countries_id`) REFERENCES `countries` (`id`),
  CONSTRAINT `mk_profile_table_permanent_region_table` FOREIGN KEY (`permanent_region_id`) REFERENCES `region` (`id`),
  CONSTRAINT `mk_profile_table_region_table` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`),
  CONSTRAINT `mk_profile_table_users_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `ui_profile_table_citizenships_table` FOREIGN KEY (`citizenship_id`) REFERENCES `citizenship` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,1,0,0,NULL,'ShokirjonMK','ShokirjonMK_uz','ShokirjonMKuz',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1734413798,1734413798,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL),(2,2,0,0,NULL,'blackmoon','blackmoon_uz','blackmoonuz',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1734413798,1734413798,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL),(3,3,0,0,NULL,'Iqboljon','Uraimov','Anvarjon o\'g\'li',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1734413798,1734413798,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL),(4,4,0,0,NULL,'Ahror','Ahror','Ahror',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1734413798,1734413798,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL),(5,5,0,0,NULL,'N','N','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'+998 (11) 111-11-11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,10,1734436012,1734436012,2,2,0,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `name_kirill` varchar(150) DEFAULT NULL,
  `slug` varchar(150) DEFAULT NULL,
  `country_id` int(11) DEFAULT 229,
  `parent_id` int(11) DEFAULT NULL,
  `type` tinyint(1) DEFAULT 0,
  `postcode` varchar(150) DEFAULT NULL,
  `lat` varchar(100) DEFAULT NULL,
  `long` varchar(100) DEFAULT NULL,
  `sort` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `created_on` timestamp NULL DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_on` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx-region-country_id` (`country_id`),
  KEY `idx-region-parent_id` (`parent_id`),
  CONSTRAINT `fk-region-country_id` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk-region-parent_id` FOREIGN KEY (`parent_id`) REFERENCES `region` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` VALUES (1,'Qoraqalpog\'iston Respublikasi','Қорақалпоғистон Республикаси',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(2,'Andijon viloyati','Андижон вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(3,'Namangan viloyati','Наманган вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(4,'Farg\'ona viloyati','Фарғона вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(5,'Buxoro viloyati','Бухоро вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(6,'Xorazm viloyati','Хоразм вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(7,'Surxondaryo viloyati','Сурхондарё вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(8,'Qashqadaryo viloyati','Қашқадарё вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(9,'Jizzax viloyati','Жиззах вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(10,'Navoiy viloyati','Навоий вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(11,'Samarqand viloyati','Самарқанд вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(12,'Sirdaryo viloyati','Сирдарё вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(13,'Toshkent viloyati','Тошкент вилояти',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(14,'Toshkent shahri','Тошкент шаҳри',NULL,235,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0),(15,'Boshqa','Бошқа',NULL,19,NULL,0,NULL,NULL,NULL,0,1,NULL,0,NULL,0);
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `residence_status`
--

DROP TABLE IF EXISTS `residence_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `residence_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `residence_status`
--

LOCK TABLES `residence_status` WRITE;
/*!40000 ALTER TABLE `residence_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `residence_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `building_id` int(11) NOT NULL,
  `capacity` int(11) NOT NULL,
  `room_size` float DEFAULT NULL,
  `room_type_id` int(11) DEFAULT NULL COMMENT '1-Maruza xonasi, 2-Seminar xonasi, 3-Xodim xonasi, 4-qoshimcha xona',
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_room_table_building_table` (`building_id`),
  KEY `mk_room_table_room_type_table` (`room_type_id`),
  CONSTRAINT `mk_room_table_building_table` FOREIGN KEY (`building_id`) REFERENCES `building` (`id`),
  CONSTRAINT `mk_room_table_room_type_table` FOREIGN KEY (`room_type_id`) REFERENCES `room_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_ip`
--

DROP TABLE IF EXISTS `room_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `building_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mk_room_ip_table_room_table` (`room_id`),
  KEY `mk_room_ip_table_building_table` (`building_id`),
  CONSTRAINT `mk_room_ip_table_building_table` FOREIGN KEY (`building_id`) REFERENCES `building` (`id`),
  CONSTRAINT `mk_room_ip_table_room_table` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_ip`
--

LOCK TABLES `room_ip` WRITE;
/*!40000 ALTER TABLE `room_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `room_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_type`
--

DROP TABLE IF EXISTS `room_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_type`
--

LOCK TABLES `room_type` WRITE;
/*!40000 ALTER TABLE `room_type` DISABLE KEYS */;
INSERT INTO `room_type` VALUES (1,1,1,1734438312,1734438312,5,0,0),(2,1,1,1734438395,1734438395,5,0,0),(3,1,1,1734438433,1734438433,5,0,0);
/*!40000 ALTER TABLE `room_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semestr`
--

DROP TABLE IF EXISTS `semestr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `semestr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_semestr_table_course_table` (`course_id`),
  CONSTRAINT `mk_semestr_table_course_table` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semestr`
--

LOCK TABLES `semestr` WRITE;
/*!40000 ALTER TABLE `semestr` DISABLE KEYS */;
INSERT INTO `semestr` VALUES (1,1,1,1,1,1734432497,1734432497,2,0,0),(2,1,1,1,1,1734432503,1734432503,2,0,0),(3,2,1,1,1,1734432509,1734432509,2,0,0),(4,2,1,1,1,1734432516,1734432516,2,0,0),(5,3,1,1,1,1734432527,1734432527,2,0,0),(6,3,1,1,1,1734432533,1734432533,2,0,0),(7,4,1,1,1,1734432540,1734432540,2,0,0),(8,4,1,1,1,1734432546,1734432546,2,0,0),(9,5,1,1,1,1734432553,1734432553,2,0,0),(10,5,1,1,1,1734432559,1734432559,2,0,0);
/*!40000 ALTER TABLE `semestr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_category`
--

DROP TABLE IF EXISTS `social_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_category`
--

LOCK TABLES `social_category` WRITE;
/*!40000 ALTER TABLE `social_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `tutor_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `direction_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `edu_year_id` int(11) DEFAULT NULL,
  `edu_type_id` int(11) DEFAULT NULL,
  `edu_form_id` int(11) DEFAULT NULL,
  `edu_lang_id` int(11) DEFAULT NULL,
  `edu_plan_id` int(11) DEFAULT NULL,
  `is_contract` int(11) DEFAULT NULL,
  `diplom_number` int(11) DEFAULT NULL,
  `diplom_seria` varchar(255) DEFAULT NULL,
  `diplom_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `gender` tinyint(1) DEFAULT NULL,
  `social_category_id` int(11) DEFAULT NULL,
  `residence_status_id` int(11) DEFAULT NULL,
  `category_of_cohabitant_id` int(11) DEFAULT NULL,
  `student_category_id` int(11) DEFAULT NULL,
  `partners_count` int(11) DEFAULT NULL,
  `live_location` text DEFAULT NULL,
  `parent_phone` varchar(55) DEFAULT NULL,
  `res_person_phone` varchar(55) DEFAULT NULL,
  `last_education` text DEFAULT NULL,
  `type` tinyint(1) DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_student_table_users_table` (`user_id`),
  KEY `mk_student_table_group_table` (`group_id`),
  KEY `mk_student_table_tutor_table` (`tutor_id`),
  KEY `mk_student_table_faculty_table` (`faculty_id`),
  KEY `mk_student_table_direction_table` (`direction_id`),
  KEY `mk_student_table_course_table` (`course_id`),
  KEY `mk_student_table_edu_year_table` (`edu_year_id`),
  KEY `mk_student_table_edu_type_table` (`edu_type_id`),
  KEY `mk_student_table_edu_form_table` (`edu_form_id`),
  KEY `mk_student_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_student_table_social_category_table` (`social_category_id`),
  KEY `mk_student_table_residence_status_table` (`residence_status_id`),
  KEY `mk_student_table_category_of_cohabitant_table` (`category_of_cohabitant_id`),
  KEY `mk_student_table_student_category_table` (`student_category_id`),
  CONSTRAINT `mk_student_table_category_of_cohabitant_table` FOREIGN KEY (`category_of_cohabitant_id`) REFERENCES `category_of_cohabitant` (`id`),
  CONSTRAINT `mk_student_table_course_table` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
  CONSTRAINT `mk_student_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_student_table_edu_form_table` FOREIGN KEY (`edu_form_id`) REFERENCES `edu_form` (`id`),
  CONSTRAINT `mk_student_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_student_table_edu_type_table` FOREIGN KEY (`edu_type_id`) REFERENCES `edu_type` (`id`),
  CONSTRAINT `mk_student_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_student_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_student_table_group_table` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `mk_student_table_residence_status_table` FOREIGN KEY (`residence_status_id`) REFERENCES `residence_status` (`id`),
  CONSTRAINT `mk_student_table_social_category_table` FOREIGN KEY (`social_category_id`) REFERENCES `social_category` (`id`),
  CONSTRAINT `mk_student_table_student_category_table` FOREIGN KEY (`student_category_id`) REFERENCES `student_category` (`id`),
  CONSTRAINT `mk_student_table_tutor_table` FOREIGN KEY (`tutor_id`) REFERENCES `users` (`id`),
  CONSTRAINT `mk_student_table_users_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_category`
--

DROP TABLE IF EXISTS `student_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_category`
--

LOCK TABLES `student_category` WRITE;
/*!40000 ALTER TABLE `student_category` DISABLE KEYS */;
INSERT INTO `student_category` VALUES (1,1,1,1734433177,1734433177,2,0,0),(2,1,1,1734433184,1734433184,2,0,0),(3,1,1,1734433190,1734433190,2,0,0);
/*!40000 ALTER TABLE `student_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_group`
--

DROP TABLE IF EXISTS `student_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `edu_year_id` int(11) DEFAULT NULL,
  `edu_plan_id` int(11) DEFAULT NULL,
  `edu_semestr_id` int(11) DEFAULT NULL,
  `edu_form_id` int(11) DEFAULT NULL,
  `semestr_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `direction_id` int(11) DEFAULT NULL,
  `semestr_key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `semestr_key` (`semestr_key`),
  KEY `mk_student_group_table_student_table` (`student_id`),
  KEY `mk_student_group_table_group_table` (`group_id`),
  KEY `mk_student_group_table_edu_year_table` (`edu_year_id`),
  KEY `mk_student_group_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_student_group_table_edu_semestr_table` (`edu_semestr_id`),
  KEY `mk_student_group_table_semestr_table` (`semestr_id`),
  KEY `mk_student_group_table_course_table` (`course_id`),
  KEY `mk_student_group_table_edu_form_table` (`edu_form_id`),
  KEY `mk_student_group_table_faculty_table` (`faculty_id`),
  KEY `mk_student_group_table_direction_table` (`direction_id`),
  CONSTRAINT `mk_student_group_table_course_table` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
  CONSTRAINT `mk_student_group_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_student_group_table_edu_form_table` FOREIGN KEY (`edu_form_id`) REFERENCES `edu_form` (`id`),
  CONSTRAINT `mk_student_group_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_student_group_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`),
  CONSTRAINT `mk_student_group_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_student_group_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_student_group_table_group_table` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `mk_student_group_table_semestr_table` FOREIGN KEY (`semestr_id`) REFERENCES `semestr` (`id`),
  CONSTRAINT `mk_student_group_table_student_table` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_group`
--

LOCK TABLES `student_group` WRITE;
/*!40000 ALTER TABLE `student_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_mark`
--

DROP TABLE IF EXISTS `student_mark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_mark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `edu_semestr_exams_type_id` int(11) NOT NULL,
  `exam_type_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_user_id` int(11) NOT NULL,
  `ball` int(11) DEFAULT 0,
  `max_ball` int(11) NOT NULL,
  `edu_semestr_subject_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `edu_plan_id` int(11) DEFAULT NULL,
  `edu_semestr_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `direction_id` int(11) DEFAULT NULL,
  `semestr_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT 0,
  `passed` int(11) DEFAULT NULL,
  `attend` int(11) DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `student_semestr_subject_vedomst_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mk_student_mark_table_edu_semestr_exams_type_table` (`edu_semestr_exams_type_id`),
  KEY `mk_student_mark_table_exam_type_table` (`exam_type_id`),
  KEY `mk_student_mark_table_student_table` (`student_id`),
  KEY `mk_student_mark_table_student_user_table` (`student_user_id`),
  KEY `mk_student_mark_table_group_table` (`group_id`),
  KEY `mk_student_mark_table_edu_semestr_subject_table` (`edu_semestr_subject_id`),
  KEY `mk_student_mark_table_subject_table` (`subject_id`),
  KEY `mk_student_mark_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_student_mark_table_edu_semestr_table` (`edu_semestr_id`),
  KEY `mk_student_mark_table_faculty_table` (`faculty_id`),
  KEY `mk_student_mark_table_direction_table` (`direction_id`),
  KEY `mk_student_mark_table_semestr_table` (`semestr_id`),
  KEY `mk_student_mark_table_course_table` (`course_id`),
  KEY `mk_student_mark_table_student_semestr_subject_vedomst_table` (`student_semestr_subject_vedomst_id`),
  CONSTRAINT `mk_student_mark_table_course_table` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
  CONSTRAINT `mk_student_mark_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_student_mark_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_student_mark_table_edu_semestr_exams_type_table` FOREIGN KEY (`edu_semestr_exams_type_id`) REFERENCES `edu_semestr_exams_type` (`id`),
  CONSTRAINT `mk_student_mark_table_edu_semestr_subject_table` FOREIGN KEY (`edu_semestr_subject_id`) REFERENCES `edu_semestr_subject` (`id`),
  CONSTRAINT `mk_student_mark_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`),
  CONSTRAINT `mk_student_mark_table_exam_type_table` FOREIGN KEY (`exam_type_id`) REFERENCES `exams_type` (`id`),
  CONSTRAINT `mk_student_mark_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_student_mark_table_group_table` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `mk_student_mark_table_semestr_table` FOREIGN KEY (`semestr_id`) REFERENCES `semestr` (`id`),
  CONSTRAINT `mk_student_mark_table_student_semestr_subject_vedomst_table` FOREIGN KEY (`student_semestr_subject_vedomst_id`) REFERENCES `student_semestr_subject_vedomst` (`id`),
  CONSTRAINT `mk_student_mark_table_student_table` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `mk_student_mark_table_student_user_table` FOREIGN KEY (`student_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `mk_student_mark_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_mark`
--

LOCK TABLES `student_mark` WRITE;
/*!40000 ALTER TABLE `student_mark` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_mark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_semestr_subject`
--

DROP TABLE IF EXISTS `student_semestr_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_semestr_subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `edu_plan_id` int(11) NOT NULL,
  `edu_semestr_id` int(11) NOT NULL,
  `edu_semestr_subject_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_user_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `direction_id` int(11) DEFAULT NULL,
  `edu_form_id` int(11) DEFAULT NULL,
  `edu_year_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `semestr_id` int(11) DEFAULT NULL,
  `all_ball` float DEFAULT 0,
  `closed` int(11) DEFAULT 0,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_student_semestr_subject_table_edu_semestr_subject_table` (`edu_semestr_subject_id`),
  KEY `mk_student_semestr_subject_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_student_semestr_subject_table_edu_semestr_table` (`edu_semestr_id`),
  KEY `mk_student_semestr_subject_table_student_table` (`student_id`),
  KEY `mk_student_semestr_subject_table_student_user_table` (`student_user_id`),
  KEY `mk_student_semestr_subject_table_faculty_table` (`faculty_id`),
  KEY `mk_student_semestr_subject_table_direction_table` (`direction_id`),
  KEY `mk_student_semestr_subject_table_edu_form_table` (`edu_form_id`),
  KEY `mk_student_semestr_subject_table_edu_year_table` (`edu_year_id`),
  KEY `mk_student_semestr_subject_table_course_table` (`course_id`),
  KEY `mk_student_semestr_subject_table_semestr_table` (`semestr_id`),
  CONSTRAINT `mk_student_semestr_subject_table_course_table` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
  CONSTRAINT `mk_student_semestr_subject_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_student_semestr_subject_table_edu_form_table` FOREIGN KEY (`edu_form_id`) REFERENCES `edu_form` (`id`),
  CONSTRAINT `mk_student_semestr_subject_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_student_semestr_subject_table_edu_semestr_subject_table` FOREIGN KEY (`edu_semestr_subject_id`) REFERENCES `edu_semestr_subject` (`id`),
  CONSTRAINT `mk_student_semestr_subject_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`),
  CONSTRAINT `mk_student_semestr_subject_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_student_semestr_subject_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_student_semestr_subject_table_semestr_table` FOREIGN KEY (`semestr_id`) REFERENCES `semestr` (`id`),
  CONSTRAINT `mk_student_semestr_subject_table_student_table` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `mk_student_semestr_subject_table_student_user_table` FOREIGN KEY (`student_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_semestr_subject`
--

LOCK TABLES `student_semestr_subject` WRITE;
/*!40000 ALTER TABLE `student_semestr_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_semestr_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_semestr_subject_vedomst`
--

DROP TABLE IF EXISTS `student_semestr_subject_vedomst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_semestr_subject_vedomst` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_semestr_subject_id` int(11) DEFAULT NULL,
  `subject_id` int(11) NOT NULL,
  `edu_year_id` int(11) DEFAULT NULL,
  `semestr_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_user_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `ball` int(11) DEFAULT 0,
  `passed` int(11) DEFAULT 0,
  `vedomst` int(11) NOT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `edu_semestr_subject_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mk_student_semestr_subject_vedomst_table_s_s_s_table` (`student_semestr_subject_id`),
  KEY `mk_student_semestr_subject_vedomst_table_subject_table` (`subject_id`),
  KEY `mk_student_semestr_subject_vedomst_table_edu_year_table` (`edu_year_id`),
  KEY `mk_student_semestr_subject_vedomst_table_semestr_table` (`semestr_id`),
  KEY `mk_student_semestr_subject_vedomst_table_student_table` (`student_id`),
  KEY `mk_student_semestr_subject_vedomst_table_student_user_table` (`student_user_id`),
  KEY `mk_student_semestr_subject_vedomst_table_group_table` (`group_id`),
  KEY `mk_edu_subject_table_student_semestr_vedomst_table` (`edu_semestr_subject_id`),
  CONSTRAINT `mk_edu_subject_table_student_semestr_vedomst_table` FOREIGN KEY (`edu_semestr_subject_id`) REFERENCES `edu_semestr_subject` (`id`),
  CONSTRAINT `mk_student_semestr_subject_vedomst_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_student_semestr_subject_vedomst_table_group_table` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `mk_student_semestr_subject_vedomst_table_s_s_s_table` FOREIGN KEY (`student_semestr_subject_id`) REFERENCES `student_semestr_subject` (`id`),
  CONSTRAINT `mk_student_semestr_subject_vedomst_table_semestr_table` FOREIGN KEY (`semestr_id`) REFERENCES `semestr` (`id`),
  CONSTRAINT `mk_student_semestr_subject_vedomst_table_student_table` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `mk_student_semestr_subject_vedomst_table_student_user_table` FOREIGN KEY (`student_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `mk_student_semestr_subject_vedomst_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_semestr_subject_vedomst`
--

LOCK TABLES `student_semestr_subject_vedomst` WRITE;
/*!40000 ALTER TABLE `student_semestr_subject_vedomst` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_semestr_subject_vedomst` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kafedra_id` int(11) NOT NULL,
  `edu_type_id` int(11) NOT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `question_count` int(11) DEFAULT 20,
  `all_time` int(11) DEFAULT 40,
  PRIMARY KEY (`id`),
  KEY `mk_subject_table_kafedra_table` (`kafedra_id`),
  KEY `mk_subject_table_edu_type_table` (`edu_type_id`),
  CONSTRAINT `mk_subject_table_edu_type_table` FOREIGN KEY (`edu_type_id`) REFERENCES `edu_type` (`id`),
  CONSTRAINT `mk_subject_table_kafedra_table` FOREIGN KEY (`kafedra_id`) REFERENCES `kafedra` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_category`
--

DROP TABLE IF EXISTS `subject_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_category`
--

LOCK TABLES `subject_category` WRITE;
/*!40000 ALTER TABLE `subject_category` DISABLE KEYS */;
INSERT INTO `subject_category` VALUES (1,NULL,1,1,1734433080,1734433080,2,0,0),(2,NULL,1,1,1734433086,1734433086,2,0,0),(3,NULL,1,1,1734433092,1734433092,2,0,0),(4,NULL,1,1,1734433131,1734433131,2,0,0),(5,NULL,1,1,1734433140,1734433140,2,0,0),(6,NULL,1,1,1734433148,1734433148,2,0,0);
/*!40000 ALTER TABLE `subject_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_content`
--

DROP TABLE IF EXISTS `subject_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_topic_id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `subject_semestr_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `teacher_access_id` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `text` longtext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `file_extension` varchar(50) DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `main` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_subject_content_table_subject_topic_table` (`subject_topic_id`),
  KEY `mk_subject_content_table_subject_table` (`subject_id`),
  KEY `mk_subject_content_table_subject_semestr_table` (`subject_semestr_id`),
  KEY `mk_subject_content_table_user_table` (`user_id`),
  KEY `mk_subject_content_table_teacher_access_table` (`teacher_access_id`),
  CONSTRAINT `mk_subject_content_table_subject_semestr_table` FOREIGN KEY (`subject_semestr_id`) REFERENCES `subject_semestr` (`id`),
  CONSTRAINT `mk_subject_content_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `mk_subject_content_table_subject_topic_table` FOREIGN KEY (`subject_topic_id`) REFERENCES `subject_topic` (`id`),
  CONSTRAINT `mk_subject_content_table_teacher_access_table` FOREIGN KEY (`teacher_access_id`) REFERENCES `teacher_access` (`id`),
  CONSTRAINT `mk_subject_content_table_user_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_content`
--

LOCK TABLES `subject_content` WRITE;
/*!40000 ALTER TABLE `subject_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `subject_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_semestr`
--

DROP TABLE IF EXISTS `subject_semestr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_semestr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) NOT NULL,
  `semestr_id` int(11) DEFAULT NULL,
  `kafedra_id` int(11) DEFAULT NULL,
  `edu_year_id` int(11) DEFAULT NULL,
  `subject_type_id` int(11) DEFAULT NULL,
  `edu_form_id` int(11) DEFAULT NULL,
  `credit` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mk_subject_semestr_table_subject_table` (`subject_id`),
  KEY `mk_subject_semestr_table_semestr_table` (`semestr_id`),
  KEY `mk_subject_semestr_table_kafedra_table` (`kafedra_id`),
  KEY `mk_subject_semestr_table_edu_year_table` (`edu_year_id`),
  KEY `mk_subject_semestr_table_subject_type_table` (`subject_type_id`),
  KEY `mk_subject_semestr_table_edu_form_table` (`edu_form_id`),
  CONSTRAINT `mk_subject_semestr_table_edu_form_table` FOREIGN KEY (`edu_form_id`) REFERENCES `edu_form` (`id`),
  CONSTRAINT `mk_subject_semestr_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_subject_semestr_table_kafedra_table` FOREIGN KEY (`kafedra_id`) REFERENCES `kafedra` (`id`),
  CONSTRAINT `mk_subject_semestr_table_semestr_table` FOREIGN KEY (`semestr_id`) REFERENCES `semestr` (`id`),
  CONSTRAINT `mk_subject_semestr_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `mk_subject_semestr_table_subject_type_table` FOREIGN KEY (`subject_type_id`) REFERENCES `subject_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_semestr`
--

LOCK TABLES `subject_semestr` WRITE;
/*!40000 ALTER TABLE `subject_semestr` DISABLE KEYS */;
/*!40000 ALTER TABLE `subject_semestr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_topic`
--

DROP TABLE IF EXISTS `subject_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_semestr_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `lang_id` int(11) NOT NULL,
  `subject_category_id` int(11) DEFAULT NULL COMMENT 'Fan turlari boyicha topic uchun',
  `name` text NOT NULL,
  `description` text DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `hours` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_subject_topic_table_subject_semestr_table` (`subject_semestr_id`),
  KEY `mk_subject_topic_table_subject_table` (`subject_id`),
  KEY `mk_subject_topic_table_lang_table` (`lang_id`),
  KEY `mk_subject_topic_table_subject_category_table` (`subject_category_id`),
  CONSTRAINT `mk_subject_topic_table_lang_table` FOREIGN KEY (`lang_id`) REFERENCES `language` (`id`),
  CONSTRAINT `mk_subject_topic_table_subject_category_table` FOREIGN KEY (`subject_category_id`) REFERENCES `subject_category` (`id`),
  CONSTRAINT `mk_subject_topic_table_subject_semestr_table` FOREIGN KEY (`subject_semestr_id`) REFERENCES `subject_semestr` (`id`),
  CONSTRAINT `mk_subject_topic_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_topic`
--

LOCK TABLES `subject_topic` WRITE;
/*!40000 ALTER TABLE `subject_topic` DISABLE KEYS */;
/*!40000 ALTER TABLE `subject_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_type`
--

DROP TABLE IF EXISTS `subject_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_type`
--

LOCK TABLES `subject_type` WRITE;
/*!40000 ALTER TABLE `subject_type` DISABLE KEYS */;
INSERT INTO `subject_type` VALUES (1,1,1,1734432945,1734432945,2,0,0),(2,1,1,1734432952,1734432952,2,0,0);
/*!40000 ALTER TABLE `subject_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_vedomst`
--

DROP TABLE IF EXISTS `subject_vedomst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_vedomst` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `edu_semestr_subject_id` int(11) NOT NULL,
  `edu_plan_id` int(11) NOT NULL,
  `edu_semestr_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_subject_vedomst_table_edu_semestr_subject_table` (`edu_semestr_subject_id`),
  KEY `mk_subject_vedomst_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_subject_vedomst_table_edu_semestr_table` (`edu_semestr_id`),
  CONSTRAINT `mk_subject_vedomst_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_subject_vedomst_table_edu_semestr_subject_table` FOREIGN KEY (`edu_semestr_subject_id`) REFERENCES `edu_semestr_subject` (`id`),
  CONSTRAINT `mk_subject_vedomst_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_vedomst`
--

LOCK TABLES `subject_vedomst` WRITE;
/*!40000 ALTER TABLE `subject_vedomst` DISABLE KEYS */;
/*!40000 ALTER TABLE `subject_vedomst` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_access`
--

DROP TABLE IF EXISTS `teacher_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `subject_semestr_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `is_lecture` tinyint(1) DEFAULT 0,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_teacher_access_table_users_table` (`user_id`),
  KEY `mk_teacher_access_table_subject_table` (`subject_id`),
  KEY `mk_teacher_access_table_subject_semestr_table` (`subject_semestr_id`),
  KEY `mk_teacher_access_table_language_table` (`language_id`),
  CONSTRAINT `mk_teacher_access_table_language_table` FOREIGN KEY (`language_id`) REFERENCES `language` (`id`),
  CONSTRAINT `mk_teacher_access_table_subject_semestr_table` FOREIGN KEY (`subject_semestr_id`) REFERENCES `subject_semestr` (`id`),
  CONSTRAINT `mk_teacher_access_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `mk_teacher_access_table_users_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_access`
--

LOCK TABLES `teacher_access` WRITE;
/*!40000 ALTER TABLE `teacher_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `teacher_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) DEFAULT NULL,
  `subject_semestr_id` int(11) DEFAULT NULL,
  `kafedra_id` int(11) DEFAULT NULL,
  `exam_type_id` int(11) DEFAULT NULL,
  `subject_topic_id` int(11) DEFAULT NULL,
  `language_id` int(11) DEFAULT NULL,
  `is_checked` int(11) DEFAULT 0,
  `level` int(11) DEFAULT 0,
  `ball` int(11) DEFAULT 1,
  `type` int(11) NOT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_test_table_subject_table` (`subject_id`),
  KEY `mk_test_table_subject_semestr_table` (`subject_semestr_id`),
  KEY `mk_test_table_kafedra_table` (`kafedra_id`),
  KEY `mk_test_table_exam_type_table` (`exam_type_id`),
  KEY `mk_test_table_subject_topic_table` (`subject_topic_id`),
  KEY `mk_test_table_language_table` (`language_id`),
  CONSTRAINT `mk_test_table_exam_type_table` FOREIGN KEY (`exam_type_id`) REFERENCES `exams_type` (`id`),
  CONSTRAINT `mk_test_table_kafedra_table` FOREIGN KEY (`kafedra_id`) REFERENCES `kafedra` (`id`),
  CONSTRAINT `mk_test_table_language_table` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`),
  CONSTRAINT `mk_test_table_subject_semestr_table` FOREIGN KEY (`subject_semestr_id`) REFERENCES `subject_semestr` (`id`),
  CONSTRAINT `mk_test_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `mk_test_table_subject_topic_table` FOREIGN KEY (`subject_topic_id`) REFERENCES `subject_topic` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_body`
--

DROP TABLE IF EXISTS `test_body`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_body` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `text` longtext DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_test_body_table_test_table` (`test_id`),
  CONSTRAINT `mk_test_body_table_test_table` FOREIGN KEY (`test_id`) REFERENCES `test` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_body`
--

LOCK TABLES `test_body` WRITE;
/*!40000 ALTER TABLE `test_body` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_body` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable`
--

DROP TABLE IF EXISTS `timetable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ids` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `edu_semestr_subject_id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `subject_category_id` int(11) DEFAULT NULL,
  `edu_plan_id` int(11) DEFAULT NULL,
  `edu_semestr_id` int(11) DEFAULT NULL,
  `edu_form_id` int(11) DEFAULT NULL,
  `edu_year_id` int(11) DEFAULT NULL,
  `edu_type_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `direction_id` int(11) DEFAULT NULL,
  `semestr_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT 0,
  `two_group` int(11) DEFAULT 0,
  `group_type` int(11) DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `hour` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-timetable-ids` (`ids`),
  KEY `mk_timetable_table_group_table` (`group_id`),
  KEY `mk_timetable_table_edu_semestr_subject_table` (`edu_semestr_subject_id`),
  KEY `mk_timetable_table_subject_table` (`subject_id`),
  KEY `mk_timetable_table_subject_category_table` (`subject_category_id`),
  KEY `mk_timetable_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_timetable_table_edu_semestr_table` (`edu_semestr_id`),
  KEY `mk_timetable_table_edu_form_table` (`edu_form_id`),
  KEY `mk_timetable_table_edu_year_table` (`edu_year_id`),
  KEY `mk_timetable_table_edu_type_table` (`edu_type_id`),
  KEY `mk_timetable_table_faculty_table` (`faculty_id`),
  KEY `mk_timetable_table_direction_table` (`direction_id`),
  KEY `mk_timetable_table_semestr_table` (`semestr_id`),
  KEY `mk_timetable_table_course_table` (`course_id`),
  CONSTRAINT `mk_timetable_table_course_table` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
  CONSTRAINT `mk_timetable_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_timetable_table_edu_form_table` FOREIGN KEY (`edu_form_id`) REFERENCES `edu_form` (`id`),
  CONSTRAINT `mk_timetable_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_timetable_table_edu_semestr_subject_table` FOREIGN KEY (`edu_semestr_subject_id`) REFERENCES `edu_semestr_subject` (`id`),
  CONSTRAINT `mk_timetable_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`),
  CONSTRAINT `mk_timetable_table_edu_type_table` FOREIGN KEY (`edu_type_id`) REFERENCES `edu_type` (`id`),
  CONSTRAINT `mk_timetable_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_timetable_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_timetable_table_group_table` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `mk_timetable_table_semestr_table` FOREIGN KEY (`semestr_id`) REFERENCES `semestr` (`id`),
  CONSTRAINT `mk_timetable_table_subject_category_table` FOREIGN KEY (`subject_category_id`) REFERENCES `subject_category` (`id`),
  CONSTRAINT `mk_timetable_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable`
--

LOCK TABLES `timetable` WRITE;
/*!40000 ALTER TABLE `timetable` DISABLE KEYS */;
/*!40000 ALTER TABLE `timetable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable_attend`
--

DROP TABLE IF EXISTS `timetable_attend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable_attend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timetable_id` int(11) NOT NULL,
  `ids_id` int(11) DEFAULT NULL,
  `timetable_date_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `student_user_id` int(11) DEFAULT NULL,
  `edu_plan_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `edu_semestr_id` int(11) DEFAULT NULL,
  `semestr_id` int(11) DEFAULT NULL,
  `edu_form_id` int(11) DEFAULT NULL,
  `edu_type_id` int(11) DEFAULT NULL,
  `edu_year_id` int(11) DEFAULT NULL,
  `group_type` int(11) NOT NULL,
  `timetable_reason_id` int(11) DEFAULT NULL,
  `reason` int(11) DEFAULT 0,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `subject_id` int(11) DEFAULT NULL,
  `subject_category_id` int(11) DEFAULT NULL,
  `para_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mk_timetable_attend_table_timetable_table` (`timetable_id`),
  KEY `mk_timetable_attend_table_timetable_ids_table` (`ids_id`),
  KEY `mk_timetable_attend_table_timetable_date_table` (`timetable_date_id`),
  KEY `mk_timetable_attend_table_group_table` (`group_id`),
  KEY `mk_timetable_attend_table_student_table` (`student_id`),
  KEY `mk_timetable_attend_table_student_user_table` (`student_user_id`),
  KEY `mk_timetable_attend_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_timetable_attend_table_faculty_table` (`faculty_id`),
  KEY `mk_timetable_attend_table_edu_semestr_table` (`edu_semestr_id`),
  KEY `mk_timetable_attend_table_semestr_table` (`semestr_id`),
  KEY `mk_timetable_attend_table_edu_form_table` (`edu_form_id`),
  KEY `mk_timetable_attend_table_edu_type_table` (`edu_type_id`),
  KEY `mk_timetable_attend_table_edu_year_table` (`edu_year_id`),
  KEY `mk_timetable_attend_table_timetable_reason_table` (`timetable_reason_id`),
  KEY `mk_timetable_attend_table_subject_table` (`subject_id`),
  KEY `mk_timetable_attend_table_subject_category_table` (`subject_category_id`),
  KEY `mk_timetable_attend_table_para_table` (`para_id`),
  CONSTRAINT `mk_timetable_attend_table_edu_form_table` FOREIGN KEY (`edu_form_id`) REFERENCES `edu_form` (`id`),
  CONSTRAINT `mk_timetable_attend_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_timetable_attend_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`),
  CONSTRAINT `mk_timetable_attend_table_edu_type_table` FOREIGN KEY (`edu_type_id`) REFERENCES `edu_type` (`id`),
  CONSTRAINT `mk_timetable_attend_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_timetable_attend_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_timetable_attend_table_group_table` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `mk_timetable_attend_table_para_table` FOREIGN KEY (`para_id`) REFERENCES `para` (`id`),
  CONSTRAINT `mk_timetable_attend_table_semestr_table` FOREIGN KEY (`semestr_id`) REFERENCES `semestr` (`id`),
  CONSTRAINT `mk_timetable_attend_table_student_table` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `mk_timetable_attend_table_student_user_table` FOREIGN KEY (`student_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `mk_timetable_attend_table_subject_category_table` FOREIGN KEY (`subject_category_id`) REFERENCES `subject_category` (`id`),
  CONSTRAINT `mk_timetable_attend_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `mk_timetable_attend_table_timetable_date_table` FOREIGN KEY (`timetable_date_id`) REFERENCES `timetable_date` (`id`),
  CONSTRAINT `mk_timetable_attend_table_timetable_ids_table` FOREIGN KEY (`ids_id`) REFERENCES `timetable` (`ids`),
  CONSTRAINT `mk_timetable_attend_table_timetable_reason_table` FOREIGN KEY (`timetable_reason_id`) REFERENCES `timetable_reason` (`id`),
  CONSTRAINT `mk_timetable_attend_table_timetable_table` FOREIGN KEY (`timetable_id`) REFERENCES `timetable` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable_attend`
--

LOCK TABLES `timetable_attend` WRITE;
/*!40000 ALTER TABLE `timetable_attend` DISABLE KEYS */;
/*!40000 ALTER TABLE `timetable_attend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable_date`
--

DROP TABLE IF EXISTS `timetable_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable_date` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timetable_id` int(11) NOT NULL,
  `ids_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `building_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `week_id` int(11) NOT NULL,
  `para_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `edu_semestr_subject_id` int(11) NOT NULL,
  `teacher_access_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `subject_category_id` int(11) DEFAULT NULL,
  `edu_plan_id` int(11) DEFAULT NULL,
  `edu_semestr_id` int(11) DEFAULT NULL,
  `edu_form_id` int(11) DEFAULT NULL,
  `edu_year_id` int(11) DEFAULT NULL,
  `edu_type_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `direction_id` int(11) DEFAULT NULL,
  `semestr_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `group_type` int(11) DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  `two_group` int(11) DEFAULT 0,
  `type` int(11) DEFAULT 0,
  `attend_status` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_timetable_date_table_timetable_table` (`timetable_id`),
  KEY `mk_timetable_date_table_timetable_ids_table` (`ids_id`),
  KEY `mk_timetable_date_table_building_table` (`building_id`),
  KEY `mk_timetable_date_table_room_table` (`room_id`),
  KEY `mk_timetable_date_table_week_table` (`week_id`),
  KEY `mk_timetable_date_table_para_table` (`para_id`),
  KEY `mk_timetable_date_table_group_table` (`group_id`),
  KEY `mk_timetable_date_table_edu_semestr_subject_table` (`edu_semestr_subject_id`),
  KEY `mk_timetable_date_table_teacher_access_table` (`teacher_access_id`),
  KEY `mk_timetable_date_table_user_table` (`user_id`),
  KEY `mk_timetable_date_table_subject_table` (`subject_id`),
  KEY `mk_timetable_date_table_subject_category_table` (`subject_category_id`),
  KEY `mk_timetable_date_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_timetable_date_table_edu_semestr_table` (`edu_semestr_id`),
  KEY `mk_timetable_date_table_edu_form_table` (`edu_form_id`),
  KEY `mk_timetable_date_table_edu_year_table` (`edu_year_id`),
  KEY `mk_timetable_date_table_edu_type_table` (`edu_type_id`),
  KEY `mk_timetable_date_table_faculty_table` (`faculty_id`),
  KEY `mk_timetable_date_table_direction_table` (`direction_id`),
  KEY `mk_timetable_date_table_semestr_table` (`semestr_id`),
  KEY `mk_timetable_date_table_course_table` (`course_id`),
  CONSTRAINT `mk_timetable_date_table_building_table` FOREIGN KEY (`building_id`) REFERENCES `building` (`id`),
  CONSTRAINT `mk_timetable_date_table_course_table` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
  CONSTRAINT `mk_timetable_date_table_direction_table` FOREIGN KEY (`direction_id`) REFERENCES `direction` (`id`),
  CONSTRAINT `mk_timetable_date_table_edu_form_table` FOREIGN KEY (`edu_form_id`) REFERENCES `edu_form` (`id`),
  CONSTRAINT `mk_timetable_date_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_timetable_date_table_edu_semestr_subject_table` FOREIGN KEY (`edu_semestr_subject_id`) REFERENCES `edu_semestr_subject` (`id`),
  CONSTRAINT `mk_timetable_date_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`),
  CONSTRAINT `mk_timetable_date_table_edu_type_table` FOREIGN KEY (`edu_type_id`) REFERENCES `edu_type` (`id`),
  CONSTRAINT `mk_timetable_date_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_timetable_date_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_timetable_date_table_group_table` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `mk_timetable_date_table_para_table` FOREIGN KEY (`para_id`) REFERENCES `para` (`id`),
  CONSTRAINT `mk_timetable_date_table_room_table` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`),
  CONSTRAINT `mk_timetable_date_table_semestr_table` FOREIGN KEY (`semestr_id`) REFERENCES `semestr` (`id`),
  CONSTRAINT `mk_timetable_date_table_subject_category_table` FOREIGN KEY (`subject_category_id`) REFERENCES `subject_category` (`id`),
  CONSTRAINT `mk_timetable_date_table_subject_table` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `mk_timetable_date_table_teacher_access_table` FOREIGN KEY (`teacher_access_id`) REFERENCES `teacher_access` (`id`),
  CONSTRAINT `mk_timetable_date_table_timetable_ids_table` FOREIGN KEY (`ids_id`) REFERENCES `timetable` (`ids`),
  CONSTRAINT `mk_timetable_date_table_timetable_table` FOREIGN KEY (`timetable_id`) REFERENCES `timetable` (`id`),
  CONSTRAINT `mk_timetable_date_table_user_table` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `mk_timetable_date_table_week_table` FOREIGN KEY (`week_id`) REFERENCES `week` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable_date`
--

LOCK TABLES `timetable_date` WRITE;
/*!40000 ALTER TABLE `timetable_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `timetable_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable_ids`
--

DROP TABLE IF EXISTS `timetable_ids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable_ids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `number` (`number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable_ids`
--

LOCK TABLES `timetable_ids` WRITE;
/*!40000 ALTER TABLE `timetable_ids` DISABLE KEYS */;
/*!40000 ALTER TABLE `timetable_ids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable_reason`
--

DROP TABLE IF EXISTS `timetable_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable_reason` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_confirmed` int(11) DEFAULT 0,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `student_user_id` int(11) DEFAULT NULL,
  `edu_plan_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `edu_semestr_id` int(11) DEFAULT NULL,
  `semestr_id` int(11) DEFAULT NULL,
  `edu_form_id` int(11) DEFAULT NULL,
  `edu_type_id` int(11) DEFAULT NULL,
  `edu_year_id` int(11) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_timetable_reason_table_group_table` (`group_id`),
  KEY `mk_timetable_reason_table_student_table` (`student_id`),
  KEY `mk_timetable_reason_table_student_user_table` (`student_user_id`),
  KEY `mk_timetable_reason_table_edu_plan_table` (`edu_plan_id`),
  KEY `mk_timetable_reason_table_faculty_table` (`faculty_id`),
  KEY `mk_timetable_reason_table_edu_semestr_table` (`edu_semestr_id`),
  KEY `mk_timetable_reason_table_semestr_table` (`semestr_id`),
  KEY `mk_timetable_reason_table_edu_form_table` (`edu_form_id`),
  KEY `mk_timetable_reason_table_edu_type_table` (`edu_type_id`),
  KEY `mk_timetable_reason_table_edu_year_table` (`edu_year_id`),
  CONSTRAINT `mk_timetable_reason_table_edu_form_table` FOREIGN KEY (`edu_form_id`) REFERENCES `edu_form` (`id`),
  CONSTRAINT `mk_timetable_reason_table_edu_plan_table` FOREIGN KEY (`edu_plan_id`) REFERENCES `edu_plan` (`id`),
  CONSTRAINT `mk_timetable_reason_table_edu_semestr_table` FOREIGN KEY (`edu_semestr_id`) REFERENCES `edu_semestr` (`id`),
  CONSTRAINT `mk_timetable_reason_table_edu_type_table` FOREIGN KEY (`edu_type_id`) REFERENCES `edu_type` (`id`),
  CONSTRAINT `mk_timetable_reason_table_edu_year_table` FOREIGN KEY (`edu_year_id`) REFERENCES `edu_year` (`id`),
  CONSTRAINT `mk_timetable_reason_table_faculty_table` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `mk_timetable_reason_table_group_table` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `mk_timetable_reason_table_semestr_table` FOREIGN KEY (`semestr_id`) REFERENCES `semestr` (`id`),
  CONSTRAINT `mk_timetable_reason_table_student_table` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `mk_timetable_reason_table_student_user_table` FOREIGN KEY (`student_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable_reason`
--

LOCK TABLES `timetable_reason` WRITE;
/*!40000 ALTER TABLE `timetable_reason` DISABLE KEYS */;
/*!40000 ALTER TABLE `timetable_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable_student`
--

DROP TABLE IF EXISTS `timetable_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ids_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_user_id` int(11) NOT NULL,
  `group_type` int(11) DEFAULT 1,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_timetable_student_table_timetable_ids_table` (`ids_id`),
  KEY `mk_timetable_student_table_group_table` (`group_id`),
  KEY `mk_timetable_student_table_student_table` (`student_id`),
  KEY `mk_timetable_student_table_student_user_table` (`student_user_id`),
  CONSTRAINT `mk_timetable_student_table_group_table` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`),
  CONSTRAINT `mk_timetable_student_table_student_table` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `mk_timetable_student_table_student_user_table` FOREIGN KEY (`student_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `mk_timetable_student_table_timetable_ids_table` FOREIGN KEY (`ids_id`) REFERENCES `timetable` (`ids`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable_student`
--

LOCK TABLES `timetable_student` WRITE;
/*!40000 ALTER TABLE `timetable_student` DISABLE KEYS */;
/*!40000 ALTER TABLE `timetable_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translate`
--

DROP TABLE IF EXISTS `translate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `table_name` varchar(255) NOT NULL,
  `language` varchar(2) NOT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translate`
--

LOCK TABLES `translate` WRITE;
/*!40000 ALTER TABLE `translate` DISABLE KEYS */;
INSERT INTO `translate` VALUES (1,1,'Kunduzgi',NULL,'edu_form','uz',1,1,1734431137,1734431137,2,0,0),(2,2,'Sirtqi',NULL,'edu_form','uz',1,1,1734431148,1734431148,2,0,0),(3,3,'Kunduzgi (3-smena)',NULL,'edu_form','uz',1,1,1734431169,1734438511,2,5,0),(4,1,'Bakalavr','Bakalavr','edu_type','uz',1,1,1734431183,1734431183,2,0,0),(5,2,'Magistratura','Magistratura','edu_type','uz',1,1,1734431190,1734438519,2,5,0),(6,1,'1 - bosqich',NULL,'course','uz',1,1,1734432461,1734432461,2,0,0),(7,2,'2 - bosqich',NULL,'course','uz',1,1,1734432468,1734432468,2,0,0),(8,3,'3 - bosqich',NULL,'course','uz',1,1,1734432474,1734432474,2,0,0),(9,4,'4 - bosqich',NULL,'course','uz',1,1,1734432478,1734432478,2,0,0),(10,5,'5 - bosqich',NULL,'course','uz',1,1,1734432484,1734432484,2,0,0),(11,1,'1 - semestr',NULL,'semestr','uz',1,1,1734432497,1734432497,2,0,0),(12,2,'2 - semestr',NULL,'semestr','uz',1,1,1734432503,1734432503,2,0,0),(13,3,'3 - semestr',NULL,'semestr','uz',1,1,1734432509,1734432509,2,0,0),(14,4,'4 - semestr',NULL,'semestr','uz',1,1,1734432516,1734432516,2,0,0),(15,5,'5 - semestr',NULL,'semestr','uz',1,1,1734432527,1734432527,2,0,0),(16,6,'6 - semestr',NULL,'semestr','uz',1,1,1734432533,1734432533,2,0,0),(17,7,'7 - semestr',NULL,'semestr','uz',1,1,1734432540,1734432540,2,0,0),(18,8,'8 - semestr',NULL,'semestr','uz',1,1,1734432546,1734432546,2,0,0),(19,9,'9 - semestr',NULL,'semestr','uz',1,1,1734432553,1734432553,2,0,0),(20,10,'10 - semestr',NULL,'semestr','uz',1,1,1734432559,1734432559,2,0,0),(21,1,'Oraliq nazorat',NULL,'exams_type','uz',1,1,1734432771,1734432771,2,0,0),(22,2,'Joriy nazorat',NULL,'exams_type','uz',1,1,1734432780,1734432780,2,0,0),(23,3,'Yakuniy nazorat',NULL,'exams_type','uz',1,1,1734432788,1734432788,2,0,0),(24,4,'Oraliq nazorat 2',NULL,'exams_type','uz',1,1,1734432801,1734432801,2,0,0),(25,5,'Mustaqil taʼlim',NULL,'exams_type','uz',1,1,1734432810,1734432810,2,0,0),(26,1,'Dushanba',NULL,'week','uz',1,1,1734432863,1734432863,2,0,0),(27,2,'Seshanba',NULL,'week','uz',1,1,1734432869,1734432869,2,0,0),(28,3,'Chorshanba',NULL,'week','uz',1,1,1734432874,1734432874,2,0,0),(29,4,'Payshanba',NULL,'week','uz',1,1,1734432882,1734432882,2,0,0),(30,5,'Juma',NULL,'week','uz',1,1,1734432887,1734432887,2,0,0),(31,6,'Shanba',NULL,'week','uz',1,1,1734432894,1734432894,2,0,0),(32,7,'Yakshanba',NULL,'week','uz',1,1,1734432901,1734432904,2,2,0),(33,1,'Majburiy',NULL,'subject_type','uz',1,1,1734432945,1734432945,2,0,0),(34,2,'Tanlov',NULL,'subject_type','uz',1,1,1734432952,1734432952,2,0,0),(35,1,'Maʼruza',NULL,'subject_category','uz',1,1,1734433080,1734433080,2,0,0),(36,2,'Amaliy',NULL,'subject_category','uz',1,1,1734433086,1734433086,2,0,0),(37,3,'Seminar',NULL,'subject_category','uz',1,1,1734433092,1734433092,2,0,0),(38,4,'Laboratoriya',NULL,'subject_category','uz',1,1,1734433131,1734433131,2,0,0),(39,5,'Kurs ishi',NULL,'subject_category','uz',1,1,1734433140,1734433140,2,0,0),(40,6,'Mustaqil taʼlim',NULL,'subject_category','uz',1,1,1734433148,1734433148,2,0,0),(41,1,'Grant',NULL,'student_category','uz',1,1,1734433177,1734433177,2,0,0),(42,2,'To‘lov-shartnoma',NULL,'student_category','uz',1,1,1734433184,1734433184,2,0,0),(43,3,'Qo\'shimcha kontrakt',NULL,'student_category','uz',1,1,1734433190,1734433190,2,0,0),(44,1,'Asosiy bino','Asosiy bino','building','uz',1,1,1734438261,1734438261,5,0,0),(45,1,'Main building',NULL,'building','en',1,1,1734438261,1734438261,5,0,0),(46,1,'Главное здание',NULL,'building','ru',1,1,1734438261,1734438261,5,0,0),(47,1,'Seminar xona','Seminar xona','room_type','uz',1,1,1734438312,1734438312,5,0,0),(48,1,'Workshop room',NULL,'room_type','en',1,1,1734438312,1734438312,5,0,0),(49,1,'Помещение для семинаров',NULL,'room_type','ru',1,1,1734438312,1734438312,5,0,0),(50,2,'Ma\'ruza xona','Ma\'ruza xona','room_type','uz',1,1,1734438395,1734438395,5,0,0),(51,2,'Lecture room',NULL,'room_type','en',1,1,1734438395,1734438395,5,0,0),(52,2,'Лекционная комната',NULL,'room_type','ru',1,1,1734438395,1734438395,5,0,0),(53,3,'Kompyuter xona','Kompyuter xona','room_type','uz',1,1,1734438433,1734438433,5,0,0),(54,3,'Computer room',NULL,'room_type','en',1,1,1734438433,1734438433,5,0,0),(55,3,'Компьютерный зал',NULL,'room_type','ru',1,1,1734438433,1734438433,5,0,0);
/*!40000 ALTER TABLE `translate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_access`
--

DROP TABLE IF EXISTS `user_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_access_type_id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `is_leader` tinyint(3) DEFAULT 0,
  `table_name` varchar(255) DEFAULT NULL,
  `role_name` varchar(255) DEFAULT NULL,
  `work_load_id` int(11) DEFAULT NULL,
  `work_rate_id` int(11) DEFAULT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `mk_user_access_table_user_access_type_table` (`user_access_type_id`),
  KEY `mk_user_access_table_work_load_table` (`work_load_id`),
  KEY `mk_user_access_table_work_rate_table` (`work_rate_id`),
  CONSTRAINT `mk_user_access_table_user_access_type_table` FOREIGN KEY (`user_access_type_id`) REFERENCES `user_access_type` (`id`),
  CONSTRAINT `mk_user_access_table_work_load_table` FOREIGN KEY (`work_load_id`) REFERENCES `work_load` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mk_user_access_table_work_rate_table` FOREIGN KEY (`work_rate_id`) REFERENCES `work_rate` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_access`
--

LOCK TABLES `user_access` WRITE;
/*!40000 ALTER TABLE `user_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_access_type`
--

DROP TABLE IF EXISTS `user_access_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_access_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `table_name` varchar(255) NOT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_access_type`
--

LOCK TABLES `user_access_type` WRITE;
/*!40000 ALTER TABLE `user_access_type` DISABLE KEYS */;
INSERT INTO `user_access_type` VALUES (1,'Faculty','faculties','\\common\\models\\model\\Faculty',1,1,1,1,1,1,0),(2,'Kafedra','kafedras','\\common\\models\\model\\Kafedra',1,1,1,1,1,1,0),(3,'Department','departments','\\common\\models\\model\\Department',1,1,1,1,1,1,0);
/*!40000 ALTER TABLE `user_access_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `auth_key` varchar(32) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `verification_token` varchar(255) DEFAULT NULL,
  `access_token` varchar(100) DEFAULT NULL,
  `access_token_time` int(11) DEFAULT NULL,
  `last_seen_time` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `template` varchar(255) DEFAULT NULL,
  `layout` varchar(255) DEFAULT NULL,
  `view` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `status` smallint(6) DEFAULT NULL,
  `status_n` smallint(6) NOT NULL DEFAULT 10,
  `deleted` tinyint(3) NOT NULL DEFAULT 0,
  `cacheable` tinyint(3) NOT NULL DEFAULT 0,
  `searchable` tinyint(3) NOT NULL DEFAULT 0,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_changed` int(11) NOT NULL DEFAULT 0,
  `attach_role` varchar(255) DEFAULT NULL,
  `change_password_type` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'ShokirjonMK','mvrsCIiU8i8CWVWL1LES','$2y$13$E.CD1pz7aK33vMqOp0MxSecyKEbkWhp.0ttlrHGsYiYMEg46RD6RK',NULL,NULL,'J22Zdn2bgdMXQHBr13SRBw0C-AT4uNe8',1734413786,NULL,'mkshokirjon@gmail.com','','','',NULL,NULL,10,10,0,0,0,1734413786,1734413786,0,0,0,NULL,0),(2,'blackmoon','FBunkjBgeMfFP301QMpP','$2y$13$1MgPmHfJZTqbyrp5MG.vvuzQYJKQzqlHY79UXw86ZY8mFR08IPjoq',NULL,NULL,'d42b5aOUlXc7pr3ZtbF0xgX5JSV-Ybcz',1734431089,1734436140,'blackmoonuz@mail.ru','','','',NULL,NULL,10,10,0,0,0,1734413787,1734436140,0,2,0,'admin',0),(3,'10ikbol','ceGrXGjEzMP7BLb7ozBJ','$2y$13$8lKQd8JYjVMsE/eKytvXyOQ/wO6Sc8bABp.cXzUqFxX4Eqe182ce2',NULL,NULL,'ai3XHaHMZwgSYNlYcUi-5Z8seZabQhXT',1734413787,NULL,'ikboljon@gmail.uz','','','',NULL,NULL,10,10,0,0,0,1734413787,1734413787,0,0,0,NULL,0),(4,'ahror','YgZudt6ifnYdB-GAP3Mh','$2y$13$E1WsJUcolAxLZgi6ZnG3w.Je6.IsO8IJTUHNtdEfGou5GCS2hBIay',NULL,NULL,'hrsyjSnDGgqCzwPaXhTfEuH7by-7XCzZ',1734437266,1734437309,'a-user@asd.uz','','','',NULL,NULL,10,10,0,0,0,1734413788,1734437309,0,4,0,'admin',0),(5,'n96','NPLLwVF9NhOWXlJ_QFHd','$2y$13$dhzfMS0mRP6YTUnhALae6.pmFd2TxpZlI2Y1T8/D9xZNDd2eUDz1W',NULL,NULL,'s21ZVBcTybcu7BQWSIKqVXZfi-klDOvQ',1734438117,1734439305,NULL,'','','',NULL,NULL,10,10,0,0,0,1734436012,1734439305,2,5,0,'edu_admin',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `week`
--

DROP TABLE IF EXISTS `week`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `week` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `week`
--

LOCK TABLES `week` WRITE;
/*!40000 ALTER TABLE `week` DISABLE KEYS */;
INSERT INTO `week` VALUES (1,1,1,NULL,1734432863,0,2,0),(2,2,1,NULL,1734432869,0,2,0),(3,3,1,NULL,1734432874,0,2,0),(4,4,1,NULL,1734432882,0,2,0),(5,5,1,NULL,1734432887,0,2,0),(6,6,1,NULL,1734432894,0,2,0),(7,7,0,NULL,1734432904,0,2,0);
/*!40000 ALTER TABLE `week` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_load`
--

DROP TABLE IF EXISTS `work_load`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_load` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_load`
--

LOCK TABLES `work_load` WRITE;
/*!40000 ALTER TABLE `work_load` DISABLE KEYS */;
/*!40000 ALTER TABLE `work_load` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_rate`
--

DROP TABLE IF EXISTS `work_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` float NOT NULL,
  `order` tinyint(1) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_rate`
--

LOCK TABLES `work_rate` WRITE;
/*!40000 ALTER TABLE `work_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `work_rate` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-17 21:00:01
